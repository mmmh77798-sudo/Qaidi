'use strict';
/* Railway-only entrypoint. One service in an isolated environment, public HTTP
   ingress with managed TLS; no TCP proxy and no other private-network services. */
const fs=require('node:fs');
const http=require('node:http');
const path=require('node:path');
const {isIP}=require('node:net');
const {createDesk}=require('../shared/server.cjs');
const BaseTransport=require('../shared/transport.cjs');
const {SQLiteStore}=require('../shared/store.cjs');
const P=require('../shared/policy.cjs');
const A=require('../shared/auth.cjs');
const release=require('../app/release.js');
const mount='/data', setupKey='QAYD_OWNER_SETUP_PASSWORD';
const uid=1000,gid=1000;
function need(ok,message){if(!ok)throw new Error(message);}
const unmapped=s=>String(s||'').toLowerCase().replace(/^::ffff:/,'');
function internalPeer(s){
  if(BaseTransport.privatePeer(s))return true;
  const a=unmapped(s);
  // Railway Metal can arrive from RFC 6598 shared address space. This is a
  // restricted address class, NOT a provider CIDR/authentication secret.
  return isIP(a)===4 && a.split('.')[0]==='100' && Number(a.split('.')[1])>=64 && Number(a.split('.')[1])<=127;
}
function one(req,n){
  const headers=req.headersDistinct?.[n];
  return headers?.length===1 ? headers[0] : undefined;
}
function realIP(req){
  const value=unmapped(one(req,'x-real-ip'));
  const family=value.length<=45 && isIP(value);
  // Canonicalize IPv6 so one address always uses the same rate limit key.
  return family===4?value:family===6?new URL('https://['+value+']').hostname.slice(1,-1):'';
}
function railwayTransport(host){
  const secure=req=>Boolean(internalPeer(req.socket.remoteAddress)&&one(req,'x-forwarded-proto')==='https'&&
     one(req,'x-forwarded-host')===host&&one(req,'host')===host&&realIP(req));
  return Object.freeze({secure,clientAddress:req=>secure(req)?realIP(req):''});
}
function readConfig(env=process.env){
  const host=env.RAILWAY_PUBLIC_DOMAIN||'';
  need(/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.up\.railway\.app$/.test(host),'A Railway-generated HTTPS domain is required.');
  need(!env.RAILWAY_TCP_PROXY_DOMAIN&&!env.RAILWAY_TCP_PROXY_PORT, 'Remove the TCP proxy. Only Railway HTTPS ingress is allowed.');
  need(env.RAILWAY_VOLUME_MOUNT_PATH===mount,'Attach one persistent Railway volume at /data.');
  const port=Number(env.PORT);
  need(/^\d+$/.test(env.PORT||'')&&Number.isInteger(port)&&port>=1024&&port<=65535,'Set a valid Railway PORT of at least 1024.');
  return {host,port};
}
function hasMount(mountinfo){return mountinfo.split('\n').some(line=>line.split(' ')[4]===mount);}
function dataDirectory(name){
  need(/^qayd(?:-deployment-check)?$/.test(name),'Invalid ledger storage directory.');
  need(fs.lstatSync(mount).isDirectory()&&hasMount(fs.readFileSync('/proc/self/mountinfo','utf8')),
    '/data is not a mounted volume. Refusing to use ephemeral storage.');
  const dir=path.join(mount,name);
  try{fs.mkdirSync(dir,{mode:0o700});}catch(e){if(e.code!=='EEXIST')throw e;}
  need(fs.lstatSync(dir).isDirectory(),'Storage must be a real directory.');
  if(process.getuid()===0){
    fs.chownSync(dir,uid,gid);fs.chmodSync(dir,0o700);
    process.setgroups([]);process.setgid(gid);process.setuid(uid);
  }
  const st=fs.statSync(dir);
  need(process.getuid()===uid&&process.getgid()===gid&&st.uid===uid&&(st.mode&0o777)===0o700,
    'Ledger must run as the restricted node user with private storage.');
  return dir;
}
function safeFile(file){
  const st=fs.lstatSync(file,{throwIfNoEntry:false});
  if(st) need(st.isFile()&&st.nlink===1&&st.uid===uid&&(st.mode&0o077)===0,'Unsafe database file; see the Railway recovery guide.');
  return !!st;
}
function send(res,status,body){
  res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff',
    'Referrer-Policy':'no-referrer','X-Frame-Options':'DENY','Strict-Transport-Security':'max-age=31536000'});
  res.end(JSON.stringify(body));
}
// Boot only from the mounted volume. Use the sealed variable solely as a
// temporary owner password; existing identities are never overwritten by it.
async function boot({directory='qayd',beforeServe=async()=>{}}={}){
  process.umask(0o077);
  const {host,port}=readConfig();
  const dir=dataDirectory(directory), db=path.join(dir,'qayd-shared.sqlite');
  const stored=safeFile(db);
  const temp=process.env[setupKey];delete process.env[setupKey];
  const transport=railwayTransport(host);
  let store=null;
  for(const suffix of ['-wal','-shm'])if(safeFile(db+suffix))need(stored,'Database sidecar exists without its database.');
  if(stored){
    store=new SQLiteStore(db);
    need(store.load(),'Existing database is not an initialized ledger; recover it rather than creating a new one.');
  }else if(temp!==undefined){
    need(typeof temp==='string'&&/^[\x21-\x7e]{20,128}$/.test(temp),'Use a unique temporary owner password of 20–128 printable ASCII characters, without spaces.');
    const hash=await A.hash(temp), state=P.fresh(), owner=A.makeUser('owner','مالك الدفتر',hash,{owner:true,mustChange:true});
    state.users.push(owner);P.log(state,owner,'owner-init');
    store=new SQLiteStore(db);store.init(state);
  }
  if(store)await beforeServe({dir,store});
  const app=store?createDesk({store,origin:'https://'+host,trustProxy:true,transport}):
    http.createServer({requestTimeout:15000,headersTimeout:10000,keepAliveTimeout:5000,maxHeaderSize:8192});
  const main=app.listeners('request')[0]; if(main)app.removeListener('request',main);
  app.on('request',(req,res)=>{
    if(req.method==='GET'&&req.url==='/health'&&one(req,'host')==='healthcheck.railway.app'&&internalPeer(req.socket.remoteAddress))return send(res,200,{ok:true});
    if(main)return main(req,res);
    if(!transport.secure(req))return send(res,426,{code:'tls-required',error:'استخدم عنوان HTTPS المعتمد لهذا الدفتر.'});
    if(req.method==='GET'&&req.url==='/api/info')return send(res,200,{demo:false,initialized:false,version:release.version,actions:P.actions,timezone:'Asia/Aden'});
    req.resume();
    send(res,503,{code:'owner-not-initialized',error:'خادم قيد متصل. يلزم تهيئة حساب المالك من لوحة Railway أولًا.'});
  });
  app.once('error',()=>{console.error('Qayd Railway: could not listen on the configured port.');process.exit(1);});
  app.listen(port,'0.0.0.0',()=>console.log('Qayd Railway: persistent volume ready; '+(store?'ledger initialized.':'waiting for private owner initialization.')));
  for(const signal of ['SIGTERM','SIGINT']) process.once(signal,()=>{
    const grace=setTimeout(()=>process.exit(1),10000);grace.unref();
    app.close(()=>{try{store?.close();}finally{process.exit(0);}});
  });
  return app;
}
function main(options){boot(options).catch(e=>{
  // Configuration messages above contain no runtime variables or credentials.
  const msg=String(e?.message||'').split('\n',1)[0];
  const safe=/^(A Railway|Remove the TCP|Attach one|Set a valid|\/data is not|Storage must|Ledger must|Unsafe database|Database sidecar|Existing database|Use a unique)/.test(msg);
  console.error('Qayd Railway: '+(safe?msg:'persistent service failed closed. Inspect the volume and settings.'));
  process.exitCode=1;
});}
if(require.main===module)main();
module.exports={main,readConfig,hasMount,internalPeer,railwayTransport};
