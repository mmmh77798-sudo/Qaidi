#!/usr/bin/env python3
"""Stage the exact public 3.4 runtime for the existing Qayd Railway service."""
from pathlib import Path
import argparse
import shutil

parser = argparse.ArgumentParser()
parser.add_argument('stage', type=Path, help='New empty destination (must not exist)')
args = parser.parse_args()
here = Path(__file__).resolve().parent
root = here.parents[1] / 'qayd'
stage = args.stage.resolve()

# Positive allowlist: no databases, private screenshots, keys, tests, logs or environment files.
app = ('logo.svg', 'icons.js', 'release.js', 'ledger.js', 'collections-model.js',
       'vault.js', 'category-backup.js', 'db-backup.js', 'db-engine.js', 'DB-ENGINE-LICENSE.txt',
       'fonts/fonts.css', 'fonts/OFL.txt',
       *(f'fonts/plex-{alphabet}-{weight}.woff2' for alphabet in ('arabic', 'latin') for weight in (400, 500, 600, 700)))
shared = ('server.cjs', 'policy.cjs', 'store.cjs', 'auth.cjs', 'totp.cjs', 'transport.cjs',
          'transfer.cjs', 'recovery.cjs', 'restore.cjs', 'qayd-recovery',
          'public/index.html', 'public/desk.css', 'public/desk.js', 'public/operations.js', 'public/maintenance.js')
railway = ('start.cjs', 'recovery.cjs', 'qayd-owner-reset')
stage.mkdir(mode=0o700, parents=True, exist_ok=False)

def copy(base, name, relative):
    out = stage / relative
    out.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(base / name, out)
    out.chmod(0o755 if out.name in ('qayd-recovery', 'qayd-owner-reset') else 0o644)

for part, names in (('app', app),('shared',shared)):
    for name in names:
        copy(root / part, name, f'{part}/{name}')
for name in railway:
    copy(here,name,f'railway/{name}')
copy(root, 'COPYRIGHT.md', 'COPYRIGHT.md')
old = 'CMD ["node", "railway/start.cjs"]'
text = (here / 'Dockerfile').read_text()
assert text.count(old) == 1
(stage / 'Dockerfile').write_text(text.replace(old, 'COPY --chmod=0755 railway/qayd-owner-reset /usr/local/bin/qayd-owner-reset\nCMD ["node", "/qayd/railway/recovery.cjs"]'))
(stage / '.dockerignore').write_text((root / '.dockerignore').read_text() + '\n!railway/\nrailway/*\n' + ''.join(f'!railway/{name}\n' for name in railway))
count = sum(p.is_file() for p in stage.rglob('*'))
assert count == len(app) + len(shared) + len(railway) + 3
print(f'Qayd 3.4 Railway upgrade staged: {count} allowlisted files.')
