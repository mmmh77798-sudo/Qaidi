'use strict';
/* Qayd Railway repair entrypoint. Keep the single existing initialized ledger
   on its mounted volume. Do not import, move, overwrite, initialize or delete. */
const fs=require('node:fs');
const path=require('node:path');
const {spawnSync}=require('node:child_process');
const {DatabaseSync}=require('node:sqlite');
const runtime=require('./start.cjs');
const mount='/data', fileName='qayd-shared.sqlite', uid=1000, gid=1000;
const service='74123369-bfd8-44a8-bea4-14fd04ba593f';
const environment='3c38e681-7707-499c-b1ef-096551c61669';
const choices=['qayd','qayd-deployment-check'];
class Refusal extends Error {}
function requireThat(ok,message){if(!ok)throw new Refusal(message);}
function lstat(file){return fs.lstatSync(file,{throwIfNoEntry:false});}
function sameUser(s){return s.uid===uid&&s.gid===gid;}
function safeFile(s){return s.isFile()&&s.nlink===1&&sameUser(s)&&(s.mode&0o077)===0;}
function existingLedger(){
  requireThat(process.env.RAILWAY_SERVICE_ID===service&&process.env.RAILWAY_ENVIRONMENT_ID===environment,
    'Wrong Railway service or environment; nothing changed.');
  runtime.readConfig();
  requireThat(lstat(mount)?.isDirectory()&&runtime.hasMount(fs.readFileSync('/proc/self/mountinfo','utf8')),
    'The persistent volume is not mounted; nothing changed.');
  if(process.getuid()===0){process.setgroups([]);process.setgid(gid);process.setuid(uid);}
  requireThat(process.getuid()===uid&&process.getgid()===gid,'Unexpected service user; nothing changed.');
  const found=[];
  for(const name of choices){
    const dir=path.join(mount,name), st=lstat(dir);
    if(!st)continue;
    requireThat(st.isDirectory()&&sameUser(st)&&(st.mode&0o777)===0o700,
      'A Qayd directory is not a private directory owned by the service; nothing changed.');
    const file=path.join(dir,fileName), main=lstat(file);
    for(const suffix of ['-wal','-shm']){
      const side=lstat(file+suffix);
      requireThat(!side||(main&&safeFile(side)), 'An unexpected SQLite sidecar needs review; nothing changed.');
    }
    if(!main)continue;
    requireThat(safeFile(main)&&main.size>0,'An unexpected SQLite file needs review; nothing changed.');
    found.push({name,file});
  }
  requireThat(found.length===1,found.length===0?'No existing Qayd ledger found; nothing changed.':'More than one Qayd ledger found; no database was selected.');
  const choice=found[0];
  const probe=new DatabaseSync(choice.file,{readOnly:true});
  try{
    probe.exec('PRAGMA busy_timeout=5000; PRAGMA query_only=ON');
    requireThat(probe.prepare('PRAGMA quick_check(1)').get()?.quick_check==='ok','SQLite integrity check failed; nothing changed.');
    const row=probe.prepare('SELECT seq,document FROM desk WHERE id=1').get();
    requireThat(row&&Number.isSafeInteger(row.seq)&&row.seq>=1,'Existing database has no initialized ledger; nothing changed.');
    const data=JSON.parse(row.document);
    const owners=Array.isArray(data?.users)?data.users.filter(u=>u?.owner):[];
    requireThat(data?.schema===1&&owners.length===1&&owners[0]?.login==='owner'&&data?.ledger&&Array.isArray(data.audit),
      'Existing database has no recognized Qayd owner; nothing changed.');
  }finally{probe.close();}
  return choice;
}
function run(){
  process.umask(0o077);
  const command=process.argv[2]||'serve';
  requireThat(['serve','check','owner-reset'].includes(command),'Unknown maintenance command; nothing changed.');
  const choice=existingLedger();
  if(command==='check'){console.log('Existing Qayd ledger verified on the mounted volume.');return;}
  if(command==='owner-reset'){
    requireThat(!process.stdin.isTTY,'Run the private qayd-owner-reset prompt; nothing changed.');
    const r=spawnSync(process.execPath,[path.join(__dirname,'../shared/server.cjs'),'owner-reset'],{
      env:{...process.env,QAYD_DB:choice.file},stdio:'inherit'
    });
    process.exitCode=r.status??1;
    return;
  }
  console.log('Qayd Railway: production entrypoint preserving '+(choice.name===choices[0]?'primary':'existing legacy')+' ledger on persistent volume.');
  runtime.main({directory:choice.name});
}
if(require.main===module){
  try{run();}catch(e){
    console.error('Qayd Railway: '+(e instanceof Refusal?e.message:'Could not safely verify the mounted Qayd ledger; no initialization was attempted.'));
    process.exitCode=1;
  }
}
