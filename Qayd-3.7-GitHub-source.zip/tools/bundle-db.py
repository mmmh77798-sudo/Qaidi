"""Build the entirely local SQLite worker from the pinned sql.js distribution."""
from pathlib import Path
from base64 import b64encode
from json import loads, dumps
from sys import argv

here = Path(__file__).resolve().parent
pkg = Path(argv[1])
assert loads((pkg/'package.json').read_text())['version'] == '1.16.0'
wasm = b64encode((pkg/'dist/sql-wasm.wasm').read_bytes()).decode('ascii')
worker_code = (pkg/'dist/sql-wasm.js').read_text() + '\nconst SQL_WASM="' + wasm + '";\n' + (here/'db-worker.js').read_text()
(here.parent/'app'/'db-engine.js').write_text('/* sql.js 1.16.0, MIT · see DB-ENGINE-LICENSE.txt. */\nglobalThis.QaydDbEngine=' + dumps(worker_code) + ';\n')
(here.parent/'app'/'DB-ENGINE-LICENSE.txt').write_text((pkg/'LICENSE').read_text())
