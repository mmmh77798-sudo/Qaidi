/* Runs inside the disposable backup worker, not in the ledger UI. */
const QAYD_ID=0x51415944, DB_LIMIT=48*1024*1024, DOC_LIMIT=20*1024*1024, PART=65536;
const SQLITE=[83,81,76,105,116,101,32,102,111,114,109,97,116,32,51,0];
class BackupProblem extends Error{}
const fail=text=>{throw new BackupProblem(text);};
const quote=name=>'"'+name.replace(/"/g,'""')+'"';
function select(db,sql,max,params=[]){
  const s=db.prepare(sql), rows=[];
  try {if(params.length)s.bind(params);while(s.step()){if(rows.length===max)fail('عدد السجلات في النسخة أكبر من الحد المدعوم.');rows.push(s.get());}}
  finally{s.free();}
  return rows;
}
function requireTable(db,tables,name,fields,pk){
  if(!tables.has(name))fail('بنية جداول النسخة غير متوافقة.');
  const cols=new Map(select(db,'SELECT name,pk FROM pragma_table_info(?, \'main\')',128,[name]).map(([n,p])=>[n.toLowerCase(),p]));
  if(fields.some(n=>!cols.has(n))||(pk&&cols.get(pk)!==1))fail('بنية أعمدة النسخة غير متوافقة.');
}
function qabRead(db,tables,v){
  if(v!==1)fail('إصدار نسخة قيد بصيغة DB غير مدعوم.');
  requireTable(db,tables,'qayd_backup',['part','payload'],'part');
  const s=db.prepare(`SELECT part, CASE WHEN typeof(payload)='blob' AND length(payload) BETWEEN 1 AND ${PART} THEN payload END FROM qayd_backup ORDER BY part LIMIT ${DOC_LIMIT/PART+1}`);
  let n=0, total=0;const chunks=[];
  try{
    while(s.step()){
      const [index,b]=s.get();
      if(index!==n++||!(b instanceof Uint8Array)||b.length>DOC_LIMIT-total)fail('محتوى نسخة قيد ناقص أو غير صالح.');
      total+=b.length;chunks.push(b);
    }
  }finally{s.free();}
  if(!total)fail('نسخة قيد فارغة.');
  const text=new Uint8Array(total);let offset=0;
  for(const chunk of chunks){text.set(chunk,offset);offset+=chunk.length;}
  return {kind:'qayd',text:new TextDecoder('utf-8',{fatal:true}).decode(text)};
}
function legacyRead(db,tables,v,app,review=false){
  if(v!==4||app!==0)fail('هذه ليست نسخة قيد أو نسخة «دفتر الحسابات» ببنية SQLite 4 المدعومة.');
  const cut=(field,len)=>`CASE WHEN typeof(${quote(field)})='blob' THEN char(1) ELSE substr(CAST(${quote(field)} AS TEXT),1,${len+1}) END`;
  // Materialize live postings plus the narrow optional balance/count check below.
  // Never read identity, licensing, deleted, replica or attachment values.
  const read=(table,fields,max)=>{
    requireTable(db,tables,table,fields.map(([n])=>n),'id');
    return select(db,`SELECT ${fields.map(([n,l])=>cut(n,l)).join(',')} FROM ${quote(table)} ORDER BY "id" LIMIT ${max+1}`,max);
  };
  requireTable(db,tables,'doc_hdr',['tr_id','cus_id','in','out']);
  const groups=[['id',22],['name',55]], currencies=[['id',22],['name',50]], accounts=[['id',22],['name',96],['gsm',54],['g_id',22]], transactions=[['id',22],['cus_id',22],['in',65],['out',65],['date_',125],['remarks',606],['now_',125],['t_cus_id',22],['curr_id',22]];
  if(review){
    for(const [table,fields] of [['groups',groups],['currency',currencies],['customers',accounts],['transactions',transactions]])requireTable(db,tables,table,fields.map(([name])=>name),'id');
    return {kind:'legacy'};
  }
  let cachedBalances=[];
  // The cache is not a source of postings. Ignore it when absent or incompatible.
  if(tables.has('cus_search_tmp'))try{
    const fields=[['id',22],['curr_id',22],['balance',65],['max_id',22],['cnt:1',12]];
    requireTable(db,tables,'cus_search_tmp',fields.map(([n])=>n));
    cachedBalances=select(db,`SELECT ${fields.map(([n,l])=>cut(n,l)).join(',')}, typeof("balance") FROM cus_search_tmp LIMIT 60001`,60000);
  }catch{}
  return {kind:'legacy',source:{cachedBalances,
    categories:read('groups',groups,200),
    currencies:read('currency',currencies,40),
    accounts:read('customers',accounts,10000),
    transactions:read('transactions',transactions,60000)
  }};
}
function readDb(SQL,bytes,review=false){
  if(!(bytes instanceof Uint8Array)||bytes.length<100||bytes.length>DB_LIMIT||!SQLITE.every((v,i)=>v===bytes[i]))fail('الملف ليس قاعدة بيانات SQLite قابلة للقراءة.');
  const head=new DataView(bytes.buffer,bytes.byteOffset,100), size=head.getUint16(16)===1?65536:head.getUint16(16);
  if(size<512||size>65536||(size&(size-1))||bytes.length%size)fail('ملف قاعدة البيانات غير مكتمل.');
  const v=head.getInt32(60),app=head.getInt32(68);
  if(app!==QAYD_ID&&(v!==4||app!==0))fail('ملف DB لا يطابق نسخة قيد أو بنية نسخة دفتر الحسابات المدعومة.');
  const db=new SQL.Database(bytes);
  try{
    db.exec('PRAGMA trusted_schema=OFF; PRAGMA query_only=ON;');
    const tables=new Set(select(db,`SELECT lower(name) FROM pragma_table_list WHERE "schema"='main' AND type='table' LIMIT 258`,257).map(r=>r[0]));
    if(review){const r=select(db,'PRAGMA quick_check(1)',1);if(r.length!==1||r[0][0]!=='ok')fail('لم يجتز ملف SQLite فحص البنية. استخدم نسخة سليمة أخرى.');}
    return app===QAYD_ID?qabRead(db,tables,v):legacyRead(db,tables,v,app,review);
  }finally{db.close();}
}
function makeDb(SQL,value){
  if(typeof value!=='string'||!value.length||value.length>DOC_LIMIT)fail('حجم الدفتر أكبر من حد النسخة.');
  const bytes=new TextEncoder().encode(value);if(bytes.length>DOC_LIMIT)fail('حجم الدفتر أكبر من حد النسخة.');
  const db=new SQL.Database();
  try{
    db.exec(`PRAGMA application_id=${QAYD_ID}; PRAGMA user_version=1; CREATE TABLE qayd_backup(part INTEGER PRIMARY KEY, payload BLOB NOT NULL); BEGIN;`);
    const s=db.prepare('INSERT INTO qayd_backup(part,payload) VALUES(?,?)');
    try{for(let at=0;at<bytes.length;at+=PART)s.run([at/PART,bytes.subarray(at,at+PART)]);}finally{s.free();}
    db.exec('COMMIT');return db.export();
  }finally{db.close();}
}
self.onmessage=async e=>{
  let SQL;
  try{SQL=await initSqlJs({wasmBinary:Uint8Array.from(atob(SQL_WASM),c=>c.charCodeAt(0))});}
  catch{self.postMessage({error:'قراءة أو إنشاء ملفات DB تحتاج إلى Chrome أو Android System WebView محدث.'});return;}
  try{
    if(e.data.action==='write'){
      const bytes=makeDb(SQL,e.data.value);self.postMessage({bytes},[bytes.buffer]);
    }else self.postMessage(readDb(SQL,new Uint8Array(e.data.bytes),e.data.review===true));
  }catch(e){self.postMessage({error:e instanceof BackupProblem?e.message:'تعذّر قراءة أو تجهيز قاعدة البيانات. تأكد من اكتمال الملف وصحة النسخة.'});}
};
