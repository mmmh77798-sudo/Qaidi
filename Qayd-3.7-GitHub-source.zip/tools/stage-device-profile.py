#!/usr/bin/env python3
"""Stage the isolated APK setup screen: only the fixed local UI and its dependencies."""
from pathlib import Path
import argparse
import shutil

parser = argparse.ArgumentParser()
parser.add_argument('out', type=Path)
args = parser.parse_args()
root = Path(__file__).resolve().parent.parent
out = args.out
out.mkdir(parents=True, exist_ok=False)
for n in ('index.html', 'profile.css', 'profile.js'):
    shutil.copyfile(root / 'android' / 'profile' / n, out / n)
for n in ('icons.js', 'shared-link.js', 'logo.svg'):
    shutil.copyfile(root / 'app' / n, out / n)
shutil.copytree(root / 'app' / 'fonts', out / 'fonts')
