#!/usr/bin/env python3
"""Create one APK-only set of shared desk assets; never bundle remote HTML."""
from pathlib import Path
import argparse
import re
import shutil

parser = argparse.ArgumentParser()
parser.add_argument('out', type=Path)
args = parser.parse_args()
root = Path(__file__).resolve().parent.parent
out = args.out
out.mkdir(parents=True, exist_ok=False)
public = root / 'shared' / 'public'
for name in ('desk.js', 'desk.css', 'operations.js'):
    shutil.copyfile(public / name, out / name)
for name in ('embedded.css', 'transport.js'):
    shutil.copyfile(root / 'android' / 'desk' / name, out / name)
assets = out / 'assets'
assets.mkdir()
for name in ('logo.svg', 'release.js', 'icons.js', 'ledger.js'):
    shutil.copyfile(root / 'app' / name, assets / name)
shutil.copytree(root / 'app' / 'fonts', assets / 'fonts')
index = (public / 'index.html').read_text(encoding='utf-8')
index = re.sub(r'(src|href)="/', r'\1="', index)
old = '  <script defer src="assets/vault.js"></script>'
assert index.count(old) == 1
index = index.replace(old, '  <link rel="stylesheet" href="embedded.css">\n  <script defer src="transport.js"></script>')
# Sensitive file operations live in the external, authenticated owner site.
for src in ('assets/category-backup.js', 'maintenance.js'):
    line = f'  <script defer src="{src}"></script>\n'
    assert index.count(line) == 1
    index = index.replace(line, '')
policy = ("default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self'; font-src 'self'; "
          "connect-src 'none'; frame-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'")
index = index.replace('  <meta charset="utf-8">', '  <meta charset="utf-8">\n  <meta http-equiv="Content-Security-Policy" content="' + policy + '">')
(out / 'index.html').write_text(index, encoding='utf-8')
