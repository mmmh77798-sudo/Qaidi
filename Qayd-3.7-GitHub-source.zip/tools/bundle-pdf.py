"""Bundle the offline PDF engine and the two full OFL font files.

Usage: python3 tools/bundle-pdf.py /tmp/qayd-pdf/node_modules /tmp/qayd-pdf-fonts
See app/pdf/PDF-CREDITS.txt. No personal PDFs are inputs to this build.
"""
from base64 import b64encode
from json import dumps, loads
from hashlib import sha256
from pathlib import Path
from subprocess import run
from sys import argv
from tempfile import TemporaryDirectory
from shutil import copyfile

root = Path(__file__).resolve().parent.parent
modules, fonts = map(lambda v: Path(v).resolve(), argv[1:3])
out = root / 'app' / 'pdf'
out.mkdir(exist_ok=True)
versions = {'jspdf': '4.2.1', 'pdfjs-dist': '4.10.38', 'bidi-js': '1.0.3', 'esbuild': '0.25.12'}
for package, version in versions.items():
    assert loads((modules / package / 'package.json').read_text())['version'] == version
copyfile(modules / 'jspdf/dist/jspdf.umd.min.js', out / 'writer.js')
copyfile(modules / 'jspdf/LICENSE', out / 'jsPDF-LICENSE.txt')
copyfile(modules / 'pdfjs-dist/LICENSE', out / 'PDF.js-LICENSE.txt')
copyfile(modules / 'bidi-js/LICENSE.txt', out / 'bidi-js-LICENSE.txt')
pdfjs = modules / 'pdfjs-dist/legacy/build'
esbuild = str(modules / '.bin/esbuild')
common = ['--bundle', '--platform=browser', '--format=iife', '--minify', '--legal-comments=inline', '--external:node:*', '--target=es2022']
with TemporaryDirectory() as folder:
    temp = Path(folder)
    entry = temp / 'runtime.mjs'
    entry.write_text(f'''import {{ getDocument, PDFWorker }} from {dumps(str(pdfjs/'pdf.min.mjs'))};
import bidiFactory from {dumps(str(modules/'bidi-js/dist/bidi.mjs'))};
globalThis.QaydPdfRuntime = {{getDocument, PDFWorker, bidi: bidiFactory()}};
''')
    run([esbuild, str(entry), *common, f'--outfile={out/"runtime.js"}'], check=True)
    run([esbuild, str(pdfjs/'pdf.worker.min.mjs'), *common, f'--outfile={temp/"worker.js"}'], check=True)
    (out/'worker-source.js').write_text('/* PDF.js worker, embedded for a local Blob worker on file: origins. */\nglobalThis.QaydPdfWorkerSource='+dumps((temp/'worker.js').read_text())+';\n')
font_digests = {'Regular': '6f611412270a132bbac838da9259d4c68569b4175f3b3b8fa3fa36a30b56dab9',
                'SemiBold': '597bd5502e5997be4414e4c9c88834b30ff3784250c84f20bce2b20e53ebd467'}
encoded = {}
for weight, digest in font_digests.items():
    font = (fonts / f'{weight}.ttf').read_bytes()
    if sha256(font).hexdigest() != digest:
        raise ValueError(f'{weight} font is not the expected release')
    encoded[weight] = b64encode(font).decode('ascii')
(out/'fonts.js').write_text('/* IBM Plex Sans Arabic, see ../fonts/OFL.txt. */\nglobalThis.QaydPdfFonts='+dumps(encoded)+';\n')
