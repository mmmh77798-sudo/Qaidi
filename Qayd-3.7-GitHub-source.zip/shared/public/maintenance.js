'use strict';
/* Web-owner workflow only. Reading and decrypting a phone file never uploads it. */
const DeskMaintenance=(()=>{
  const MAX=14*1024*1024;
  const available=()=>!embedded&&!s.demo&&s.me?.owner&&s.capabilities.categoryTransfer===1&&s.capabilities.recoveryArchive===1;
  const check=(name,label)=>`<label class="check keep-check"><input type="checkbox" name="${h(name)}" required><span>${h(label)}</span></label>`;
  const counts=(x)=>`<dl class="transfer-counts"><div><dt>الحسابات</dt><dd>${bdi(number(x.accounts))}</dd></div><div><dt>الحركات</dt><dd>${bdi(number(x.movements))}</dd></div><div><dt>سندات القبض</dt><dd>${bdi(number(x.receipts))}</dd></div></dl>`;
  function panel(){
    if(!available())return '';
    const m=s.desk.maintenance||{};
    return `<section class="panel maintenance-panel" id="maintenance-panel">${panelHeader('النقل والاستعادة','إجراءات المالك فقط · لا مزامنة تلقائية مع دفتر الهاتف',badge('خاص','ok'))}
      <div class="pane-content maintenance-steps">
        <article class="maintenance-step">${tint('lock','green')}<div><p class="cap">الخطوة ١</p><h3>احفظ نسخة استعادة للخادم</h3><p>تتضمن السجلات والمستخدمين والصلاحيات والتدقيق. نزّلها مشفّرة واحتفظ بها خارج الاستضافة.</p>
        <div class="row">${btn('تنزيل ملف الاستعادة','recovery-export','download',m.backupReady?'outline':'primary')}${m.backupReady?badge('جُهّزت نسخة للحالة الحالية','ok'):''}</div></div></article>
        <article class="maintenance-step">${tint('tag')}<div><p class="cap">الخطوة ٢</p><h3>أضف تصنيفًا من دفتر الهاتف</h3><p>تصنيف جديد من ملف واحد، دون استبدال الحسابات أو منح صلاحيات تلقائيًا. جهّز الملف من «نقل تصنيف من الهاتف» في قيد.</p>
        <div class="row">${btn('اختيار ملف تصنيف','transfer-pick','archive',m.backupReady?'primary':'outline',m.backupReady?'':'disabled')}${m.transfers?badge(`${number(m.transfers)} عملية نقل`,'neutral'):''}</div></div></article>
      </div></section>`;
  }
  function recoveryForm(){
    dial('تنزيل ملف استعادة الخادم','هذه ليست نسخة الهاتف أو تصدير السجلات فقط.',tip('تحتوي النسخة حتى على بيانات المصادقة. احفظ الملف المشفّر على جهاز أو مخزن خاص خارج الاستضافة، واحفظ العبارة في مكان منفصل. استعادته على خادم معزول، لا عبر رفعه إلى هذه الصفحة.','warn','lock')+
      fld('current','كلمة سر حساب المالك','',{type:'password',attrs:'required maxlength="128" autocomplete="current-password"',ltr:true})+
      (s.me.mfa?DeskOps.otpField(): '')+
      fld('phrase','عبارة استعادة جديدة · 16 حرفًا على الأقل','',{type:'password',attrs:'required minlength="16" maxlength="128" autocomplete="new-password"',ltr:true})+
      fld('again','أعد كتابة عبارة الاستعادة','',{type:'password',attrs:'required minlength="16" maxlength="128" autocomplete="new-password"',ltr:true}),async f=>{
        if(f.phrase!==f.again||f.phrase===f.current)throw new Error('طابق عبارتي الاستعادة واختر عبارة غير كلمة سر المالك.');
        const archive=await api('recovery/export',{current:f.current,phrase:f.phrase,...(f.otp?{otp:f.otp}:{})},'blob');
        saveBlob(archive,`qayd-recovery-${s.desk.today}.qayd-recovery`);close();
        flash('طُلب تنزيل الملف. تحقّق من اكتماله واحفظه خارج الاستضافة.');
        try{await refresh();}catch(e){if(e.code==='login')return clearSession('أُنشئ الملف. سجّل الدخول لتحديث حالة النسخة.');flash('طُلب التنزيل، لكن حالة الدفتر لم تُحدّث. اضغط تحديث قبل النقل.',true);}
      },{submit:'تشفير وتنزيل'});
  }
  function pick(){
    if(!s.desk.maintenance?.backupReady)throw new Error('نزّل نسخة استعادة للحالة الحالية أولًا.');
    dial('اختيار تصنيف من دفتر الهاتف','في هذه الخطوة يُفتح الملف في المتصفح فقط؛ لا يُرسل إلى الخادم.',
      fld('source','ملف نقل التصنيف · DB أو JSON','',{type:'file',attrs:'required accept=".db,.json,.sqlite,.sqlite3,application/octet-stream,application/json"'})+
      fld('password','عبارة ملف النقل (إذا كان مشفّرًا)','',{type:'password',attrs:'maxlength="128" autocomplete="off"',ltr:true})+
      tip('اختر ملف تصنيف واحد بلا صور. لن يُفتح ملف الاستعادة أو نسخة دفتر كاملة من هنا.','','file'),async f=>{
        const copy=QaydCategoryBackup.validate(await readDeskFile(f.source,f.password));
        if(copy.demo||copy.includePhotos||!copy.accounts.length)throw new Error('اختر تصنيفًا حقيقيًا غير فارغ من «تجهيز ملف نقل مشفّر»، دون صور.');
        if(new Blob([JSON.stringify(copy)]).size>MAX)throw new Error('ملف التصنيف أكبر من حد النقل (14 ميغابايت قبل التشفير).');
        const initialName=Array.from(copy.category.name+' · الهاتف').slice(0,50).join('').slice(0,50),version=s.desk.version;
        dial('إرسال التصنيف للمراجعة',copy.category.name,
          counts({accounts:copy.accounts.length,movements:copy.entries.length,receipts:copy.entries.filter(e=>e.receipt).length})+
          fld('name','اسم جديد للتصنيف في الدفتر المشترك',initialName,{attrs:'required maxlength="50" dir="auto"'})+
          tip(`وجهة النقل: ${location.origin}. أرسل هذا التصنيف فقط للمراجعة عبر HTTPS. ملف الهاتف ودفتره لن يتغيّرا. راجع المذكرات والأسماء والأرقام قبل المشاركة لاحقًا.`,'warn','cloud')+
          check('previewConsent','أوافق على إرسال بيانات هذا التصنيف فقط إلى هذا الخادم للمراجعة.'),async b=>{
            if(!b.previewConsent)throw new Error('أكّد إرسال هذا التصنيف للمراجعة.');
            return review(await api('book/transfer-review',{version,name:b.name,copy,previewConsent:true}));
          },{submit:'إرسال للمراجعة'});
      },{submit:'فتح الملف محليًا'});
  }
  function review({ticket,version,summary:r}){
    const amounts=r.totals.length?`<div class="scroll transfer-totals"><table><caption>أرصدة التصنيف بعد النقل (دون تحويل بين العملات)</caption><thead><tr><th scope="col">العملة</th><th scope="col">لي</th><th scope="col">عليّ</th><th scope="col">الصافي</th></tr></thead>
      <tbody>${r.totals.map(x=>`<tr data-code="${h(x.code)}"><th scope="row">${bdi(x.code)}</th><td>${bdi(money(x.credit))}</td><td>${bdi(money(x.debit))}</td><td class="${x.net<0?'neg':'pos'}">${bdi(money(x.net))}</td></tr>`).join('')}</tbody></table></div>`:'';
    const notes=[r.standalone?`${number(r.standalone)} طرف تحويل يُحفظ بقيمته فقط دون بيانات الطرف الآخر.`:'',
      r.archived?`${number(r.archived)} حركة ستبقى مؤرشفة. يُحفظ أثر إغلاق الهاتف ضمن حسابات التصنيف دون تغيير الإغلاق السنوي للخادم.`:'',
      r.addedCodes.length?`رموز عملات ستُضاف إلى قائمة العملات: ${r.addedCodes.join('، ')}.`:'',
      r.differingCodes.length?`تبقى تعريفات العملات الموجودة كما هي: ${r.differingCodes.join('، ')}.`:''].filter(Boolean);
    dial('تأكيد إضافة تصنيف خاص',`من «${r.source}» إلى «${r.name}»`,
      tip('لن تُستبدل أي سجلات أو صلاحيات. التصنيف خاص بالمالك عند إنشائه؛ لا يراه الموظفون إلا إذا منحتهم «عرض» لاحقًا.','','shield')+
      counts(r)+amounts+(notes.length?`<ul class="transfer-notes">${notes.map(n=>`<li>${h(n)}</li>`).join('')}</ul>`:'')+
      `<p class="small sub">تظل المراجعة صالحة لست دقائق ما لم يتغيّر الدفتر أو حساباته على الخادم. لا يُعاد طلب الحفظ تلقائيًا عند انقطاع الاتصال.</p>`+
      check('backupConfirmed','تحقّقت من حفظ ملف الاستعادة خارج الاستضافة وأحتفظ بعبارته بشكل منفصل.')+
      check('confirm','راجعت الأرصدة وأوافق على إضافة التصنيف الجديد وحده.'),async b=>{
        if(!b.confirm||!b.backupConfirmed)throw new Error('أكّد الأرصدة وحفظ ملف الاستعادة أولًا.');
        const result=await api('book/transfer-commit',{ticket,version,confirm:true,backupConfirmed:true});
        close();flash(`أضيف تصنيف «${result.summary.name}» دون منح وصول للموظفين.`);
        try{await refresh();}catch(e){if(e.code==='login')return clearSession('أضيف التصنيف. سجّل الدخول للتحقق منه.');flash('أضيف التصنيف. تعذّر تحديث العرض؛ اضغط تحديث ولا تكرّر النقل.',true);}
      },{submit:'إضافة التصنيف الآن',wide:true});
  }
  function action(id){
    if(!available())return;
    if(id==='recovery-export')return recoveryForm();
    if(id==='transfer-pick')return pick();
  }
  return {panel,action};
})();
