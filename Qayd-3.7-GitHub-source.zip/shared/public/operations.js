/* Shared-desk workspaces. All financial data and permissions come from the scoped server API. */
'use strict';
const DeskOps=(()=>{
  const states={overdue:'متأخر',today:'مستحق اليوم',week:'خلال 7 أيام',later:'بعد 7 أيام',unscheduled:'بلا موعد',followup:'متابعة مستحقة'};
  const followLabels={contacted:'تم التواصل',promise:'وعد بالسداد',review:'تحتاج مراجعة'};
  const bands=[['d30','1–30','يومًا'],['d60','31–60','يومًا'],['d90','61–90','يومًا'],['d91','91','يومًا فأكثر']];
  const auditKinds={'user-create':'فتح مستخدم فرعي','user-update':'تعديل الصلاحيات أو حالة المستخدم','user-reset':'تعيين كلمة سر مؤقتة','user-revoke':'إنهاء الجلسات','book-import':'استيراد نسخة قيد','category-transfer':'نقل تصنيف من الهاتف','recovery-export':'تجهيز ملف استعادة','owner-init':'إعداد المالك','owner-reset':'إعادة ضبط دخول المالك','password-change':'تغيير كلمة السر','mfa-enable':'تفعيل التحقق بخطوتين','mfa-disable':'إيقاف التحقق بخطوتين','mfa-console-reset':'إعادة ضبط التحقق من الخادم','mfa-recovery':'دخول برمز استرداد','account-add':'إضافة حساب','account-edit':'تعديل حساب','account-delete':'حذف حساب فارغ','movement-add':'إضافة حركة','movement-edit':'تعديل حركة','movement-delete':'حذف حركة','collection-followup':'تغيير متابعة التحصيل','category-add':'إضافة تصنيف','category-edit':'تعديل تصنيف'};
  let plan=null;
  const clear=()=>{plan=null;};
  const dateText=v=>v?bdi(v):'—';
  const values=(row,parts)=>`<dl class="age-values">${parts.map(([k,t])=>`<div><dt>${h(t)}</dt><dd class="${k==='overdue'&&row[k]?'neg':''}">${bdi(money(row[k]))}</dd></div>`).join('')}</dl>`;
  const buckets=[['overdue','متأخر'],['today','اليوم'],['week','7 أيام قادمة'],['later','لاحقًا'],['unscheduled','بلا موعد']];
  function collectionPage(){
    const f=s.f,r=s.collection,z=r.sums,reports=rights('reports'),canExport=rights('exportCsv').some(c=>f.category==='*'||c.id===f.category);
    const range=r.asOf!==r.today?'لقطة أرصدة سابقة · لا تتضمن المتابعة الحالية':'متاح لتسجيل القبض والمتابعات حسب الصلاحية';
    const queue=r.rows.map(row=>`<article class="age-card" data-collection="${h(row.id)}"><div class="row apart age-card-head"><div class="profile-name min0">${tint(row.overdue?'clock':'wallet',row.overdue?'red':'green')}<div class="min0"><strong class="wrap">${h(row.name)}</strong><small class="cell-sub">${h(row.categoryName)}${row.firstDue?' · أقرب استحقاق '+bdi(row.firstDue):''}</small></div></div><div class="age-total">${bdi(money(row.total))} <small>${h(r.code)}</small></div></div>${values(row,buckets)}<div class="row apart age-card-foot"><span>${row.followup?badge(followLabels[row.followup.kind],row.followup.day&&row.followup.day<=r.today?'warn':'neutral')+(row.followup.day?' '+dateText(row.followup.day):''):row.oldestDays?badge(`أقدم تأخر: ${number(row.oldestDays)} يومًا`,'warn'):badge(row.unscheduled===row.total?'لم يُحدد موعد':'حسب تاريخ الرصد','neutral')}</span>${btn('عرض تفاصيل الذمة','aging-detail','arrowLeft','outline slim',idattr(row.id))}</div></article>`).join('');
    return head('التحصيل','راجع المبالغ المتبقية، أعمار التأخر وخطة المتابعة حسب التصنيف والعملة.',(canExport?btn('تنزيل أعمار الذمم CSV','aging-csv','download','outline'):'')+codeSelect(),'إدارة الذمم')+
      grid([metric('إجمالي المتبقي',money(z.total),`${number(z.accounts)} حساب · ${r.code}`,'wallet'),metric('المبالغ المتأخرة',money(z.overdue),`${number(z.lateAccounts)} حساب · ${r.code}`,'clock','red'),metric('اليوم وخلال 7 أيام',money(z.today+z.week),r.code,'calendar','green')])+
      `<section class="panel">${panelHeader('أعمار المتأخرات',`الرصد حتى ${r.asOf} · ${range}`)}<div class="pane-content age-bands">${bands.map(([k,n,u])=>`<div><span><bdi dir="ltr">${h(n)}</bdi> ${h(u)}</span><strong>${bdi(money(z[k]))}</strong><progress aria-label="${h(n+' '+u)}" max="${Math.max(1,z.overdue)}" value="${z[k]}"></progress></div>`).join('')}</div></section>
      <section class="panel">${panelHeader('قائمة التحصيل',`${number(r.total)} حساب مطابق · دون خلط العملات`)}<form id="filters" class="filter age-filter">${sel('category','التصنيف',scopeOptions(reports,f.category))}${fld('q','بحث باسم الحساب',f.q,{type:'search',attrs:'maxlength="140"'})}${sel('state','حالة التحصيل',opt('','جميع الحالات',f.state)+Object.entries(states).map(([k,v])=>opt(k,v,f.state)).join(''))}${fld('asOf','حتى تاريخ (اختياري)',f.asOf,{type:'date',attrs:`max="${h(r.today)}"`,ltr:true})}${btn('تطبيق','','filter','outline')}</form>
      <div class="pane-content age-list">${queue||empty('لا ذمم مطابقة','جرّب تغيير التصنيف أو التاريخ أو البحث أو العملة.','wallet')}${tip('تُطبّق التخصيصات أولًا، ثم تُخصم بقية الدفعات من أقدم القيود. المبالغ بلا موعد لا تُحسب ضمن التأخر.','','info')}</div>${r.total>r.limit?pageFooter(r.offset,r.total,'aging-page',r.limit):''}</section>`;
  }
  async function collectionDetail(id,offset=0){
    const p=await api('collection/detail?'+query({account:id,asOf:s.f.asOf,offset})),row=p.row;
    const currency=`${money(row.total)} ${p.code}`,current=p.asOf===p.today;
    const info=row.followup?`<section class="age-note"><strong>${h(followLabels[row.followup.kind])}</strong>${row.followup.day?` · ${dateText(row.followup.day)}`:''}${row.followup.note?`<p class="wrap" dir="auto">${h(row.followup.note)}</p>`:''}</section>`:current?tip('لا متابعة مسجلة لهذا الحساب والعملة.','','info'):'';
    const items=p.items.length?`<ul class="age-items">${p.items.map(e=>`<li><div class="min0"><strong>${h(e.transfer?'طرف تحويل':'قيد موجب')} · ${bdi(e.day)}</strong><small class="cell-sub">${h(states[e.key])}${e.due?' · '+dateText(e.due):''}</small>${e.memo?`<p class="wrap" dir="auto">${h(e.memo)}</p>`:''}</div><div class="age-item-number"><strong>${bdi(money(e.open))}</strong><small>من ${bdi(money(e.original))}</small>${row.post?btn('قبض لهذا القيد','aging-receipt','wallet','outline slim',idattr(e.id)):''}</div></li>`).join('')}</ul>`:empty('لا مبلغ متبقٍ','لا يوجد قيد مفتوح في تاريخ الرصد والعملة.','check');
    dial('تفاصيل الذمة',`${row.name} · ${currency}`,values(row,buckets)+info+items+(p.total>p.limit?pageFooter(p.offset,p.total,'aging-detail-page',p.limit):''),null,{wide:true,foot:(row.manage?btn('ضبط المتابعة','aging-followup','calendar','outline'):'')+(row.post&&row.total>0?btn('تسجيل قبض','aging-receipt','wallet','primary'):'')});
    plan=p;
  }
  function followupForm(p){
    if(!p?.row.manage)return;
    const row=p.row,f=row.followup;
    dial('متابعة التحصيل',`${row.name} · ${p.code}`,tip('تظهر المتابعة لزملائك الذين لديهم صلاحية التقارير على التصنيف. لا يُرسل هذا الحفظ أي رسالة.')+
      `<div class="fields">${sel('kind','حالة المتابعة',opt('','دون متابعة',f?.kind||'')+Object.entries(followLabels).map(([k,v])=>opt(k,v,f?.kind)).join(''))}${day('day','موعد المتابعة (اختياري)',f?.day||'')}${memo('note','ملاحظة للفريق',f?.note||'',260)}</div>`,b=>bookChange('collection-followup',row.id,{code:p.code,kind:b.kind,day:b.kind?b.day:'',note:b.kind?b.note:''},p.version),{submit:'حفظ المتابعة',posting:true});
  }
  function receiptForm(p,target){
    if(!p?.row.post||!p.row.total)return;
    const item=target?p.items.find(x=>x.id===target):null;
    if(target&&!item)return;
    dial('تسجيل قبض',`${p.row.name} · ${p.code}`,sharedDestination()+tip(item?`سيُخصص القبض للقيد المحدد. المتبقي ${money(item.open)} ${p.code}.`:`المتبقي في تاريخ الرصد ${money(p.row.total)} ${p.code}. يُوزّع القبض على أقدم القيود المفتوحة.`)+
      `<div class="fields">${fld('amount','مبلغ القبض',item?Ledger.inputDecimal(item.open):'',{attrs:'required inputmode="decimal" maxlength="28"',ltr:true})}${fld('day','تاريخ القبض',p.today,{type:'date',attrs:`required max="${h(p.today)}"`,ltr:true})}${sel('method','طريقة القبض',Object.entries(methods).map(([k,v])=>opt(k,v,'cash')).join(''))}${fld('reference','المرجع (اختياري)','',{attrs:'maxlength="90" dir="auto"'})}${memo('memo','البيان','')}</div>`,f=>bookChange('movement-add',undefined,{...f,kind:'receipt',code:p.code,account:p.row.id,target:item?.id||''},p.version),{submit:'إصدار سند في الدفتر المشترك',wide:true,posting:true});
  }
  function auditPanel(){
    const f=s.f,a=s.audit;
    return `<section class="panel">${panelHeader('سجل التدقيق',`${number(a.total)} عملية مطابقة · يعرض أحدث 1,000 حدث محفوظ`)}
      <form id="filters" class="filter audit-filter">${fld('q','بحث باسم المستخدم أو العملية',f.q,{type:'search',attrs:'maxlength="140"'})}${sel('type','نوع العملية',opt('','جميع العمليات',f.type)+Object.entries(auditKinds).map(([k,v])=>opt(k,v,f.type)).join(''))}${day('from','من تاريخ',f.from)}${day('to','إلى تاريخ',f.to)}${btn('بحث في السجل','','filter','outline')}</form>
      <div class="pane-content">${a.rows.length?`<ul class="record-list audit-list">${a.rows.map(x=>`<li>${tint(x.kind.startsWith('user-')||x.kind.startsWith('mfa-')?'shield':'clock')}<div class="min0 grow"><strong>${h(auditKinds[x.kind]||'تحديث')}</strong><small class="cell-sub wrap">${h(x.actor)}${x.subject?' · '+h(x.subject):''}</small><time>${h(shortDay(x.at))}</time></div>${x.versions?btn('عرض التغيير','audit-compare','moves','outline slim',idattr(x.id)):''}</li>`).join('')}</ul>`:empty('لا عمليات مطابقة','عدّل عوامل البحث أو التاريخ.','clock')}</div>${a.total>a.limit?pageFooter(a.offset,a.total,'audit-page',a.limit):''}</section>`;
  }
  function compare(id){
    const x=s.audit.rows.find(y=>y.id===id);if(!x?.versions)return;
    const stack=(title,v)=>`<article class="audit-side"><h3>${h(title)}</h3>${v?`<dl><dt>التاريخ والوقت</dt><dd>${bdi(v.day)} · ${bdi(v.time)}</dd><dt>المبالغ الموقّعة</dt><dd>${v.legs.map(l=>`<p class="wrap">${h(l.name)} · <strong class="${l.minor<0?'neg':'pos'}">${bdi(money(l.minor))} ${h(l.code)}</strong></p>`).join('')}</dd><dt>الاستحقاق</dt><dd>${dateText(v.due)}</dd><dt>البيان</dt><dd class="wrap" dir="auto">${h(v.memo||'—')}</dd>${v.receipt?`<dt>سند القبض</dt><dd>${bdi(Ledger.receiptNumber(v.receipt.number))} · ${h(methods[v.receipt.method]||'')}</dd>`:''}</dl>`:'<p class="sub">لا يوجد قيد في هذه الحالة.</p>'}</article>`;
    dial('مقارنة القيد قبل وبعد',`${x.actor} · ${shortDay(x.at)}`,`<div class="audit-compare">${stack('قبل التغيير',x.versions.before)}${stack('بعد التغيير',x.versions.after)}</div>`,null,{wide:true});
  }
  const otpField=(label='رمز تطبيق المصادقة أو رمز استرداد',required=true)=>fld('otp',label,'',{attrs:`${required?'required ':''}maxlength="30" autocomplete="one-time-code" autocapitalize="characters" spellcheck="false"`,ltr:true});
  const current=()=>fld('current','كلمة سر المالك','',{type:'password',attrs:'required maxlength="128" autocomplete="current-password"',ltr:true});
  function securityPanel(){
    const button=s.demo?'':s.me.mfa?btn('إيقاف التحقق','mfa-disable','lock','outline'):btn('فعّل التحقق بخطوتين','mfa-start','shield','primary');
    return `<section class="panel security-panel">${panelHeader('أمان حساب المالك',s.demo?'التفعيل متاح في الدفتر الحقيقي عبر HTTPS.':'أضف رمزًا من تطبيق المصادقة إلى كلمة السر.',s.demo?badge('معاينة','warn'):badge(s.me.mfa?'مفعّل':'غير مفعّل',s.me.mfa?'ok':'warn'))}<div class="pane-content cluster"><p class="sub small">${s.me.mfa?'احتفظ برموز الاسترداد خارج هذا الجهاز. يُقبل كل رمز استرداد مرة واحدة.':'يدعم قيد رموز المصادقة الزمنية (ستة أرقام) دون خدمة إرسال أو رقم هاتف.'}</p>${button?`<div class="row">${button}</div>`:''}</div></section>`;
  }
  async function startMfa(){
    dial('تفعيل التحقق بخطوتين','أعد إدخال كلمة السر قبل إنشاء مفتاح الإعداد.',current(),async f=>{
      const p=await api('mfa/start',{current:f.current});
      dial('ربط تطبيق المصادقة','أضف حسابًا يدويًا في تطبيق المصادقة، واختر «رمز يعتمد على الوقت».',
        fld('accountLabel','اسم الحساب في تطبيق المصادقة',`Qayd · ${p.login}`,{attrs:'readonly',ltr:true})+fld('seed','مفتاح الإعداد',p.secret,{attrs:'readonly autocomplete="off" spellcheck="false"',ltr:true})+otpField('الرمز الحالي (6 أرقام)')+
        tip('المفتاح سرّي ويظهر في هذه الجلسة لمدة 10 دقائق. لا تشاركه. يُنهي التفعيل جلسات المالك الأخرى.','warn','info'),async b=>{
          const r=await api('mfa/enable',{setup:p.setup,otp:b.otp});s.me=r.me;
          dial('احفظ رموز الاسترداد','يمكنك استخدام رمز واحد بدل رمز التطبيق إذا فقدت الوصول إليه.',tip('لن تُعرض الرموز ثانية. احفظها خارج هذا الجهاز، ولا ترسلها لأحد.','warn','info')+
            `<ol class="recovery-list" dir="ltr">${r.recovery.map(x=>`<li><code>${h(x)}</code></li>`).join('')}</ol>`,null,{foot:btn('نسخ الرموز','copy-recovery','copy','outline')});
          await refresh();
        },{submit:'التحقق والتفعيل'});
    },{submit:'إنشاء مفتاح الإعداد'});
  }
  function disableMfa(){
    dial('إيقاف التحقق بخطوتين','سيعود الدخول إلى كلمة السر وحدها، وتُنهى جلسات المالك الأخرى.',current()+otpField(),async f=>{
      const r=await api('mfa/disable',{current:f.current,otp:f.otp});close();await logged(r,s.page);flash('أُوقف التحقق بخطوتين.');
    },{submit:'إيقاف التحقق',danger:true});
  }
  function about(){
    const r=QaydRelease;
    dial('عن قيد والدعم','دفتر الذمم العربي · الدفتر المشترك',`<div class="desk-credits"><img src="${embedded?'':'/'}assets/logo.svg" width="52" height="52" alt=""><div><strong>قيد <bdi>${h(r.version)}</bdi></strong><p>${h(r.rights)}</p></div></div>`+
      fld('support','الدعم والتواصل · '+r.owner,r.phone,{attrs:'readonly',ltr:true})+tip('لا تُرفق سجلات العملاء عند التواصل ما لم تختر ذلك.','','info'),null,{foot:(embedded?'':`<a class="btn outline" href="tel:${h(r.phone)}">${icon('phone',16)}فتح شاشة الاتصال</a>`)+btn('نسخ رقم التواصل','copy-support','copy','outline')});
  }
  async function copyText(text,input=null){
    try{await navigator.clipboard.writeText(text);feedback('تم النسخ.');}
    catch{if(input){input.focus();input.select();}feedback('لم يُتح النسخ التلقائي؛ يمكنك نسخ النص يدويًا.');}
  }
  async function action(b){
    const {action:id,id:target,step}=b.dataset;
    switch(id){
      case 'aging-detail':return collectionDetail(target);
      case 'aging-page':s.f.offset=Math.max(0,s.collection.offset+Number(step)*s.collection.limit);return refresh();
      case 'aging-detail-page':if(plan)return collectionDetail(plan.row.id,Math.max(0,plan.offset+Number(step)*plan.limit));return;
      case 'aging-followup':return followupForm(plan);
      case 'aging-receipt':return receiptForm(plan,target);
      case 'aging-csv':await saveBlob(await api('collection.csv?'+query(s.f),undefined,'blob'),`qayd-aging-${s.code}-${s.collection.asOf}.csv`);return;
      case 'audit-page':s.f.offset=Math.max(0,s.audit.offset+Number(step)*s.audit.limit);return refresh();
      case 'audit-compare':return compare(target);
      case 'mfa-start':return startMfa();
      case 'mfa-disable':return disableMfa();
      case 'copy-recovery':return copyText(q('.recovery-list code',dlg).map(x=>x.textContent).join('\n'));
      case 'copy-support':return copyText(QaydRelease.phone,$('[name=support]',dlg));
      case 'about':return about();
    }
  }
  return {clear,collectionPage,auditPanel,securityPanel,otpField,action};
})();

// Account selection for posting. Index only accounts returned with addMovement
// permission, and require a deliberate selection before sending a record ID.
const DeskPicker=(()=>{
  const pickers=new WeakMap(),lookup=el=>el&&pickers.get(el.closest('[data-post-picker]')),order=new Intl.Collator('ar',{numeric:true});
  function field(name,label,list,selected){
    const a=list.find(x=>x.id===selected),id='post-'+name;
    return `<div class="post-picker" data-post-picker="${h(name)}">
      <label class="field" for="${id}">${h(label)}<input id="${id}" data-account-query type="search" required maxlength="90" value="${h(a?.name||'')}" dir="auto" autocomplete="off" spellcheck="false" placeholder="ابحث بالاسم أو رقم الهاتف" role="combobox" aria-autocomplete="list" aria-expanded="false" aria-controls="${id}-options" aria-describedby="${id}-hint"></label>
      <input type="hidden" name="${h(name)}" value="${h(a?.id||'')}">
      <p class="small sub post-picker-hint" id="${id}-hint" aria-live="polite">${a?`مختار · ${h(catName(a.category))}`:'اختر من الحسابات التي يمكنك التسجيل فيها.'}</p>
      <div class="post-options" id="${id}-options" role="listbox" aria-label="${h(label)}" hidden></div>
    </div>`;
  }
  function hide(p){
    if(!p)return;
    p.options.hidden=true;p.active=-1;p.input.removeAttribute('aria-activedescendant');p.input.setAttribute('aria-expanded','false');
  }
  function show(p){
    if(!p||p.input.disabled)return;
    const needle=Ledger.searchKey(p.input.value).replace(/\s+/g,' '),digits=needle.replace(/[\s()+-]/g,'');
    const byPhone=/^[0-9]+$/.test(digits),hits=[],others=[];let total=0;
    for(const a of p.list){
      if(!needle||a.key.startsWith(needle)){total++;if(hits.length<8)hits.push(a);}
      else if(a.key.includes(needle)||(byPhone&&a.digits.includes(digits))){total++;if(others.length<8)others.push(a);}
    }
    p.matches=hits.concat(others.slice(0,8-hits.length));p.active=-1;
    p.input.removeAttribute('aria-activedescendant');p.input.setAttribute('aria-expanded',String(!!total));
    p.hint.textContent=total?`اختر الحساب · ${number(total)} مطابق${total>8?'، اكتب المزيد لتضييق البحث':''}`:'لا يوجد حساب مطابق يمكنك التسجيل فيه.';
    p.options.hidden=!total;
    p.options.innerHTML=p.matches.map((a,i)=>`<button type="button" class="post-option" id="${p.input.id}-choice-${i}" data-option="${i}" role="option" tabindex="-1" aria-selected="false"><strong dir="auto">${h(a.name)}</strong><small>${h(a.categoryName)}</small></button>`).join('');
  }
  function indicate(p){
    const a=p.byId.get(p.value.value);
    p.hint.textContent=a?`مختار · ${a.categoryName}`:'ابحث واختر الحساب من النتائج.';
  }
  function choose(p,index){
    const a=p.matches[index];if(!a)return;
    p.value.value=a.id;p.input.value=a.name;p.input.removeAttribute('aria-invalid');indicate(p);hide(p);
    const next=p.value.name==='from'?'#post-to':'[name="amount"]';$(next,dlg)?.focus();
  }
  function mount(list){
    const names=new Map(categories().map(c=>[c.id,c.name]));
    const index=list.map(a=>({id:a.id,name:a.name,categoryName:names.get(a.category)||'بلا تصنيف',key:Ledger.searchKey(a.name).replace(/\s+/g,' '),digits:Ledger.searchKey(a.phone||'').replace(/\D/g,'')})).sort((a,b)=>order.compare(a.name,b.name));
    const byId=new Map(index.map(a=>[a.id,a]));
    for(const el of q('[data-post-picker]',dlg)){
      const p={input:$('[data-account-query]',el),value:$('[type=hidden]',el),hint:$('.post-picker-hint',el),options:$('.post-options',el),list:index,byId,matches:[],active:-1};
      pickers.set(el,p);
      p.input.addEventListener('focus',()=>{if(!p.value.value)show(p);});
      p.input.addEventListener('input',()=>{p.value.value='';p.input.removeAttribute('aria-invalid');show(p);});
      el.addEventListener('focusout',e=>{if(!el.contains(e.relatedTarget)){hide(p);indicate(p);}});
      p.options.addEventListener('mousedown',e=>{if(e.target.closest('[data-option]'))e.preventDefault();});
      p.options.addEventListener('click',e=>{const b=e.target.closest('[data-option]');if(b)choose(p,Number(b.dataset.option));});
      p.input.addEventListener('keydown',e=>{
        if(e.isComposing)return;
        if(e.key==='Escape'&&!p.options.hidden){e.preventDefault();hide(p);indicate(p);return;}
        if(e.key==='Enter'&&!p.value.value){
          e.preventDefault();
          if(!p.options.hidden&&(p.active>=0||p.matches.length===1))choose(p,p.active>=0?p.active:0);else show(p);
          return;
        }
        if(!['ArrowDown','ArrowUp'].includes(e.key))return;
        e.preventDefault();if(p.options.hidden)show(p);if(!p.matches.length)return;
        const n=p.matches.length,down=e.key==='ArrowDown';p.active=p.active<0?(down?0:n-1):(p.active+(down?1:-1)+n)%n;
        q('[role=option]',p.options).forEach((item,i)=>{
          item.setAttribute('aria-selected',String(i===p.active));
          if(i===p.active){p.input.setAttribute('aria-activedescendant',item.id);item.scrollIntoView({block:'nearest'});}
        });
      });
    }
  }
  function valid(name,id){
    const p=lookup($('[name="'+name+'"]',dlg));
    if(p?.byId.has(id)&&p.byId.get(id).name===p.input.value&&!p.input.disabled)return true;
    if(p){p.input.setAttribute('aria-invalid','true');p.input.focus();show(p);}
    feedback('اختر الحساب من نتائج البحث قبل الحفظ.',!p);return false;
  }
  function escape(){
    const p=lookup(document.activeElement);if(!p||p.options.hidden)return false;hide(p);indicate(p);return true;
  }
  function hideGroup(group){q('[data-post-picker]',group).forEach(el=>hide(pickers.get(el)));}
  return {field,mount,valid,escape,hideGroup};
})();
