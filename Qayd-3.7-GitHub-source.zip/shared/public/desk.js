'use strict';
const embedded=window.QaydDeskTransport||null,employee=embedded?.employee===true;
const $=(s,r=document)=>r.querySelector(s),q=(s,r=document)=>[...r.querySelectorAll(s)],root=$('#root'),dlg=$('#dialog');
const h=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c]);
const bdi=s=>`<bdi>${h(s)}</bdi>`,nf=new Intl.NumberFormat('en',{maximumFractionDigits:3}),number=n=>nf.format(n),money=n=>number(n/Ledger.SCALE);
const shortDay=at=>new Intl.DateTimeFormat('ar-YE-u-ca-gregory-nu-latn',{dateStyle:'medium',timeStyle:'short',...(s.timezone?{timeZone:s.timezone}:{})}).format(new Date(at));
const s={demo:false,ops:{},capabilities:{},timezone:'',token:'',realm:new URL(location.href).searchParams.get('demo')||'',me:null,desk:null,page:'home',code:'',f:{},rows:null,report:null,collection:null,users:[],audit:null};
let busy=false, submitModal=null, noticeTimer, acctPage=0, dbLoader=null, syncAt=0, syncStale=false, consent=false, autoTried=false;
let quickPost=embedded?.quickPost===true&&!employee, writeState='', reviewHint=null, reviewReady=false;
const noticeKey='qayd.shared.write-notice.v1';
function readWriteState(){
  try{const value=embedded?embedded.readWriteNotice():sessionStorage.getItem(noticeKey);return ['uncertain','saved'].includes(value)?value:'';}
  catch{return '';}
}
function setWriteState(state){
  writeState=state;if(state!=='uncertain'){reviewReady=false;reviewHint=null;}
  if(s.demo)return;
  try{
    if(embedded)embedded.writeWriteNotice(state);
    else if(state)sessionStorage.setItem(noticeKey,state);
    else sessionStorage.removeItem(noticeKey);
  }catch{/* Do not store any form data. The in-memory guard remains active. */}
}
const labels={home:['نظرة عامة','home'],accounts:['الحسابات','accounts'],movements:['الحركات','moves'],collection:['التحصيل','wallet'],reports:['التقارير','report'],users:['المستخدمون الفرعيون','people'],book:['إعدادات الدفتر','settings'],more:['المزيد','more']};
const primaryPages=['home','accounts','movements','more'];
const kinds={credit:'لي',debit:'عليّ',transfer:'تحويل',isolated:'طرف تحويل',receipt:'سند قبض'};
const methods={cash:'نقدًا',bank:'تحويل بنكي',wallet:'محفظة',check:'شيك',other:'أخرى'};
const btn=(text,action='',ic='',cls='outline',attrs='')=>`<button type="${action?'button':'submit'}" class="btn ${h(cls)}" ${action?`data-action="${h(action)}"`:''} ${attrs}>${ic?icon(ic,16):''}${h(text)}</button>`;
const ib=(label,act,ic,attrs='')=>btn('',act,ic,'outline icon-btn',`aria-label="${h(label)}" title="${h(label)}" ${attrs}`);
const tint=(ic,t='',color='')=>`<span class="tint ${h(t)}" ${color?`data-color="${h(color)}"`:''}>${icon(ic,18)}</span>`;
const badge=(txt,t='')=>`<span class="badge ${h(t)}">${h(txt)}</span>`;
const tip=(txt,t='',ic='shield')=>`<div class="tip ${h(t)}">${icon(ic,16)}<span>${h(txt)}</span></div>`;
const fld=(name,label,val='',{type='text',attrs='',ltr=false,span=false}={})=>`<label class="field ${span?'span':''}">${h(label)}<input name="${h(name)}" type="${h(type)}" value="${h(val)}" ${ltr?'dir="ltr"':''} ${attrs}></label>`;
const memo=(name,label,val='',max=600)=>`<label class="field span">${h(label)}<textarea name="${h(name)}" maxlength="${max}" dir="auto">${h(val)}</textarea></label>`;
const opt=(val,text,v)=>`<option value="${h(val)}" ${val===v?'selected':''}>${h(text)}</option>`;
const sel=(name,label,options,attrs='')=>`<label class="field">${h(label)}<select name="${h(name)}" ${attrs}>${options}</select></label>`;
const empty=(title,txt,ic='folder',action='')=>`<div class="empty">${tint(ic)}<h3>${h(title)}</h3><p>${h(txt)}</p>${action}</div>`;
const head=(t,txt,actions='',eyebrow='الدفتر المشترك')=>`<div class="head"><div class="min0">${eyebrow?`<p class="cap">${h(eyebrow)}</p>`:''}<h1>${h(t)}</h1>${txt?`<p>${h(txt)}</p>`:''}</div>${actions?`<div class="row">${actions}</div>`:''}</div>`;
const panelHeader=(t,txt='',a='')=>`<div class="pane-head"><div><h2>${h(t)}</h2>${txt?`<p>${h(txt)}</p>`:''}</div>${a}</div>`;
const metric=(t,v,n,ic,tone='')=>`<article class="metric"><div class="row"><span>${h(t)}</span>${tint(ic,tone)}</div><strong>${bdi(v)}</strong><small>${h(n)}</small></article>`;
const grid=rows=>`<div class="metrics">${rows.join('')}</div>`;
const day=(name,label,val='')=>fld(name,label,val,{type:'date',ltr:true});
const brand=()=>`<span class="brand"><img src="${embedded?'':'/'}assets/logo.svg" alt=""><span><strong>قيد</strong><small>الدفتر المشترك</small></span></span>`;
const connection=()=>embedded?`<div class="app-connection"><strong>${employee?'دفتر مديرك · اتصال HTTPS':'الدفتر المشترك · اتصال HTTPS'}</strong><bdi>${h(embedded.origin)}</bdi><span>${employee?'تحقّق أن الرابط هو نفسه الذي أرسله إليك المدير.':'حسابات وحركات دفتر الهاتف لا تظهر هنا تلقائيًا.'}</span></div>`:'';
const returnLocal=()=>employee?btn('تغيير رابط المدير','desk-link','settings','text'):embedded?btn('دفتر الهاتف','leave-desk','arrowRight','text'):'';
const kept=()=>employee&&embedded.kept();
const rememberField=(checked=false)=>!employee?'':embedded.canRemember()?`<label class="remember-check"><input type="checkbox" name="remember" ${checked?'checked':''}><span><strong>احفظ دخولي على هذا الهاتف</strong><small>يُحفظ مشفّرًا لحساب الموظف ورابط المدير هذا فقط. اختره على جهازك الشخصي.</small></span></label>`:tip('لتفعيل حفظ الدخول، فعّل قفل شاشة الهاتف. يمكنك الدخول الآن دون حفظ.','','lock');
const savedControls=()=>kept()?`<div class="row saved-controls">${btn('الدخول المحفوظ','desk-saved','lock','outline')}${btn('حذف الدخول المحفوظ','desk-forget','trash','text')}</div>`:'';
const syncLabel='العرض غير محدّث. تحقّق من الاتصال ثم اضغط تحديث.';
function syncMark(stale){if(!embedded)return;syncStale=stale;if(!stale)syncAt=Date.now();const el=$('.sync-strip');if(el)el.hidden=!stale;}
const idattr=id=>`data-id="${h(id)}"`;
const categories=()=>s.desk?.categories||[];
const accounts=()=>s.desk?.accounts||[];
const getCategory=id=>categories().find(c=>c.id===id);
const rights=(key,cats=categories())=>cats.filter(c=>c.allow.includes(key));
const can=(cat,key)=>getCategory(cat)?.allow.includes(key)===true;
const rowAccount=id=>accounts().find(a=>a.id===id);
const postable=()=>accounts().filter(a=>a.post);
const catName=id=>getCategory(id)?.name||'بلا تصنيف';
const scopeOptions=(list=categories(),selected='*',all=true)=>`${all?opt('*','جميع التصنيفات المتاحة',selected):''}${list.map(c=>opt(c.id,c.name,selected)).join('')}`;
const role=()=>s.me?.owner?'المالك':'مستخدم فرعي';
const alerts=()=>'<p id="gate-error" class="error" role="alert" hidden></p>';
function flash(message,error=false){
  $('#notice').innerHTML=`<p class="${error?'err':''}">${h(message)}</p>`;clearTimeout(noticeTimer);noticeTimer=setTimeout(()=>$('#notice').replaceChildren(),5000);
}
function feedback(msg,scroll=true){const e=(dlg.open&&$('#dialog-error'))||$('#gate-error');if(!e)return flash(msg,true);e.textContent=msg;e.hidden=false;if(scroll)e.scrollIntoView({block:'nearest'});}
function writeNotice(controls=false){
  const unsure=writeState==='uncertain';
  return `<div id="write-notice" class="write-notice" ${writeState?`data-state="${h(writeState)}"`:'hidden'} tabindex="-1" aria-label="نتيجة الحفظ">${writeState?`<div class="write-notice-line">${tint(unsure?'info':'check',unsure?'':'green')}<div role="status"><strong>${unsure?'لم يتأكد الحفظ':'حُفظ التغيير في الدفتر المشترك'}</strong><p>${unsure?(reviewReady?'قارن السجل بالحركة المقصودة قبل المتابعة. إذا بقيت النتيجة غير واضحة، لا تكرّر التسجيل.':'قد يكون التغيير وصل إلى الخادم. راجع السجل قبل إعادة التسجيل؛ لن يعيد قيد إرسال الطلب.'):'لم يُحدّث العرض بعد. حدّث البيانات ولا تكرّر الحفظ.'}</p></div></div>${controls?`<div class="row">${btn(unsure?'تحديث ومراجعة السجل':'تحديث البيانات',unsure?'review-write':'refresh', 'undo','outline')}${unsure&&reviewReady?btn('راجعت الدفتر','ack-write','check','primary'):''}</div>`:''}`:''}</div>`;
}
function paintWriteNotice(focus=false){
  const node=$('#write-notice');if(!node)return;
  node.outerHTML=writeNotice(!!s.desk&&!!s.me&&!s.me.mustChange);if(focus)$('#write-notice')?.focus();
}
function guardWrite(){
  if(!writeState)return true;
  if(dlg.open)close();paintWriteNotice(true);return false;
}
async function reviewWrite(){
  if(writeState!=='uncertain')return;
  reviewReady=false;paintWriteNotice();
  const old={page:s.page,code:s.code,f:s.f},hint=reviewHint||{page:'movements'};
  s.page=hint.page;s.code=hint.code||s.code;s.f={...resetFilter(),...(hint.account?{account:hint.account}:{}),...(hint.day?{from:hint.day,to:hint.day}:{})};
  try{await refresh();}catch(e){Object.assign(s,old);throw e;}
  reviewReady=true;paintWriteNotice(true);
}
function acknowledgeWrite(){
  if(writeState!=='uncertain'||!reviewReady)return;
  setWriteState('');paintWriteNotice();flash('انتهت مراجعة نتيجة الحفظ.');
}
class ApiError extends Error{
  constructor(status,json){
    super(typeof json?.error==='string'&&json.error?json.error:'تعذّر إتمام الطلب.');this.status=status;
    this.code=typeof json?.code==='string'?json.code:'';
    this.structured=typeof json?.code==='string'&&typeof json.error==='string'&&!!json.error;
  }
}
async function api(path,body,mode='json',passive=false,remember=false){
  if(embedded){
    const {status,data}=await embedded.request(path,body,passive,remember);
    if(status<200||status>=300)throw new ApiError(status,data);
    // Preserve the UTF-8 BOM when the native document picker saves a CSV.
    return mode==='blob'?data.csv:data;
  }
  const headers={...(s.token?{Authorization:'Bearer '+s.token}:{}),...(passive?{'X-Qayd-Passive':'1'}:{})};
  if(body!==undefined)Object.assign(headers,{'Content-Type':'application/json','X-Qayd-Client':'desk-v1'});
  // Bound ordinary ledger writes and view reads. Timing out a POST never proves it failed.
  const controller=new AbortController(),bounded=path==='book/change'||(body===undefined&&mode==='json'&&path!=='book/backup');
  const timer=bounded?setTimeout(()=>controller.abort(),30000):null;
  try{
    const res=await fetch('/api/'+path,{method:body===undefined?'GET':'POST',headers,body:body===undefined?undefined:JSON.stringify(body),credentials:'same-origin',cache:'no-store',redirect:'error',signal:controller.signal});
    const jsonType=/^application\/json(?:\s*;|$)/i.test(res.headers.get('Content-Type')||'');
    if(!res.ok){let json={};if(jsonType){try{json=await res.json();}catch{}}throw new ApiError(res.status,json);}
    if(mode==='blob')return await res.blob();
    const data=jsonType?await res.json():null;
    if(!data||typeof data!=='object'||Array.isArray(data))throw new Error('protocol');
    return data;
  }catch(e){
    if(e instanceof ApiError)throw e;
    throw new ApiError(0,{code:'network',error:'لم يصل رد صالح من الخادم. تحقّق من الاتصال ثم حدّث الدفتر.'});
  }finally{clearTimeout(timer);}
}
function dial(title,sub,body,fn,{submit='حفظ',danger=false,wide=false,foot='',posting=false}={}){
  DeskOps.clear();submitModal=fn||null;dlg.classList.toggle('compact',!wide);
  dlg.innerHTML=`<div class="modal-head"><div class="min0"><h2 id="dialog-title">${h(title)}</h2>${sub?`<p>${h(sub)}</p>`:''}</div>${ib('إغلاق','close','close')}</div>
    ${fn?`<form id="dialog-form" ${posting?'data-posting':''}>`:''}<div class="dialog-body">${body}<p class="error" id="dialog-error" role="alert" hidden></p>${posting?'<div class="row" id="book-rejected-actions" hidden>'+btn('إغلاق وتحديث البيانات','refresh-rejected','undo','outline')+'</div>':''}</div>
    <div class="modal-foot">${foot}${btn(fn?'إلغاء':'إغلاق','close')}${fn?btn(submit,'',danger?'trash':'check',danger?'danger':'primary'):''}</div>${fn?'</form>':''}`;
  if(!dlg.open)dlg.showModal();dlg.scrollTop=0;
}
function close(){DeskOps.clear();submitModal=null;if(dlg.open)dlg.close();dlg.innerHTML='';}
function clearSession(msg=''){
  close();if(embedded){embedded.clear();syncAt=0;syncStale=false;consent=false;}
  reviewHint=null;reviewReady=false;
  Object.assign(s,{me:null,desk:null,token:'',page:'home',code:'',f:{},rows:null,report:null,collection:null,users:[],audit:null});renderGate();
  if(msg)flash(msg);
}
async function work(fn){
  if(busy){if(embedded)feedback('يجري اتصال بالدفتر. انتظر قليلًا ثم أعد الإجراء.');return;}busy=true;
  const buttons=q('button[type=submit]').filter(e=>!e.disabled);buttons.forEach(e=>e.disabled=true);
  const er=(dlg.open&&$('#dialog-error'))||$('#gate-error');if(er)er.hidden=true;
  try{await fn();}catch(e){
    if(e.code==='login'){clearSession('انتهت الجلسة. سجّل الدخول مجددًا.');}
    else if(e.code==='password-required'&&s.me){close();s.me.mustChange=true;renderGate();}
    else {if(embedded&&s.desk&&(e.code==='network'||!e.status||e.status>=500))syncMark(true);feedback((e.message||'تعذّر إتمام العملية.')+(embedded&&e.code==='stale'?' أغلق النافذة وحدّث الدفتر قبل إعادة الحفظ.':''));}
  }finally{busy=false;buttons.forEach(e=>{if(!e.form?.hasAttribute('data-rejected'))e.disabled=false;});}
}
function renderGate(){
  const changing=s.me?.mustChange;
  root.innerHTML=`<div class="gate simple-gate"><section class="gate-main"><div class="cluster">${brand()}
    <h2>${changing?'اختر كلمة سر جديدة':employee?'دخول الموظف':'الدخول إلى قيد'}</h2>${connection()}${writeNotice()}
    ${quickPost&&!changing?tip('سجّل الدخول أولًا لفتح نموذج حركة في الدفتر المشترك. لن يُرسل قيد دون حفظه من النموذج.','green','moves'):''}
    ${changing?'<p class="sub">غيّر كلمة السر المؤقتة لمرة واحدة.</p>':''}
    ${s.demo?tip('هذه تجربة مؤقتة مستقلة. لا تدخل بياناتك أو كلمات سرك الفعلية.','warn','info'):''}
    ${changing?`<form id="password-first">${passwordFields(true)}${alerts()}${btn('تعيين كلمة السر والدخول','','lock','primary wide')}</form>${btn('تسجيل الخروج','logout','arrowRight','text')}`:`<form id="login-form">
      ${fld('login','اسم الدخول','',{attrs:'required maxlength="32" autocomplete="username" autocapitalize="none"',ltr:true})}
      ${fld('password','كلمة السر','',{type:'password',attrs:'required maxlength="128" autocomplete="current-password"',ltr:true})}
      ${embedded?`<div class="row">${btn('لديّ رمز تحقق','desk-show-otp','shield','text','aria-controls="mfa-login" aria-expanded="false"')}</div>`:''}
      ${!s.demo?`<div id="mfa-login" hidden>${DeskOps.otpField(undefined,false)}<p class="small sub">أدخل الرمز من تطبيق المصادقة. في حال فقدته استخدم رمز استرداد غير مستعمل.</p></div>`:''}
      ${rememberField()}${alerts()}${btn('تسجيل الدخول','','lock','primary wide')}
      </form>${savedControls()}${s.demo?`<div class="gate-line"></div><div class="gate-actions">${btn('جرّب كمالك الدفتر','demo','spark','outline wide')}</div>`:''}`}
    <div class="gate-credit"><span>${h(QaydRelease.rights)}</span>${btn('عن قيد والدعم','about','info','text slim')}</div>
  ${embedded?`<div class="row">${returnLocal()}</div>`:''}</div></section></div>`;
}
function passwordFields(first=false){
  return fld('current',first?'كلمة السر المؤقتة':'كلمة السر الحالية','',{type:'password',attrs:'required maxlength="128" autocomplete="current-password"',ltr:true})+
    fld('password','كلمة السر الجديدة','',{type:'password',attrs:'required minlength="12" maxlength="128" autocomplete="new-password"',ltr:true})+
    fld('again','أعد كتابة كلمة السر','',{type:'password',attrs:'required minlength="12" maxlength="128" autocomplete="new-password"',ltr:true})+(s.me?.mfa?DeskOps.otpField():'')+rememberField(first?consent:kept());
}
async function logged(d,page='home'){
  s.me=d.me;s.page=!embedded&&!s.demo&&d.me.owner&&location.hash==='#maintenance'?'book':page;s.code='';s.f={};
  if(s.demo){s.token=d.token;s.realm=d.realm;const u=new URL(location.href);u.searchParams.set('demo',s.realm);history.replaceState(null,'',u.pathname+u.search);}
  if(s.me.mustChange){renderGate();return;}
  if(!embedded)return refresh();
  Object.assign(s,{desk:null,rows:null,report:null,collection:null,users:[],audit:null});
  await loadWorkspace();
  if(d.deviceSaveFailed&&s.me)flash('تم الدخول، لكن تعذّر حفظ كلمة السر بأمان على هذا الجهاز.',true);
}
async function loadWorkspace(){
  const loading=(message,failed=false)=>`<div class="loading app-boot">${brand()}${connection()}${writeNotice()}<p class="${failed?'error':''}" role="status">${h(message)}</p><div class="row">${failed?btn('إعادة تحميل الدفتر','desk-reload','undo','primary')+btn('تسجيل الخروج','logout','lock'):''}${returnLocal()}</div></div>`;
  root.innerHTML=loading('جارٍ تحميل الدفتر المشترك…');
  try{
    await refresh();
    if(quickPost){
      quickPost=false;if(writeState)return paintWriteNotice(true);
      if(postable().length)return movementForm(null);
      flash(s.me.owner?'أضف حسابًا في الدفتر المشترك قبل تسجيل حركة.':'لا يوجد حساب يسمح لك بإضافة حركة. راجع مدير الدفتر.',true);
    }
  }catch(e){
    if(e.code==='login')return clearSession('انتهت الجلسة. سجّل الدخول مجددًا.');
    if(e.code==='password-required'){s.me.mustChange=true;return renderGate();}
    root.innerHTML=loading(e.message||'لم يُحمّل الدفتر. تحقّق من الإنترنت.',true);
  }
}
const resetFilter=()=>({category:'*',account:'',q:'',from:'',to:'',type:'',state:'',asOf:'',offset:0});
function query(f,code=s.code){
  const p=new URLSearchParams(code?{code}:{});
  for(const k of ['category','account','q','from','to','offset','type','state','asOf']){
    if(k==='category'?(f[k]!==undefined&&f[k]!=='*'):!!f[k])p.set(k,f[k]);
  }
  return p.toString();
}
async function refresh(passive=false,retried=false){
  const params=s.code?'?code='+encodeURIComponent(s.code):'';
  const d=await api('desk'+params,undefined,'json',passive),me=d.me,f={...resetFilter(),...s.f};
  let page=s.page;
  const reports=d.categories.filter(c=>c.allow.includes('reports'));
  if((!me.owner&&['users','book'].includes(page))||(['reports','collection'].includes(page)&&!reports.length))page='home';
  if(f.category!=='*'&&!(['reports','collection'].includes(page)?reports:d.categories).some(c=>c.id===f.category))f.category='*';
  if(f.account&&!d.accounts.some(a=>a.id===f.account))f.account='';
  if(f.asOf===d.today)f.asOf='';
  if(f.asOf&&f.state==='followup')f.state='';
  const next={desk:d,me,page,code:d.code,f};
  async function listing(endpoint){
    let r=await api(endpoint+'?'+query(f,d.code),undefined,'json',passive);
    if(r.offset&&!r.rows.length){f.offset=r.total?Math.floor((r.total-1)/r.limit)*r.limit:0;r=await api(endpoint+'?'+query(f,d.code),undefined,'json',passive);}
    return r;
  }
  try{
    if(page==='home'||page==='movements')next.rows=await api('movements?'+query(page==='home'?{}:f,d.code),undefined,'json',passive);
    if(page==='reports')next.report=await api('report?'+query(f,d.code),undefined,'json',passive);
    if(page==='collection')next.collection=await listing('collection');
    if(page==='users')next.users=(await api('users',undefined,'json',passive)).users;
    if(page==='book')next.audit=await listing('audit');
  }catch(e){
    if(!retried&&e instanceof ApiError&&[403,404].includes(e.status))return refresh(passive,true);
    throw e;
  }
  Object.assign(s,next);if(writeState==='saved')setWriteState('');syncMark(false);render();
}
function marketNav(){return Object.entries(labels).filter(([id])=>!(['users','book'].includes(id)&&!s.me.owner)&&!(['reports','collection'].includes(id)&&!rights('reports').length));}
function navLinks(){
  const active=primaryPages.includes(s.page)?s.page:'more';
  return primaryPages.map(id=>`<button type="button" class="side-link ${active===id?'active':''}" ${active===id?'aria-current="page"':''} data-action="go" data-page="${id}">${icon(labels[id][1],17)}${h(id==='home'?'الرئيسية':labels[id][0])}</button>`).join('');
}
function morePage(){
  const tile=(title,ic,action,attrs='')=>btn(title,action,ic,'more-tile',attrs);
  const pages=marketNav().filter(([id])=>!primaryPages.includes(id));
  const goTile=([id,[title,ic]])=>tile(title,ic,'go',`data-page="${id}"`);
  return head('المزيد','')+`<div class="desk-more">
    ${pages.length?`<section class="panel">${panelHeader('الدفتر')}${pages.map(goTile).join('')}</section>`:''}
    <section class="panel">${panelHeader('الحساب والجهاز')}${tile('الجلسة الحالية','lock','session')}${tile('عن قيد والدعم','info','about')}${tile('تسجيل الخروج','arrowRight','logout')}</section>
  </div>`;
}
function render(){
  if(!s.me||s.me.mustChange||!s.desk){renderGate();return;}
  const views={home,accounts:accountsPage,movements:movementPage,collection:DeskOps.collectionPage,reports,users:usersPage,book:bookPage,more:morePage};
  const back=primaryPages.includes(s.page)?'':`<div class="desk-back">${btn('المزيد','go','arrowRight','text','data-page="more"')}</div>`;
  root.innerHTML=`<div class="shell"><aside class="sidebar">${brand()}<nav aria-label="أقسام الدفتر المشترك">${navLinks()}</nav><div class="side-foot"><span class="side-caption">قيد · ${h(QaydRelease.version)}</span></div></aside>
  <div class="body"><header class="top simple-top"><div class="top-name"><div class="path">${icon('cloud',17)}<strong>الدفتر المشترك</strong></div><span class="who" dir="auto">${h(s.me.name)}</span>${badge(role(),s.me.owner?'':'ok')}${s.demo?badge('تجربة','warn'):''}</div>
  <div class="row">${ib('تحديث البيانات','refresh','undo')}${embedded&&!employee?returnLocal():''}</div></header>
  ${embedded?`<div class="sync-strip" data-stale="true" ${syncStale?'':'hidden'}><div class="sync-message">${icon('info',16)}<span class="sync-text" role="status">${h(syncLabel)}</span></div></div>`:''}
  <nav class="mobile-nav mobile-only" aria-label="التنقل على الهاتف">${navLinks()}</nav><main class="page" id="page" tabindex="-1">${writeNotice(true)}${back}${views[s.page]()}</main></div></div>`;
}
const codeSelect=()=>sel('code','العملة',s.desk.currencies.map(c=>opt(c.code,c.name+' · '+c.code,s.code)).join(''),'data-change="currency"');
function filterDisclosure(content,active=false){return `<details class="desk-filter-more" ${active?'open':''}><summary>${icon('filter',16)} التصفية</summary><div class="row">${content}</div></details>`;}
const newPost=(id='')=>btn('إضافة حركة','new-movement','plus','primary',idattr(id));
const newAccount=()=>btn('إضافة حساب','new-account','plus','primary');
const newUser=()=>btn('فتح مستخدم فرعي','new-user','plus','primary');
const noAccess=()=>empty('لا تصنيفات متاحة','اطلب من مالك الدفتر منحك صلاحية عرض التصنيف الذي تعمل عليه.','lock');
function home(){
  const {totals}=s.desk;
  const action=postable().length?newPost():rights('addAccount').length?newAccount():'';
  return head('نظرة عامة','',(categories().length?codeSelect():'')+action,'')+
    (!categories().length?`<section class="panel">${noAccess()}</section>`:grid([
      metric('صافي الرصيد',money(totals.net),s.code,'wallet'),metric('لي',money(totals.credit),`${number(totals.credits)} حساب`,'credit','green'),metric('عليّ',money(totals.debit),`${number(totals.debts)} حساب`,'debit','red')])+`
      <section class="panel">${panelHeader('آخر الحركات')}${movementTable(s.rows?.rows.slice(0,4)||[],true)}</section>`);
}
function accountsPage(){
  const f=s.f,search=Ledger.searchKey(f.q),list=accounts().filter(a=>(f.category==='*'||a.category===f.category)&&(!search||Ledger.searchKey(a.name+' '+a.phone).includes(search))).sort((a,b)=>a.name.localeCompare(b.name,'ar'));
  const page=Math.min(acctPage,Math.max(0,Math.ceil(list.length/40)-1)),shown=list.slice(page*40,page*40+40);
  return head('الحسابات','',(rights('addAccount').length?newAccount():'')+codeSelect())+`<section class="panel">${panelHeader('دليل الحسابات',`${number(list.length)} حساب مطابق`)}
  ${categories().length?`<form id="filters" class="filter simple-filter">${fld('q','بحث بالاسم أو الهاتف',f.q,{type:'search',attrs:'maxlength="140"'})}${btn('بحث','','search','outline')}${categories().length>1?filterDisclosure(sel('category','التصنيف',scopeOptions(categories(),f.category)),f.category!=='*'):''}</form>`:''}
  ${!categories().length?noAccess():shown.length?`<div class="scroll"><table><thead><tr><th>الحساب</th><th>التصنيف</th><th>الرصيد · ${h(s.code)}</th><th>الإجراءات</th></tr></thead><tbody>${shown.map(a=>`<tr data-account="${h(a.id)}"><td><button class="linklike" data-action="view-account" ${idattr(a.id)}>${h(a.name)}</button>${a.phone?`<small class="cell-sub">${bdi(a.phone)}</small>`:''}</td><td>${h(catName(a.category))}</td><td class="${a.minor<0?'neg':'pos'}">${bdi(money(a.minor))}</td><td class="actions"><div class="row">${a.post?ib('إضافة حركة','new-movement','plus',idattr(a.id)):''}${a.edit?ib('تعديل الحساب','edit-account','edit',idattr(a.id)):''}${a.remove?ib('حذف الحساب الفارغ','delete-account','trash',idattr(a.id)):''}</div></td></tr>`).join('')}</tbody></table></div>`:empty('لا حسابات مطابقة','غيّر البحث أو أضف حسابًا إلى تصنيف متاح.','accounts')}
  ${list.length>40?pageFooter(page*40,list.length,'account-page'):''}</section>`;
}
const rowTitle=e=>e.legs.map(l=>l.name).join(' ← ');
function movementTable(rows,compact=false){
  if(!rows.length)return empty('لا حركات في العرض',embedded&&employee?'تأكد أنك تعرض عملة الحركة وفترتها وأن المدير سجّلها في الدفتر المشترك.':'جرّب اختيار عملة أو فترة أخرى.','moves');
  return `<div class="scroll"><table><thead><tr><th>الحساب</th><th>التاريخ</th><th>النوع</th><th>المبلغ</th>${compact?'':'<th>الإجراءات</th>'}</tr></thead><tbody>${rows.map(e=>`<tr data-movement="${h(e.id)}"><td><button class="linklike" data-action="movement-info" ${idattr(e.id)}>${h(rowTitle(e))}</button>${e.memo?`<small class="cell-sub">${h(e.memo)}</small>`:''}</td><td class="no-break">${bdi(e.day)}${compact?'':`<small class="cell-sub">${bdi(e.time)}</small>`}</td><td>${badge(e.receipt?`سند #${Ledger.receiptNumber(e.receipt.number)}`:kinds[e.kind],e.kind==='credit'?'ok':e.kind==='debit'||e.kind==='receipt'?'off':e.kind==='isolated'?'warn':'')}${e.locked&&!compact?'<small class="cell-sub">مؤرشف</small>':''}</td><td class="${e.kind==='transfer'?'':e.minor<0?'neg':'pos'}">${bdi(money(e.minor))}</td>${compact?'':`<td class="actions"><div class="row">${e.edit?ib('تعديل الحركة','edit-movement','edit',idattr(e.id)):''}${e.remove?ib('حذف الحركة','delete-movement','trash',idattr(e.id)):''}</div></td>`}</tr>`).join('')}</tbody></table></div>`;
}
function pageFooter(offset,total,act,size=40){
  return `<div class="footer row apart"><span>${number(offset+1)}–${number(Math.min(offset+size,total))} من ${number(total)}</span><div class="row">${btn('السابق',act,'arrowRight','outline slim',`data-step="-1" ${offset?'':'disabled'}`)}${btn('التالي',act,'arrowLeft','outline slim',`data-step="1" ${offset+size>=total?'disabled':''}`)}</div></div>`;
}
function movementPage(){
  const f=s.f,r=s.rows;
  return head('الحركات','',(postable().length?newPost(f.account):'')+codeSelect())+`<section class="panel">${panelHeader('سجل الحركات',`${number(r.total)} حركة · ${s.code}`)}
  ${categories().length?`<form class="filter simple-filter" id="filters">${fld('q','بحث في الحركات',f.q,{type:'search',attrs:'maxlength="140"'})}${btn('بحث','','search','outline')}${filterDisclosure((categories().length>1?sel('category','التصنيف',scopeOptions(categories(),f.category)):'')+sel('account','الحساب',opt('','جميع الحسابات',f.account)+accounts().map(a=>opt(a.id,a.name,f.account)).join(''))+day('from','من تاريخ',f.from)+day('to','إلى تاريخ',f.to),!!(f.category!=='*'||f.account||f.from||f.to))}</form>`:''}
  ${categories().length?movementTable(r.rows):noAccess()}${r.total>40?pageFooter(r.offset,r.total,'movement-page'):''}</section>`;
}
function reports(){
  const f=s.f,r=s.report,available=rights('reports'),eligible=rights('exportCsv'),shown=eligible.some(c=>f.category==='*'||f.category===c.id);
  return head('التقارير','ملخص الحركات والأرصدة ضمن التصنيفات المصرّح بها.',(shown?btn('تنزيل CSV','report-csv','download','outline'):'')+codeSelect())+
    grid([metric('صافي الفترة',money(r.totals.balance),s.code,'wallet'),metric('إجمالي الحركات الموجبة',money(r.totals.credit),s.code,'credit','green'),metric('إجمالي الحركات السالبة',money(r.totals.debit),s.code,'debit','red')])+
    `<section class="panel">${panelHeader('تقرير الحسابات','كل تحويل محسوب بطرف الحساب ضمن النطاق. التنزيل يشمل التصنيفات المسموح بتصديرها فقط.')}<form class="filter" id="filters">${sel('category','التصنيف',scopeOptions(available,f.category))}${day('from','من تاريخ',f.from)}${day('to','إلى تاريخ',f.to)}${btn('تطبيق','','filter','outline')}</form>
    ${r.rows.length?`<div class="scroll"><table><thead><tr><th>الحساب</th><th>التصنيف</th><th>لي</th><th>عليّ</th><th>الصافي</th><th>الحركات</th></tr></thead><tbody>${r.rows.map(x=>`<tr><td>${h(x.name)}</td><td>${h(x.category)}</td><td>${bdi(money(x.credit))}</td><td>${bdi(money(x.debit))}</td><td>${bdi(money(x.balance))}</td><td>${bdi(number(x.count))}</td></tr>`).join('')}</tbody></table></div>`:empty('لا حسابات متاحة للتقرير','اختر تصنيفًا متاحًا فيه حسابات.','report')}</section>`;
}
function userStatus(u){return u.enabled?(u.mustChange?badge('بانتظار تغيير كلمة السر','warn'):badge('نشط','ok')):badge('موقوف','off');}
function usersPage(){
  const list=s.users;
  return head('المستخدمون الفرعيون','',newUser(),'')+
  `<section class="panel">
  ${list.length?`<div class="scroll users-scroll"><table class="users-table"><thead><tr><th>المستخدم</th><th>الحالة</th><th>التصنيفات</th><th>الإدارة</th></tr></thead><tbody>${list.map(u=>`<tr data-user="${h(u.login)}"><td class="user-cell"><div class="profile-name"><span class="avatar">${h([...u.name][0])}</span><div><strong class="wrap">${h(u.name)}</strong><small class="cell-sub">${bdi(u.login)}</small></div></div></td><td class="user-state">${userStatus(u)}</td><td class="user-scopes">${u.grants.length?u.grants.map(x=>badge(catName(x.category),'neutral')).join(' '):badge('دون وصول','neutral')}</td><td class="user-tools"><div class="row">${btn('الصلاحيات','edit-user','settings','outline slim',idattr(u.id))}${ib(u.enabled?'إيقاف المستخدم':'تفعيل المستخدم','toggle-user',u.enabled?'lock':'check',idattr(u.id))}${ib('تعيين كلمة سر مؤقتة','reset-user','undo',idattr(u.id))}${ib('إنهاء الجلسات','revoke-user','shield',idattr(u.id))}</div></td></tr>`).join('')}</tbody></table></div>`:empty('لم تفتح مستخدمًا فرعيًا بعد','افتح مستخدمًا واسمح له، مثلًا، بإضافة حركات العملاء دون رؤية الموردين.','people')}</section>`;
}
function bookPage(){
  return head('إعدادات الدفتر','إدارة التصنيفات والنسخ وسجل عمليات المستخدمين.','', 'خاص بالمالك')+
    `<div class="panels"><section class="panel">${panelHeader('التصنيفات','يعتمد وصول المستخدمين على هذه التصنيفات.',btn('تصنيف جديد','new-category','plus','outline'))}<div class="pane-content"><ul class="categories">${categories().filter(c=>c.id).map(c=>`<li>${tint('tag','',c.color)}<bdi class="grow strong">${h(c.name)}</bdi>${ib('تعديل اسم التصنيف','edit-category','edit',idattr(c.id))}</li>`).join('')}</ul></div></section>
    ${!s.demo&&!embedded?`<section class="panel">${panelHeader('نسخ السجلات')}<div class="pane-content cluster"><div class="prefs-actions">${btn('استيراد نسخة قيد','import','archive','outline',s.desk.importable?'':'disabled')}${btn('تنزيل دفتر قيد','backup','download','outline')}</div>${!s.desk.importable?'<p class="small sub">الاستيراد الكامل متاح في دفتر جديد قبل التسجيل أو فتح المستخدمين.</p>':''}</div></section>`:''}</div>`+(embedded?maintenanceHandoff():DeskMaintenance.panel())+DeskOps.securityPanel()+DeskOps.auditPanel();
}
function maintenanceHandoff(){
  if(s.demo||!s.me.owner)return '';
  const ready=s.capabilities.categoryTransfer===1&&s.capabilities.recoveryArchive===1;
  return `<section class="panel maintenance-panel" id="maintenance-panel">${panelHeader('النقل والاستعادة','إجراءات المالك على موقع الدفتر فقط.',ready?badge('متاح','ok'):badge('يتطلب ترقية الخادم','warn'))}
    <div class="pane-content cluster">${ready?tip(`افتح ${embedded.origin} في المتصفح. سجّل دخول المالك هناك لنقل تصنيف أو تنزيل ملف استعادة. لن يُرسل التطبيق أي ملف أو كلمة سر عند الفتح.`,'','lock')+`<div class="row">${btn('فتح إجراءات المالك في المتصفح','maintenance-web','cloud','outline')}</div>`:tip('نقل تصنيف من الهاتف والنسخة المشفّرة التي تشمل المستخدمين يتطلبان خادم قيد 3.4. تظل الحسابات والحركات والصلاحيات تعمل على الخادم الحالي.','warn','info')}</div></section>`;
}
function sharedDestination(){
  return `<div class="post-destination" data-destination="shared">${tint('cloud','green')}<div><strong>وجهة الحفظ: ${s.demo?'الدفتر التجريبي':'الدفتر المشترك'}</strong><p>${s.demo?'بيانات تجربة فقط.':'عبر الإنترنت. يراه الفريق بحسب صلاحياته؛ لا يُضاف إلى دفتر الهاتف.'}</p></div></div>`;
}
function bookReviewHint(action,id,f){
  if(action.startsWith('movement-')){
    const e=id&&item(id);
    return {page:'movements',code:f.code||e?.legs?.[0]?.code||s.code,account:f.account||f.from||e?.legs?.[0]?.account,day:f.day||e?.day};
  }
  return {page:action==='collection-followup'?'collection':action.startsWith('category-')?'book':'accounts',code:f.code||s.code};
}
function bookRejected(e){
  if(e.code==='login')return clearSession('لم يُحفظ التغيير. انتهت الجلسة؛ سجّل الدخول مجددًا.');
  if(e.code==='password-required'&&s.me){close();s.me.mustChange=true;renderGate();return feedback('لم يُحفظ التغيير. غيّر كلمة السر أولًا.');}
  const form=$('#dialog-form',dlg);
  if(form&&[403,404,409].includes(e.status)&&e.code!=='busy'){
    form.dataset.rejected='true';
    const submit=$('[type=submit]',form);if(submit)submit.disabled=true;
    const actions=$('#book-rejected-actions',dlg);if(actions)actions.hidden=false;
  }
  feedback('لم يُحفظ التغيير. '+e.message);
}
async function bookChange(action,id,fields,version=s.desk.version){
  if(!guardWrite())return;
  clearTimeout(noticeTimer);$('#notice').replaceChildren();
  const form=$('#dialog-form',dlg),submit=form&&$('[type=submit]',form),label=submit?.innerHTML;
  if(submit){submit.textContent='جارٍ الحفظ…';submit.setAttribute('aria-busy','true');}
  // Set the marker before dispatch. Its value is not a draft and never causes another POST.
  setWriteState('uncertain');reviewHint=bookReviewHint(action,id,fields);
  try{
    const r=await api('book/change',{action,id,fields:{...fields,version}});
    if(typeof r.id!=='string'||!r.id||typeof r.version!=='string'||!r.version||r.version===version)throw new Error('Unconfirmed book change');
  }catch(e){
    // These are structured pre-commit rejections from the Qayd API/bridge, not gateway timeouts.
    if(e instanceof ApiError&&e.structured&&[400,401,403,404,405,409,413,415,421,422,426,428,429].includes(e.status)&&e.code!=='protocol'){
      setWriteState('');return bookRejected(e);
    }
    close();syncMark(true);paintWriteNotice(true);return;
  }finally{if(submit?.isConnected){submit.innerHTML=label;submit.removeAttribute('aria-busy');}}
  setWriteState('saved');close();
  const success=fields.kind==='receipt'?'حُفظ سند القبض في الدفتر المشترك.':'حُفظ التغيير في الدفتر المشترك.';
  flash(success);
  try{await refresh();}catch(e){
    if(e.code==='login')return clearSession('حُفظ التغيير. سجّل الدخول لتحديث العرض.');
    syncMark(true);paintWriteNotice(true);
  }
}
function accountForm(a){
  const list=rights('addAccount');if(!a&&!list.length)throw new Error('لا يوجد تصنيف يسمح بإضافة حساب.');
  const version=s.desk.version;
  const body=`<div class="fields">${fld('name','اسم الحساب',a?.name,{attrs:'required maxlength="90" dir="auto"'})}${a?fld('cat','التصنيف',catName(a.category),{attrs:'readonly'}):sel('category','التصنيف',scopeOptions(list,list[0]?.id,false))}${fld('phone','رقم الهاتف',a?.phone,{type:'tel',attrs:'maxlength="48"',ltr:true})}${memo('note','ملاحظة',a?.note,400)}</div>`;
  dial(a?'تعديل حساب':'إضافة حساب','يُحفظ الحساب في الدفتر المشترك فقط.',body,f=>bookChange(a?'account-edit':'account-add',a?.id,{name:f.name,phone:f.phone,note:f.note,...(a?{}:{category:f.category})},version),{posting:true});
}
function valueFields(e){
  return `<div class="fields">${day('day','التاريخ',e?.day||s.desk.today)}${fld('amount','المبلغ الموجب',e?Ledger.inputDecimal(Math.abs(e.legs[0].minor)):'',{attrs:'required inputmode="decimal" maxlength="28" placeholder="0.000"',ltr:true})}${memo('memo','البيان (اختياري)',e?.memo)}<details class="span post-extra"><summary>تفاصيل إضافية</summary><div class="fields">${fld('time','الوقت',e?.time||'',{type:'time',ltr:true})}${day('due','الاستحقاق (اختياري)',e?.due||'')}</div></details></div>`;
}
function movementForm(e,account=''){
  const version=s.desk.version,eligible=postable();
  if(!e&&!eligible.length)throw new Error('لا يوجد حساب يسمح بإضافة حركة.');
  const base=e?tip(`${rowTitle(e)} · ${e.legs[0].code} · ${kinds[e.kind]}. يبقى الحساب ونوع الحركة والعملة كما هي.`):`<div class="fields">${sel('kind','نوع الحركة',Object.entries(kinds).filter(([k])=>k!=='isolated'&&(k!=='transfer'||eligible.length>1)).map(([k,v])=>opt(k,v,'credit')).join(''))}
  ${sel('code','العملة',s.desk.currencies.map(c=>opt(c.code,c.name+' · '+c.code,s.code)).join(''))}<div id="one-account" class="span">${DeskPicker.field('account','الحساب المشترك',eligible,account)}</div>
  <div id="two-accounts" class="fields span" hidden>${DeskPicker.field('from','من حساب',eligible,account)}${DeskPicker.field('to','إلى حساب',eligible,'')}</div>
  <div id="receipt-fields" class="fields span" hidden>${sel('method','طريقة القبض',Object.entries(methods).map(([k,v])=>opt(k,v,'cash')).join(''))}${fld('reference','المرجع (اختياري)','',{attrs:'maxlength="90" dir="auto"'})}<p class="sub small span">يُرقّم سند القبض تلقائيًا ويوزّع المبلغ على أقدم القيود المستحقة.</p></div></div>`;
  dial(e?'تعديل حركة':'إضافة حركة',e&&e.receipt?'رقم السند وطريقته وتخصيصه لا تتغير من هذه الشاشة.':'القيم تُحفظ بدقة ثلاثة أجزاء عشرية.',sharedDestination()+base+valueFields(e),f=>{
    if(!f.day)throw new Error('اختر تاريخ الحركة.');
    const fields={day:f.day,time:f.time,amount:f.amount,memo:f.memo,due:f.due||''};
    if(!e){
      for(const name of f.kind==='transfer'?['from','to']:['account'])if(!DeskPicker.valid(name,f[name]))return;
      if(f.kind==='transfer'&&f.from===f.to)throw new Error('اختر حسابين مختلفين للتحويل.');
      Object.assign(fields,{kind:f.kind,code:f.code});
      if(f.kind==='transfer'){fields.from=f.from;fields.to=f.to;}
      else{fields.account=f.account;if(f.kind==='receipt')Object.assign(fields,{method:f.method,reference:f.reference});}
    }
    return bookChange(e?'movement-edit':'movement-add',e?.id,fields,version);
  },{wide:true,submit:'حفظ في الدفتر المشترك',posting:true});
  if(e){const due=$('[name="due"]',dlg);due.disabled=e.kind==='receipt'||e.legs.every(l=>l.minor<0);due.closest('label').hidden=due.disabled;}
  else{DeskPicker.mount(eligible);movementKind('credit');}
}
function movementKind(kind){
  const transfer=kind==='transfer';
  for(const [id,shown] of [['one-account',!transfer],['two-accounts',transfer],['receipt-fields',kind==='receipt']]){
    const group=$('#'+id,dlg);group.hidden=!shown;q('input,select',group).forEach(el=>el.disabled=!shown);
    if(!shown)DeskPicker.hideGroup(group);
  }
  const due=$('[name="due"]',dlg);due.disabled=['debit','receipt'].includes(kind);due.closest('label').hidden=due.disabled;if(due.disabled)due.value='';
}
const permInput=(k,allow)=>`<label class="check"><input type="checkbox" data-permission="${h(k)}" ${allow.includes(k)?'checked':''}><span>${h(k==='view'?'عرض':s.ops[k])}</span></label>`;
function permCard(cat,allow){
  return `<section class="perm" data-category="${h(cat.id)}"><div class="perm-header"><span class="perm-name">${tint('tag','',cat.color)}${h(cat.name)}</span>${permInput('view',allow)}</div><div class="perm-body" ${allow.includes('view')?'':'hidden'}>${Object.keys(s.ops).filter(k=>k!=='view').map(k=>permInput(k,allow)).join('')}</div></section>`;
}
function permCheck(){
  for(const c of q('.perm',dlg)){
    const enabled=$('[data-permission=view]',c).checked,report=$('[data-permission=reports]',c),csv=$('[data-permission=exportCsv]',c);
    $('.perm-body',c).hidden=!enabled;
    if(!enabled)q('.perm-body input',c).forEach(x=>x.checked=false);
    for(const dependent of [csv,$('[data-permission=followup]',c)].filter(Boolean)){dependent.disabled=!report.checked;if(dependent.disabled)dependent.checked=false;}
  }
}
function userForm(u){
  const rules=new Map(u?.grants.map(g=>[g.category,g.allow]));
  const body=`<div class="fields">${fld('name','اسم المستخدم',u?.name,{attrs:'required maxlength="60" dir="auto"'})}${fld('login','اسم الدخول',u?.login,{attrs:u?'readonly':'required minlength="3" maxlength="32" pattern="[A-Za-z0-9][A-Za-z0-9._\\-]{2,31}" autocomplete="off" autocapitalize="none" placeholder="sales.1"',ltr:true})}</div>
  ${u?`<label class="check"><input type="checkbox" name="enabled" ${u.enabled?'checked':''}><span>السماح بتسجيل الدخول</span></label>`:tip('ينشئ قيد كلمة سر مؤقتة تظهر مرة واحدة. يختار المستخدم كلمة سر جديدة عند أول دخول.','green','lock')}
  <div class="first-perms"><h3>الصلاحيات حسب التصنيف</h3><p class="sub small">فعّل العرض للتصنيف المطلوب، ثم اختر وظائفه. يبقى كل ما لم تحدده محجوبًا.</p><div class="perm-grid">${categories().map(c=>permCard(c,rules.get(c.id)||[])).join('')}</div></div>`;
  dial(u?'إعدادات المستخدم الفرعي':'فتح مستخدم فرعي',u?`${u.name} · ${u.login}`:'حساب مستقل للدخول إلى هذا الدفتر من أي جهاز.',body,async f=>{
    const grants=q('.perm',dlg).map(p=>({category:p.dataset.category,allow:q('[data-permission]:checked',p).map(input=>input.dataset.permission)})).filter(x=>x.allow.length);
    const result=await api(u?'users/update':'users/create',u?{id:u.id,version:u.version,name:f.name,grants,enabled:!!f.enabled}:{login:f.login,name:f.name,grants});
    if(result.temporary){invite(result);await refresh();}else{close();await refresh();flash('حُفظت الصلاحيات وحالة الدخول.');}
  },{submit:u?'حفظ الصلاحيات':'إنشاء المستخدم',wide:true});permCheck();
}
function invite({user,temporary}){
  const u=new URL((embedded?embedded.origin:location.origin)+'/');if(s.demo)u.searchParams.set('demo',s.realm);
  const attrs='readonly autocomplete="off"';
  dial('بيانات دخول المستخدم',user.name,tip('ستظهر كلمة السر المؤقتة هنا مرة واحدة. سلّمها للمستخدم بطريقة آمنة وبشكل منفصل عن الرابط.','warn','info')+
    fld('invite-link','رابط الدخول',u.href,{attrs,ltr:true})+fld('invite-user','اسم الدخول',user.login,{attrs,ltr:true})+fld('invite-pass','كلمة السر المؤقتة',temporary,{attrs,ltr:true})+
    '<p class="sub small">في قيد اختر «أنا موظف» ثم احفظ هذا الرابط. عند أول دخول يختار الموظف كلمة سر جديدة. الرابط لا يتضمن كلمة السر.</p>',null,{foot:btn('نسخ الرابط','copy-link','copy','outline')});
}
function confirm(title,txt,submit,fn,danger=true,posting=false){dial(title,'',(posting?sharedDestination():'')+tip(txt,danger?'warn':'','info'),fn,{submit,danger,posting});}
function userOp(u,op){
  const enabled=!u.enabled;
  if(op==='reset')return confirm('تعيين كلمة سر مؤقتة',`سيُنهى دخول «${u.name}» وتُنشأ كلمة مؤقتة بديلة.`, 'إنشاء كلمة مؤقتة',async()=>{const r=await api('users/reset',{id:u.id,version:u.version});invite(r);await refresh();},false);
  if(op==='revoke')return confirm('إنهاء جلسات المستخدم',`سيُسجّل خروج «${u.name}» من أجهزته. يمكنه الدخول مجددًا بكلمة سره الحالية إن كان مفعّلًا.`,'إنهاء الجلسات',async()=>{await api('users/revoke',{id:u.id,version:u.version});close();await refresh();flash('أُنهيت جلسات المستخدم.');});
  confirm(enabled?'تفعيل المستخدم':'إيقاف المستخدم',enabled?`سيتمكن «${u.name}» من الدخول وفق الصلاحيات نفسها.`:`سيُمنع «${u.name}» من الدخول وتُنهي جميع جلساته دون حذف حركاته.`,enabled?'تفعيل':'إيقاف',async()=>{
    await api('users/update',{id:u.id,version:u.version,name:u.name,grants:u.grants,enabled});close();await refresh();flash(enabled?'أُعيد تفعيل المستخدم.':'أُوقف المستخدم.');
  },!enabled);
}
function saveBlob(blob,name){if(embedded)return embedded.save(blob,name);const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),10000);}
function loadSQLite(){
  const load=url=>new Promise((ok,no)=>{const script=document.createElement('script');script.src=url;script.onload=ok;script.onerror=()=>{script.remove();no(new Error('تعذّر تحميل قارئ SQLite. تحقق من اتصال الخادم.'));};document.head.append(script);});
  return dbLoader||=(globalThis.QaydDbEngine?Promise.resolve():load('/assets/db-engine.js')).then(()=>load('/assets/db-backup.js')).catch(e=>{dbLoader=null;throw e;});
}
async function readDeskFile(file,password){
  if(!file?.size||file.size>48*1024*1024)throw new Error('اختر ملفًا صالحًا بحجم لا يتجاوز 48 ميغابايت.');
  const bytes=new Uint8Array(await file.arrayBuffer());let text;
  if(bytes[0]===83&&bytes[1]===81&&bytes[2]===76&&bytes[3]===105){await loadSQLite();const db=await QaydDb.read(bytes).promise;if(db.kind!=='qayd')throw new Error('استورد النسخة القديمة في قيد المحلي، ثم احفظ نسخة قيد كاملة.');text=db.text;}
  else {if(bytes.length>20*1024*1024)throw new Error('ملف JSON أكبر من الحد المسموح.');try{text=new TextDecoder('utf-8',{fatal:true}).decode(bytes);}catch{throw new Error('الملف ليس نسخة قيد مقروءة.');}}
  let raw;try{raw=JSON.parse(text.replace(/^\uFEFF/,''));}catch{throw new Error('صيغة بيانات النسخة غير معروفة.');}
  if(Vault.is(raw))raw=(await Vault.unlock(raw,password)).value;
  return raw;
}
function importForm(){
  const version=s.desk.version;
  dial('استيراد نسخة قيد كاملة','الملف يُقرأ محليًا للمراجعة قبل إرساله إلى الخادم.',
    fld('source','ملف DB أو JSON','',{type:'file',attrs:'required accept=".db,.sqlite,.sqlite3,.json,application/json,application/octet-stream"'})+
    fld('password','كلمة سر النسخة (إن كانت مشفّرة)','',{type:'password',attrs:'maxlength="128" autocomplete="off"',ltr:true})+
    tip('تُنسخ البيانات إلى الخادم عند التأكيد فقط. الملف ودفتر الهاتف لا يتغيران. لا تستخدم ملف تصنيف أو نسخة التطبيق القديم مباشرة.','warn','info'),async f=>{
      const raw=await readDeskFile(f.source,f.password);
      if(raw?.format==='qayd-category-backup'||raw?.demo===true)throw new Error('اختر نسخة كاملة ببياناتك الفعلية، لا نسخة تصنيف أو تجربة.');
      const ledger=Ledger.validate(raw);
      dial('تأكيد نسخ الدفتر','هذا الإجراء متاح لدفتر مشترك جديد فقط.',
        tip(`سترسل ${number(ledger.accounts.length)} حساب و${number(ledger.entries.length)} حركة و${number(ledger.categories.length)} تصنيف إلى الخادم ${location.host}. لن يتغير الدفتر المحلي.`,'warn','archive')+
        '<label class="check"><input name="confirmed" type="checkbox" required><span>أوافق على حفظ هذه البيانات في الخادم المحدّد.</span></label>',async c=>{
          if(!c.confirmed)throw new Error('أكّد إرسال النسخة أولًا.');await api('book/import',{version,confirm:true,ledger});close();await refresh();flash('نُسخت البيانات إلى الدفتر المشترك.');
        },{submit:'حفظ على الخادم'});
    },{submit:'قراءة ومراجعة'});
}
function backupForm(){
  dial('تنزيل دفتر قيد','ملف JSON يُفتح في قيد كنسخة دفتر كاملة. لا يشمل حسابات الدخول أو كلمات السر.',
    fld('password','كلمة سر جديدة لتشفير ملف النسخة','',{type:'password',attrs:'required minlength="12" maxlength="128" autocomplete="new-password"',ltr:true})+
    fld('again','أعد كتابة كلمة سر النسخة','',{type:'password',attrs:'required minlength="12" maxlength="128" autocomplete="new-password"',ltr:true})+
    tip('احفظ كلمة سر النسخة في مكان آمن. لا يغير ذلك كلمة سر الدخول أو تشفير تخزين الخادم.'),async f=>{
      if(f.password!==f.again)throw new Error('كلمتا السر غير متطابقتين.');
      const ledger=await api('book/backup'),key=await Vault.newKey(f.password),packed=await Vault.lock(ledger,key);
      saveBlob(new Blob([JSON.stringify(packed)],{type:'application/json'}),`qayd-shared-${s.desk.today}.json`);close();flash('طُلب تنزيل نسخة مشفّرة.');
    },{submit:'تشفير وتنزيل'});
}
const grab=form=>Object.fromEntries(new FormData(form));
async function changePassword(f){
  if(f.password!==f.again)throw new Error('كلمتا السر غير متطابقتين.');
  const r=await api('password',{current:f.current,password:f.password,...(f.otp?{otp:f.otp}:{})},'json',false,employee&&f.remember==='on');close();consent=false;await logged(r,s.page);
  if(!r.deviceSaveFailed)flash('حُفظت كلمة السر الجديدة وأُنهيت الجلسات الأخرى.'+(r.deviceSaved?' حُفظ الدخول على هذا الهاتف.':''));
}
async function go(page){
  if(!marketNav().some(([id])=>id===page))return;
  const before={page:s.page,f:s.f},beforePage=acctPage;
  s.page=page;s.f=resetFilter();acctPage=0;close();
  try{if(page==='more')render();else await refresh();}
  catch(e){Object.assign(s,before);acctPage=beforePage;throw e;}
  $('#page')?.focus({preventScroll:true});window.scrollTo(0,0);
}
const item=id=>s.rows?.rows.find(x=>x.id===id);
const person=id=>s.users.find(x=>x.id===id);
function detail(e){
  dial(e.receipt?`سند قبض #${Ledger.receiptNumber(e.receipt.number)}`:kinds[e.kind],rowTitle(e),
    `<div class="fields"><p><strong>التاريخ</strong><br>${bdi(e.day)} · ${bdi(e.time)}</p><p><strong>المبلغ</strong><br>${bdi(money(e.minor))} ${h(e.legs[0].code)}</p>${e.memo?`<p class="span wrap"><strong>البيان</strong><br>${h(e.memo)}</p>`:''}${e.due?`<p><strong>الاستحقاق</strong><br>${bdi(e.due)}</p>`:''}${e.receipt?`<p><strong>الطريقة</strong><br>${h(methods[e.receipt.method])}</p><p class="wrap"><strong>المرجع</strong><br>${h(e.receipt.reference||'—')}</p>`:''}</div>`+
    (e.kind==='isolated'?tip('هذا هو الطرف الموقّع الظاهر لهذا الحساب. لا يُعرض الطرف الآخر.'):e.locked?tip('هذا القيد في أرشيف رصيد مغلق.','warn','archive'):''),null);
}
async function action(b){
  const {action,id,page,step}=b.dataset;
  if(action==='close')return close();
  if(action==='demo')return logged(await api('demo',{}),'users');
  if(action==='logout'){
    if(embedded){
      const removed=embedded.forget();
      try{await api('logout',{});}finally{clearSession(removed?'تم تسجيل الخروج من هذا الجهاز.':'تم الخروج، لكن تعذّر حذف الدخول المحفوظ. احذفه من شاشة الدخول.');}return;
    }
    await api('logout',{});return clearSession('تم تسجيل الخروج.');
  }
  if(action==='desk-connect'&&embedded)return connect();
  if(action==='desk-reload'&&embedded&&s.me)return loadWorkspace();
  if(action==='desk-show-otp'&&embedded)return showLoginOtp(true);
  if(action==='desk-saved'&&employee&&kept()){
    try{return await logged(await api('device-login'));}catch(e){renderGate();feedback(e.message||'تعذّر استخدام الدخول المحفوظ.');return;}
  }
  if(action==='desk-forget'&&employee){
    if(!embedded.forget())throw new Error('تعذّر حذف الدخول المحفوظ. تحقّق من الهاتف وأعد المحاولة.');
    if(dlg.open)close();if(!s.me)renderGate();flash('حُذف الدخول المحفوظ من هذا الهاتف.');return;
  }
  if(action==='session')return dial('الجلسة الحالية',s.me.name,connection()+(embedded&&syncAt?`<p class="sub small">آخر تحقق · ${h(shortDay(syncAt))}</p>`:'')+tip(`${role()} · ${s.me.login}. ${employee?(kept()?'الدخول محفوظ لهذا الدفتر فقط.':'الدخول غير محفوظ على هذا الهاتف.'):embedded?'تُغلق الجلسة عند مغادرة الدفتر أو إرسال التطبيق إلى الخلفية.':'تعمل هذه الجلسة في هذا المتصفح.'}`),null,{foot:s.demo&&s.me.owner?'':btn('تغيير كلمة السر','password','lock','outline')+(employee?returnLocal()+(kept()?btn('حذف الدخول المحفوظ','desk-forget','trash','text'):''):'')});
  if(action==='password')return dial('تغيير كلمة السر','يُنهي التغيير الجلسات الأخرى.',passwordFields(),changePassword);
  if(action==='go')return go(page);
  if(action==='refresh'||action==='refresh-rejected'){if(action==='refresh-rejected')close();await refresh();return flash('حُدّث عرض الدفتر.');}
  if(action==='review-write')return reviewWrite();
  if(action==='ack-write')return acknowledgeWrite();
  if(action==='account-page'){acctPage=Math.max(0,acctPage+Number(step));return render();}
  if(action==='movement-page'){s.f.offset=Math.max(0,s.f.offset+Number(step)*40);return refresh();}
  if(action==='view-account'){s.page='movements';s.f={...resetFilter(),account:id};return refresh();}
  if(['new-account','edit-account','delete-account','new-movement','edit-movement','delete-movement','new-category','edit-category','aging-receipt','aging-followup'].includes(action)&&!guardWrite())return;
  if(action==='new-account'||action==='edit-account')return accountForm(action==='edit-account'?rowAccount(id):null);
  if(action==='delete-account'){
    const a=rowAccount(id),version=s.desk.version;if(a)return confirm('حذف الحساب الفارغ',`سيُحذف «${a.name}». يُمنع حذف الحساب إذا كانت له حركات.`,'حذف الحساب',()=>bookChange('account-delete',id,{},version),true,true);
  }
  if(action==='new-movement')return movementForm(null,id);
  if(action==='edit-movement'){const e=item(id);if(e)return movementForm(e);}
  if(action==='movement-info'){const e=item(id);if(e)return detail(e);}
  if(action==='delete-movement'){
    const e=item(id),version=s.desk.version;if(e)return confirm('حذف الحركة',`سيُزال قيد ${rowTitle(e)} يوم ${e.day} نهائيًا من الدفتر المشترك.`,'حذف الحركة',()=>bookChange('movement-delete',id,{},version),true,true);
  }
  if(action==='new-user'||action==='edit-user')return userForm(action==='edit-user'?person(id):null);
  if(['toggle-user','reset-user','revoke-user'].includes(action)){const u=person(id);if(u)return userOp(u,action.split('-')[0]);}
  if(action==='copy-link'){
    const input=$('[name="invite-link"]',dlg);if(!input)return;
    try{await navigator.clipboard.writeText(input.value);flash('نُسخ رابط الدخول.');}catch{input.focus();input.select();feedback('حدّد الرابط وانسخه من هذا الحقل.');}return;
  }
  if(action==='new-category'||action==='edit-category'){
    const c=action==='edit-category'?getCategory(id):null,version=s.desk.version;
    return dial(c?'تعديل التصنيف':'تصنيف جديد','يتحكم المالك بالتصنيفات التي يُتاح لكل مستخدم الوصول إليها.',fld('name','اسم التصنيف',c?.name,{attrs:'required maxlength="50" dir="auto"'}),f=>bookChange(c?'category-edit':'category-add',c?.id,{name:f.name},version),{posting:true});
  }
  if(action==='report-csv'){const blob=await api('report.csv?'+query(s.f),undefined,'blob');await saveBlob(blob,`qayd-report-${s.code}-${s.desk.today}.csv`);return;}
  if(action==='import'&&!embedded)return importForm();
  if(action==='backup'&&!embedded)return backupForm();
  if(action==='maintenance-web'&&embedded&&!employee&&s.me?.owner&&s.capabilities.categoryTransfer===1&&s.capabilities.recoveryArchive===1)return embedded.openMaintenance();
  if(!embedded&&(action==='transfer-pick'||action==='recovery-export'))return DeskMaintenance.action(action);
  return DeskOps.action(b);
}
document.addEventListener('click',e=>{
  const b=e.target.closest('button[data-action]');if(!b)return;e.preventDefault();
  if(embedded&&b.dataset.action==='leave-desk'){embedded.leave();return;}
  if(employee&&b.dataset.action==='desk-link'){if(!busy||!s.me)embedded.changeManager();return;}
  if(!b.disabled)void work(()=>action(b));
});
function showLoginOtp(manual=false){
  const pane=$('#mfa-login');if(!pane)return;
  const field=$('[name=otp]',pane),toggle=$('[data-action=desk-show-otp]');
  if(manual&&!pane.hidden){field.value='';field.required=false;pane.hidden=true;toggle?.setAttribute('aria-expanded','false');return;}
  pane.hidden=false;field.required=!manual;toggle?.setAttribute('aria-expanded','true');field.focus();field.select();
}
document.addEventListener('submit',e=>{
  e.preventDefault();const form=e.target,f=grab(form);
  void work(async()=>{
    if(form=== $('#dialog-form',dlg)&&submitModal&&!form.hasAttribute('data-rejected'))return submitModal(f);
    if(form.id==='login-form'){
      consent=employee&&f.remember==='on';
      try{return logged(await api('login',{login:f.login.trim(),password:f.password,...(s.demo?{realm:s.realm}:{}),...(f.otp?{otp:f.otp.trim()}:{})},'json',false,consent));}
      catch(e){
        if(e.code==='mfa-required'||e.code==='mfa-invalid')showLoginOtp();
        throw e;
      }
    }
    if(form.id==='password-first')return changePassword(f);
    if(form.id==='filters'){
      if(f.from&&f.to&&f.from>f.to)throw new Error('تاريخ البداية يجب أن يسبق تاريخ النهاية.');
      s.f={...resetFilter(),...f};acctPage=0;await refresh();
    }
  });
});
document.addEventListener('input',e=>{
  const el=e.target;if(embedded||!el.closest('#login-form')||!['login','password'].includes(el.name))return;
  const pane=$('#mfa-login');if(pane&&!pane.hidden){const field=$('[name=otp]',pane);field.value='';field.required=false;pane.hidden=true;}
});
document.addEventListener('change',e=>{
  const el=e.target;
  if(el.dataset.change==='currency')void work(async()=>{s.code=el.value;s.f.offset=0;await refresh();});
  if(el.dataset.permission)permCheck();
  if(el.name==='kind'&&dlg.open&&$('#one-account',dlg))movementKind(el.value);
});
dlg.addEventListener('cancel',e=>{e.preventDefault();if(!busy&&!DeskPicker.escape())close();});
async function updateIfChanged(){
  if(!s.me||s.me.mustChange||!s.desk||busy||dlg.open||document.visibilityState==='hidden')return;
  // Scroll/input state is not disrupted while the user is editing a filter.
  if(document.activeElement?.closest('#filters'))return;
  const poll=async()=>{const m=await api('status',undefined,'json',true);if(m.version!==s.desk.version||m.profileVersion!==s.me.version)await refresh(true);else syncMark(false);};
  if(!embedded){await work(poll);return;}
  busy=true;
  try{await poll();}catch(e){if(e.code==='login')clearSession('انتهت الجلسة. سجّل الدخول مجددًا.');else syncMark(true);}
  finally{busy=false;}
}
window.addEventListener('focus',()=>void updateIfChanged());setInterval(()=>void updateIfChanged(),20000);
if(embedded){document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')void updateIfChanged();});
  window.qaydDeskBack=()=>{if(dlg.open){if(!busy)close();return true;}if(s.desk&&s.me&&!primaryPages.includes(s.page)){void work(()=>go('more'));return true;}return false;};
}
async function connect(){
  writeState=readWriteState();
  if(embedded)root.innerHTML=`<div class="loading app-boot">${brand()}${connection()}${writeNotice()}<p role="status">جارٍ الاتصال…</p><div class="row">${returnLocal()}</div></div>`;
  try{const info=await api('info');s.demo=info.demo;if(s.demo)writeState='';s.ops=info.actions;s.timezone=info.timezone;s.capabilities=info.capabilities||{};
    if(!s.demo&&!embedded){try{const m=await api('me');await logged(m);return;}catch(e){if(e.code!=='login')throw e;}}
    if(employee&&!autoTried&&kept()){
      autoTried=true;
      try{await logged(await api('device-login'));}catch(e){renderGate();feedback(e.message||'تعذّر الدخول المحفوظ.');}
      return;
    }
    renderGate();
  }catch(e){root.innerHTML=`<div class="loading ${embedded?'app-boot':''}">${brand()}${connection()}${writeNotice()}<p class="error">${h(e.message||'تعذّر الاتصال.')}</p>${embedded?`<div class="row">${btn('إعادة المحاولة','desk-connect','undo','primary')}${returnLocal()}</div>`:'<a href="/">إعادة المحاولة</a>'}</div>`;}
}
void connect();
