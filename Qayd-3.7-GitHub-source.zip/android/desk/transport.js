/* Loaded only by the packaged shared workspace. No fetch, local storage, file
   reads, WebView cookies, or local-ledger bridge. */
'use strict';
(()=>{
  const n=window.QaydDesk;
  if(!n||typeof n.request!=='function')return;
  const origin=String(n.origin()||''),employee=n.employeeMode?.()===true;
  const quickPost=!employee&&n.takeQuickPost?.()===true;
  const maximum=16*1024*1024;
  let sequence=0,waiting=null;
  function finish(id,status,chunk,done){
    const p=waiting;if(!p||p.id!==id)return;
    try{
      if(!Number.isInteger(status)||typeof chunk!=='string'||chunk.length>49152||p.size+chunk.length>maximum||
         (p.status!==null&&p.status!==status))throw new Error('response');
      p.parts.push(chunk);p.size+=chunk.length;p.status=status;
      if(!done)return;
      const raw=atob(p.parts.join('')),bytes=new Uint8Array(raw.length);
      for(let i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);
      const data=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));
      if(!data||typeof data!=='object'||Array.isArray(data))throw new Error('response');
      clearTimeout(p.timer);waiting=null;p.resolve({status,data});
    }catch{
      clearTimeout(p.timer);waiting=null;p.reject(new Error('تعذّر قراءة رد الخادم. حدّث البيانات قبل تكرار الحفظ.'));
    }
  }
  function request(route,body,passive=false,remember=false){
    if(waiting)return Promise.reject(new Error('يجري اتصال بالفعل. انتظر انتهاءه.'));
    const id='desk-'+(++sequence);
    return new Promise((resolve,reject)=>{
      const timer=setTimeout(()=>{
        if(waiting?.id!==id)return;
        waiting=null;n.clear();reject(new Error('لم يُؤكَّد الطلب في الوقت المحدد. حدّث الدفتر قبل تكرار الحفظ.'));
      },65000);
      waiting={id,resolve,reject,timer,status:null,size:0,parts:[]};
      try{n.request(id,route,body===undefined?'':JSON.stringify(body),Boolean(passive),employee&&Boolean(remember));}
      catch{clearTimeout(timer);waiting=null;reject(new Error('تعذّر الاتصال من التطبيق.'));}
    });
  }
  window.qaydDeskReply=finish;
  window.QaydDeskTransport=Object.freeze({origin,employee,quickPost,request,leave:()=>n.exit(),clear:()=>n.clear(),openMaintenance:()=>{if(!employee)n.openMaintenance?.();},
    readWriteNotice:()=>n.readWriteNotice?.()||'',writeWriteNotice:state=>n.writeWriteNotice?.(state)===true,
    canRemember:()=>employee&&n.canRemember?.()===true,kept:()=>employee&&n.hasRemembered?.()===true,
    forget:()=>!employee||n.forgetRemembered?.()===true,changeManager:()=>n.changeManager(),
    save:(csv,name)=>{if(typeof csv!=='string'||new TextEncoder().encode(csv).length>2*1024*1024)throw new Error('التقرير أكبر من الحد المسموح على الهاتف.');n.saveCsv(name,csv);}
  });
})();
