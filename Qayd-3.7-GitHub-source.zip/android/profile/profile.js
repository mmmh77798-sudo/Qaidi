'use strict';
(()=>{
  const n=window.QaydProfile,root=document.querySelector('#content');
  const h=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c]);
  const here='https://qayd-production.up.railway.app';
  if(!n){root.textContent='افتح إعداد الجهاز داخل تطبيق قيد.';return;}
  const cfg=JSON.parse(n.setup());
  let screen=cfg.editing?'link':'role',origin=cfg.origin||'',sent=false;
  const banner=(tag,t,p)=>`<div class="profile-intro"><p class="cap">${h(tag)}</p><h1>${h(t)}</h1><p>${h(p)}</p></div>`;
  const error='<p id="profile-error" role="alert" hidden></p>';
  const choice=(who,title,desc,ic)=>`<button type="button" class="choice" data-role="${who}"><span class="symbol">${icon(ic,24)}</span><span><strong>${h(title)}</strong><small>${h(desc)}</small></span>${icon('left',16)}</button>`;
  function role(){return banner('إعداد هذا الجهاز','كيف ستستخدم قيد؟','اختر وضع الجهاز للبدء. يمكنك تغييره لاحقًا.')+
    `<div class="choices">${choice('manager','أنا مدير','افتح الرئيسية ودفتر الهاتف، أو ادخل إلى الدفتر المشترك لإدارة فريقك.','shield')}${choice('staff','أنا موظف','ادخل إلى دفتر مديرك مباشرةً بحساب الموظف الذي أعطاك إياه.','people')}</div>
      ${cfg.role==='staff'?'<p class="note">اختيار وضع المدير يحذف الدخول المحفوظ للموظف من هذا الجهاز، ولا يحذف حسابه أو حركاته.</p>':''}${error}
      ${cfg.role?'<button class="text" type="button" data-action="leave">إلغاء</button>':''}`;}
  function link(){return banner('وضع الموظف','اربط دفتر مديرك','استخدم رابط الدفتر نفسه الذي أرسله إليك المدير. ستُدخل اسمك وكلمة سرك في الخطوة التالية.')+
    `<form id="profile-link"><label for="origin">رابط دفتر المدير</label><input id="origin" name="origin" dir="ltr" inputmode="url" autocapitalize="none" autocomplete="off" spellcheck="false" required maxlength="253" placeholder="https://…" value="${h(origin)}">
      <div class="note">${icon('shield',16)}<span>لا يقبل قيد إلا رابط HTTPS. تغيير الرابط يحذف الدخول المحفوظ للرابط السابق على هذا الجهاز.</span></div>
      <button type="button" class="text" data-action="current">استخدام رابط قيد الحالي</button>
      ${error}<button class="primary" type="submit">متابعة إلى تسجيل الدخول ${icon('left',17)}</button>
      <button class="text" type="button" data-action="back">اختيار وضع آخر</button>
    </form>`;}
  function draw(focus=false){root.innerHTML=screen==='link'?link():role();if(focus)root.querySelector(screen==='link'?'#origin':'h1')?.focus();}
  window.qaydProfileError=message=>{
    sent=false;root.querySelectorAll('button').forEach(b=>b.disabled=false);
    const el=root.querySelector('#profile-error');el.textContent=message;el.hidden=false;
  };
  function choose(role,at=''){
    if(sent)return;sent=true;root.querySelectorAll('button').forEach(b=>b.disabled=true);
    try{n.choose(role,at);}catch{window.qaydProfileError('تعذّر متابعة الإعداد. أعد المحاولة.');}
  }
  root.addEventListener('click',e=>{
    const b=e.target.closest('button');if(!b||sent)return;
    if(b.dataset.role==='manager')return choose('manager');
    if(b.dataset.role==='staff'){screen='link';draw(true);return;}
    switch(b.dataset.action){
      case 'current':{const input=root.querySelector('#origin');input.value=here;input.focus();break;}
      case 'back':origin=root.querySelector('#origin')?.value||origin;screen='role';draw();break;
      case 'leave':n.leave();break;
    }
  });
  root.addEventListener('submit',e=>{
    e.preventDefault();if(e.target.id!=='profile-link'||sent)return;
    try{origin=QaydSharedLink.origin(new FormData(e.target).get('origin'));choose('staff',origin);}
    catch(err){window.qaydProfileError(err.message);}
  });
  window.qaydProfileBack=()=>{if(sent)return true;if(screen==='link'&&!cfg.editing){screen='role';draw();return true;}return false;};
  draw();
})();
