package app.qayd.ledger;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.CookieHandler;
import java.net.HttpRetryException;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.net.ssl.HttpsURLConnection;

/** Transport for packaged team controls. No remote HTML, redirect, disk cache or system cookies. */
final class TeamHttp {
    static final String COOKIE = "__Host-qayd_session";
    static final int REQUEST_LIMIT = 64 * 1024, REPLY_LIMIT = 192 * 1024, LEGACY_LIMIT = 9 * 1024 * 1024;
    enum Route {
        INFO("/api/info", false), LOGIN("/api/login", true), LOGOUT("/api/logout", true),
        TEAM("/api/team", false), MEMBER("/api/team", false), CREATE("/api/users/create", true),
        UPDATE("/api/users/update", true), RESET("/api/users/reset", true), REVOKE("/api/users/revoke", true),
        OLD_DESK("/api/desk", false), OLD_USERS("/api/users", false);
        final String path; final boolean post;
        Route(String path, boolean post) {this.path=path;this.post=post;}
    }
    static final class Fault extends IOException {
        final String code;
        Fault(String code) {super(code);this.code=code;}
    }
    static final class Reply {
        final int status;final String json;final String cookie;
        Reply(int status,String json,String cookie){this.status=status;this.json=json;this.cookie=cookie;}
    }
    private TeamHttp(){}
    static boolean memberId(String id){return id!=null&&id.matches("[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}");}
    static boolean sessionValue(String v){return v!=null&&v.matches("[A-Za-z0-9_-]{43}");}
    static String target(String origin,Route route,String id) throws Fault {
        String expected=SharedOrigin.canonical(origin);
        if(expected==null||!expected.equals(origin)||route==null)throw new Fault("origin");
        if(route==Route.MEMBER){if(!memberId(id))throw new Fault("request");return expected+route.path+"?user="+id;}
        if(id!=null)throw new Fault("request");return expected+route.path;
    }
    static String loginCookie(Map<String,List<String>> headers) {
        String answer=null; int count=0;
        for(Map.Entry<String,List<String>> h:headers.entrySet()){
            if(!"Set-Cookie".equalsIgnoreCase(h.getKey()))continue;
            for(String raw:h.getValue()){
                if(raw==null||raw.length()>512)continue;
                String[] parts=raw.split(";",-1);String first=parts[0].trim();
                if(!first.startsWith(COOKIE+"="))continue;
                count++;String value=first.substring(COOKIE.length()+1);
                boolean secure=false,http=false,path=false,strict=false,domain=false;
                for(int i=1;i<parts.length;i++){
                    String part=parts[i].trim().toLowerCase(Locale.ROOT);
                    if(part.equals("secure"))secure=true;
                    if(part.equals("httponly"))http=true;
                    if(part.equals("path=/"))path=true;
                    if(part.equals("samesite=strict"))strict=true;
                    if(part.startsWith("domain="))domain=true;
                }
                if(sessionValue(value)&&secure&&http&&path&&strict&&!domain)answer=value;
            }
        }
        return count==1?answer:null;
    }
    static Reply call(String origin,Route route,String id,String cookie,String data) throws IOException {
        String address=target(origin,route,id);
        int cap=(route==Route.OLD_DESK||route==Route.OLD_USERS)?LEGACY_LIMIT:REPLY_LIMIT;
        return exchange(origin,address.substring(origin.length()),route.post,cookie,data,false,false,route==Route.LOGIN,cap);
    }
    /** Callers supply a validated API route, never a URL provided by a page. */
    static Reply exchange(String origin,String path,boolean post,String cookie,String data,boolean passive,boolean csv,boolean issue,int cap) throws IOException {
        final String canonical=SharedOrigin.canonical(origin);
        if(canonical==null||!canonical.equals(origin)||path==null||!path.startsWith("/api/")||path.length()>4096||cap>LEGACY_LIMIT)throw new Fault("request");
        if(cookie!=null&&!sessionValue(cookie))throw new Fault("request");
        if(CookieHandler.getDefault()!=null)throw new Fault("protocol");
        if(post&&data==null)throw new Fault("request");
        byte[] body=post?data.getBytes(StandardCharsets.UTF_8):null;
        if((post&&body.length>REQUEST_LIMIT)||(!post&&data!=null))throw new Fault("request");
        HttpsURLConnection conn=(HttpsURLConnection)new URL(origin+path).openConnection();
        conn.setInstanceFollowRedirects(false);conn.setUseCaches(false);
        conn.setConnectTimeout(10000);conn.setReadTimeout(14000);
        conn.setRequestMethod(post?"POST":"GET");
        conn.setRequestProperty("Accept",csv?"text/csv, application/json":"application/json");
        conn.setRequestProperty("Accept-Encoding","identity");
        conn.setRequestProperty("Cache-Control","no-store");
        if(passive&&!post)conn.setRequestProperty("X-Qayd-Passive","1");
        if(cookie!=null)conn.setRequestProperty("Cookie",COOKIE+"="+cookie);
        try {
            if(body!=null){
                conn.setDoOutput(true);conn.setFixedLengthStreamingMode(body.length);
                conn.setRequestProperty("Content-Type","application/json; charset=utf-8");
                conn.setRequestProperty("Origin",origin);
                conn.setRequestProperty("X-Qayd-Client","desk-v1");
                try(OutputStream out=conn.getOutputStream()){out.write(body);}
            }
            final int status;
            try{status=conn.getResponseCode();}
            catch(HttpRetryException auth){
                // Some platform clients discard the body of a streamed 401. Never retry a team write.
                if(auth.responseCode()==401)return new Reply(401,"",null);
                throw auth;
            }
            if(status>=300&&status<400)throw new Fault("redirect");
            String encoding=conn.getContentEncoding(),type=conn.getContentType();
            String expected=csv&&status<300?"text/csv":"application/json";
            if(status<200||status>=600||type==null||!type.split(";",2)[0].trim().equalsIgnoreCase(expected)||(encoding!=null&&!encoding.equalsIgnoreCase("identity")))throw new Fault("protocol");
            long size=conn.getContentLengthLong();if(size>cap)throw new Fault("oversize");
            String json;
            try(InputStream in=status>=400?conn.getErrorStream():conn.getInputStream()){
                if(in==null){if(status==401)return new Reply(401,"",null);throw new Fault("protocol");}
                ByteArrayOutputStream read=new ByteArrayOutputStream((int)Math.min(Math.max(size,512),cap));
                byte[] b=new byte[8192];int n;
                long deadline=System.nanoTime()+20_000_000_000L;
                while((n=in.read(b))!=-1){
                    if(read.size()>cap-n)throw new Fault("oversize");
                    if(Thread.currentThread().isInterrupted()||System.nanoTime()>deadline)throw new Fault("network");
                    read.write(b,0,n);
                }
                json=StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(read.toByteArray())).toString();
            }
            return new Reply(status,json,issue&&status==200?loginCookie(conn.getHeaderFields()):null);
        }finally{conn.disconnect();}
    }
}
