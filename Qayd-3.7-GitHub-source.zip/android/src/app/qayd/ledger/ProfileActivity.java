package app.qayd.ledger;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Insets;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import java.io.ByteArrayInputStream;
import java.util.Collections;
import org.json.JSONObject;

/** Packaged first-run/profile selector. No network, login data, or ledger bridge. */
public final class ProfileActivity extends Activity {
    static final String SEED="app.qayd.ledger.PROFILE_SEED", LINK="app.qayd.ledger.PROFILE_LINK";
    private static final String BASE="file:///android_asset/device-profile/", ENTRY=BASE+"index.html";
    private DeviceProfile profile;
    private WebView web;
    private String seed,state;
    private boolean enabled,transition;
    @Override protected void onCreate(Bundle saved){
        super.onCreate(saved);profile=new DeviceProfile(this);
        String savedOrigin=profile.origin(),seedOrigin=SharedOrigin.canonical(getIntent().getStringExtra(SEED));
        seed=savedOrigin!=null?savedOrigin:seedOrigin;
        state="{\"role\":"+JSONObject.quote(profile.role())+",\"origin\":"+JSONObject.quote(seed==null?"":seed)+
            ",\"editing\":"+(getIntent().getBooleanExtra(LINK,false)&&DeviceRole.STAFF.equals(profile.role()))+"}";
        FrameLayout layout=new FrameLayout(this);layout.setBackgroundColor(Color.rgb(243,246,252));
        if(Build.VERSION.SDK_INT>=30){
            getWindow().setDecorFitsSystemWindows(false);
            layout.setOnApplyWindowInsetsListener((v,i)->{
                Insets bars=i.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout()),ime=i.getInsets(WindowInsets.Type.ime());
                v.setPadding(bars.left,bars.top,bars.right,Math.max(bars.bottom,ime.bottom));return WindowInsets.CONSUMED;
            });
        }
        web=new WebView(this);web.setBackgroundColor(Color.rgb(243,246,252));layout.addView(web,new FrameLayout.LayoutParams(-1,-1));setContentView(layout);
        WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(false);s.setAllowFileAccess(false);s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);s.setAllowUniversalAccessFromFileURLs(false);s.setBlockNetworkLoads(true);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);s.setJavaScriptCanOpenWindowsAutomatically(false);s.setSupportMultipleWindows(false);s.setSaveFormData(false);s.setTextZoom(100);
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return !r.isForMainFrame()||!ENTRY.equals(r.getUrl().toString());}
            @Override public boolean shouldOverrideUrlLoading(WebView v,String url){return !ENTRY.equals(url);}
            @Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest r){
                String url=r.getUrl().toString();
                if("GET".equals(r.getMethod())&&url.startsWith(BASE)&&url.substring(BASE.length()).matches("(?:index\\.html|profile\\.(?:js|css)|shared-link\\.js|icons\\.js|logo\\.svg|fonts/(?:fonts\\.css|plex-(?:arabic|latin)-(?:400|500|600|700)\\.woff2))"))return null;
                return new WebResourceResponse("text/plain","utf-8",403,"Blocked",Collections.emptyMap(),new ByteArrayInputStream(new byte[0]));
            }
            @Override public void onReceivedSslError(WebView v,SslErrorHandler h,SslError e){h.cancel();}
        });
        web.addJavascriptInterface(new Bridge(),"QaydProfile");web.loadUrl(ENTRY);
    }
    private boolean active(){return web!=null&&enabled&&!transition&&!isFinishing();}
    private void error(String message){if(active())web.evaluateJavascript("window.qaydProfileError && window.qaydProfileError("+JSONObject.quote(message)+")",null);}
    private final class Bridge {
        @JavascriptInterface public String setup(){return state;}
        @JavascriptInterface public void leave(){runOnUiThread(()->{if(active())finish();});}
        @JavascriptInterface public void choose(String role,String origin){runOnUiThread(()->select(role,origin));}
    }
    private void select(String role,String raw){
        if(!active())return;
        Intent to;
        if(DeviceRole.MANAGER.equals(role)){
            if(!profile.chooseManager()){error("تعذّر حفظ وضع المدير. تحقّق من مساحة الهاتف.");return;}
            to=new Intent(this,MainActivity.class).setAction(Intent.ACTION_MAIN);
        }else if(DeviceRole.STAFF.equals(role)){
            String origin=SharedOrigin.canonical(raw);
            if(origin==null){error("أدخل رابط HTTPS لدفتر المدير دون مسار أو كلمة سر.");return;}
            if(!profile.chooseStaff(origin)){error("تعذّر حفظ رابط المدير على الهاتف.");return;}
            to=SharedDeskActivity.employeeIntent(this,origin);
        }else return;
        transition=true;
        startActivity(to.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK));
        finish();
    }
    @Override protected void onResume(){super.onResume();enabled=true;}
    @Override protected void onPause(){enabled=false;super.onPause();}
    @Override public void onBackPressed(){
        if(!active()){finish();return;}
        web.evaluateJavascript("window.qaydProfileBack ? window.qaydProfileBack() : false",r->{if(active()&&!"true".equals(r))finish();});
    }
    @Override protected void onDestroy(){if(web!=null){web.removeJavascriptInterface("QaydProfile");web.destroy();web=null;}super.onDestroy();}
}
