package app.qayd.ledger;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;

/** Exposes only generated exports via temporary Android read grants. */
public final class ShareProvider extends ContentProvider {
    @Override public boolean onCreate() { return true; }
    private File exported(Uri uri) {
        List<String> p = uri.getPathSegments();
        if(p.size()!=2 || !p.get(0).matches("[a-f0-9-]{36}") || !p.get(1).matches("qayd-[A-Za-z0-9_-]{1,105}\\.(json|csv|db|pdf|xlsx)")) throw new IllegalArgumentException("Invalid export URI");
        return new File(new File(new File(getContext().getCacheDir(),"shares"),p.get(0)),p.get(1));
    }
    private boolean capture(Uri uri){List<String> p=uri.getPathSegments();return p.size()==3&&"capture".equals(p.get(0))&&p.get(1).matches("[a-f0-9-]{36}")&&"receipt.jpg".equals(p.get(2));}
    private File captured(Uri uri){return new File(new File(new File(getContext().getCacheDir(),"captures"),uri.getPathSegments().get(1)),"receipt.jpg");}
    @Override public String getType(Uri uri) {
        if(capture(uri))return "image/jpeg";
        String name=exported(uri).getName();
        if(name.endsWith(".db"))return BackupDbFile.MIME;
        if(name.endsWith(".pdf"))return PdfExport.MIME;
        if(name.endsWith(".xlsx"))return WorkbookExport.MIME;
        if(name.endsWith(".csv"))return "text/csv";
        return "application/json";
    }
    @Override public Cursor query(Uri uri,String[] projection,String selection,String[] args,String order) {
        File f = capture(uri)?captured(uri):exported(uri);
        String[] cols = projection == null ? new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE} : projection;
        MatrixCursor out = new MatrixCursor(cols);
        if(!f.isFile())return out;
        Object[] values=new Object[cols.length];
        for(int i=0;i<cols.length;i++){
            if(OpenableColumns.DISPLAY_NAME.equals(cols[i])) values[i] = f.getName();
            else if(OpenableColumns.SIZE.equals(cols[i])) values[i] = f.length();
        }
        out.addRow(values);return out;
    }
    @Override public ParcelFileDescriptor openFile(Uri uri,String mode) throws FileNotFoundException {
        if(capture(uri))return ParcelFileDescriptor.open(captured(uri),ParcelFileDescriptor.parseMode(mode));
        if(!"r".equals(mode))throw new FileNotFoundException("Read only");
        return ParcelFileDescriptor.open(exported(uri),ParcelFileDescriptor.MODE_READ_ONLY);
    }
    @Override public Uri insert(Uri u,ContentValues v){throw new UnsupportedOperationException();}
    @Override public int update(Uri u,ContentValues v,String s,String[] a){throw new UnsupportedOperationException();}
    @Override public int delete(Uri u,String s,String[] a){throw new UnsupportedOperationException();}
}
