package app.qayd.ledger;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Insets;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.SslErrorHandler;
import android.net.http.SslError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;
import java.io.ByteArrayInputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONObject;

/** Packaged online workspace. This view has no offline-ledger or device bridge.
 * Every server response is API data only; no remote document runs in the view. */
public final class SharedDeskActivity extends Activity {
    static final String ORIGIN="app.qayd.ledger.SHARED_ORIGIN";
    static final String QUICK_POST="app.qayd.ledger.QUICK_POST";
    private static final String EMPLOYEE="app.qayd.ledger.EMPLOYEE_MODE";
    static Intent employeeIntent(android.content.Context context,String at){
        return new Intent(context,SharedDeskActivity.class).putExtra(ORIGIN,at).putExtra(EMPLOYEE,true);
    }
    private static final String ASSET="file:///android_asset/shared-desk/", ENTRY=ASSET+"index.html";
    private static final int CHUNK=48*1024, CREATE_CSV=361, CSV_LIMIT=2*1024*1024;
    private FrameLayout root;
    private WebView web;
    private SharedDeskClient client;
    private DeviceProfile profile;
    private boolean employee;
    private final AtomicBoolean quickPost=new AtomicBoolean(false);
    private String origin, writeNoticeKey;
    private volatile long generation;
    private volatile boolean visible;
    private byte[] pendingCsv;
    private final ExecutorService exports=Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);
        origin=SharedOrigin.canonical(getIntent().getStringExtra(ORIGIN));
        employee=getIntent().getBooleanExtra(EMPLOYEE,false);
        profile=new DeviceProfile(this);
        if(origin==null||!currentProfile()){finish();return;}
        quickPost.set(!employee&&saved==null&&getIntent().getBooleanExtra(QUICK_POST,false));
        getIntent().removeExtra(QUICK_POST);
        writeNoticeKey=(employee?"staff|":"manager|")+origin;
        client=new SharedDeskClient(origin,employee?new StaffLoginVault(this,profile,origin):null);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        root=new FrameLayout(this);root.setBackgroundColor(Color.rgb(242,245,251));
        if(Build.VERSION.SDK_INT>=30){
            getWindow().setDecorFitsSystemWindows(false);
            root.setOnApplyWindowInsetsListener((v,insets)->{
                Insets bars=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout()),ime=insets.getInsets(WindowInsets.Type.ime());
                v.setPadding(bars.left,bars.top,bars.right,Math.max(bars.bottom,ime.bottom));return WindowInsets.CONSUMED;
            });
        }
        setContentView(root);
    }
    private boolean currentProfile(){return employee?profile.bound(origin):DeviceRole.MANAGER.equals(profile.role());}
    static boolean permittedAsset(String url){
        if(url==null||!url.startsWith(ASSET))return false;
        String tail=url.substring(ASSET.length());
        return tail.matches("(?:index\\.html|desk\\.(?:css|js)|operations\\.js|embedded\\.css|transport\\.js|assets/(?:logo\\.svg|release\\.js|icons\\.js|ledger\\.js|fonts/(?:fonts\\.css|plex-(?:arabic|latin)-(?:400|500|600|700)\\.woff2)))");
    }
    private void openView(){
        long when=++generation;
        web=new WebView(this);web.setBackgroundColor(Color.rgb(242,245,251));
        if(Build.VERSION.SDK_INT>=26)web.setImportantForAutofill(android.view.View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);
        root.addView(web,new FrameLayout.LayoutParams(-1,-1));
        WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(false);
        s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setAllowUniversalAccessFromFileURLs(false);s.setAllowFileAccessFromFileURLs(false);
        s.setBlockNetworkLoads(true);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        s.setJavaScriptCanOpenWindowsAutomatically(false);s.setSupportMultipleWindows(false);s.setSaveFormData(false);s.setTextZoom(100);
        android.webkit.CookieManager.getInstance().setAcceptCookie(false);
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return !r.isForMainFrame()||!ENTRY.equals(r.getUrl().toString());}
            @Override public boolean shouldOverrideUrlLoading(WebView v,String url){return !ENTRY.equals(url);}
            @Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest r){
                return "GET".equals(r.getMethod())&&permittedAsset(r.getUrl().toString())?null:
                    new WebResourceResponse("text/plain","utf-8",403,"Blocked",Collections.emptyMap(),new ByteArrayInputStream(new byte[0]));
            }
            @Override public void onReceivedSslError(WebView v,SslErrorHandler h,SslError e){h.cancel();}
        });
        web.addJavascriptInterface(new Bridge(when),"QaydDesk");web.loadUrl(ENTRY);
    }
    private boolean live(long when){return visible&&web!=null&&generation==when&&!isFinishing();}
    private void sendChunks(long when,String id,int status,String encoded,int start){
        if(!live(when))return;
        int end=Math.min(encoded.length(),start+CHUNK);boolean done=end==encoded.length();
        String script="window.qaydDeskReply && window.qaydDeskReply("+JSONObject.quote(id)+","+status+","+
            JSONObject.quote(encoded.substring(start,end))+","+done+")";
        web.evaluateJavascript(script,r->{if(!done)sendChunks(when,id,status,encoded,end);});
    }
    private final class Bridge {
        private final long when;
        Bridge(long when){this.when=when;}
        @JavascriptInterface public String origin(){return origin;}
        @JavascriptInterface public boolean employeeMode(){return employee;}
        @JavascriptInterface public boolean takeQuickPost(){return visible&&generation==when&&!employee&&quickPost.getAndSet(false);}
        // Only a status marker for this role and HTTPS origin survives a view restart.
        // Never store the request, user, record ID, amount, session or a retry queue.
        @JavascriptInterface public String readWriteNotice(){
            if(!visible||generation!=when||!currentProfile())return "";
            return getSharedPreferences("qayd.shared.write-notice.v1",MODE_PRIVATE).getString(writeNoticeKey,"");
        }
        @JavascriptInterface public boolean writeWriteNotice(String state){
            if(!visible||generation!=when||!currentProfile())return false;
            android.content.SharedPreferences.Editor edit=getSharedPreferences("qayd.shared.write-notice.v1",MODE_PRIVATE).edit();
            if("uncertain".equals(state)||"saved".equals(state))return edit.putString(writeNoticeKey,state).commit();
            if("".equals(state))return edit.remove(writeNoticeKey).commit();
            return false;
        }
        @JavascriptInterface public boolean canRemember(){return employee&&client.canKeep();}
        @JavascriptInterface public boolean hasRemembered(){return employee&&client.kept();}
        @JavascriptInterface public boolean forgetRemembered(){return client.forget();}
        @JavascriptInterface public void changeManager(){runOnUiThread(()->{
            if(!live(when)||!employee)return;
            client.clear();startActivity(new Intent(SharedDeskActivity.this,ProfileActivity.class).putExtra(ProfileActivity.LINK,true));
        });}
        @JavascriptInterface public void request(String id,String route,String json,boolean passive,boolean remember){
            if(!SharedDeskClient.ticket(id))return;
            runOnUiThread(()->{
                if(!live(when))return;
                client.request(id,route,json,passive,remember,(ticket,status,data)->{
                    String enc=Base64.encodeToString(data.getBytes(StandardCharsets.UTF_8),Base64.NO_WRAP);
                    runOnUiThread(()->sendChunks(when,ticket,status,enc,0));
                });
            });
        }
        @JavascriptInterface public void clear(){runOnUiThread(()->{if(live(when))client.clear();});}
        @JavascriptInterface public void exit(){runOnUiThread(()->{if(live(when))finish();});}
        @JavascriptInterface public void openMaintenance(){runOnUiThread(()->{
            if(!live(when)||employee||!currentProfile())return;
            // External browser, on the exact configured HTTPS origin. No file, session or credentials cross over.
            Intent link=new Intent(Intent.ACTION_VIEW,Uri.parse(origin+"/#maintenance")).addCategory(Intent.CATEGORY_BROWSABLE);
            try{startActivity(link);}catch(ActivityNotFoundException|SecurityException e){notice("افتح عنوان الدفتر في المتصفح ثم اختر إعدادات الدفتر.");}
        });}
        @JavascriptInterface public void saveCsv(String name,String csv){
            if(name==null||!name.matches("qayd-(?:report|aging)-[A-Za-z0-9-]{1,45}\\.csv")||csv==null||csv.length()>CSV_LIMIT)return;
            final byte[] bytes=csv.getBytes(StandardCharsets.UTF_8);
            runOnUiThread(()->{
                if(!live(when)||pendingCsv!=null)return;
                if(bytes.length>CSV_LIMIT){notice("التقرير أكبر من حد التنزيل على الهاتف.");return;}
                Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("text/csv").putExtra(Intent.EXTRA_TITLE,name);
                pendingCsv=bytes;
                try{startActivityForResult(i,CREATE_CSV);}catch(ActivityNotFoundException|SecurityException x){pendingCsv=null;notice("لا يوجد مدير ملفات متاح.");}
            });
        }
    }
    private void notice(String text){if(!isFinishing())Toast.makeText(this,text,Toast.LENGTH_LONG).show();}
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request!=CREATE_CSV)return;
        byte[] b=pendingCsv;pendingCsv=null;
        Uri out=result==RESULT_OK&&data!=null?data.getData():null;
        if(b==null||out==null||!"content".equals(out.getScheme()))return;
        exports.execute(()->{
            boolean ok=false;
            try(OutputStream stream=getContentResolver().openOutputStream(out,"wt")){
                if(stream!=null){stream.write(b);stream.flush();ok=true;}
            }catch(Exception ignored){}
            String m=ok?"حُفظ تقرير CSV في المكان المختار.":"لم يُحفظ التقرير. جرّب مكانًا آخر.";
            runOnUiThread(()->notice(m));
        });
    }
    @Override protected void onResume(){
        super.onResume();if(root==null)return;if(!currentProfile()){finish();return;}
        visible=true;if(web==null)openView();
    }
    private void dispose(){
        visible=false;generation++;
        if(client!=null)client.clear();
        if(web!=null){web.removeJavascriptInterface("QaydDesk");web.stopLoading();root.removeView(web);web.destroy();web=null;}
    }
    @Override protected void onStop(){dispose();super.onStop();}
    @Override public void onBackPressed(){
        if(web==null){finish();return;}
        long when=generation;
        web.evaluateJavascript("window.qaydDeskBack ? window.qaydDeskBack() : false",r->{if(live(when)&&!"true".equals(r))finish();});
    }
    @Override protected void onDestroy(){dispose();if(client!=null)client.close();pendingCsv=null;exports.shutdown();super.onDestroy();}
}
