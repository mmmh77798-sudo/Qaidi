package app.qayd.ledger;

import java.io.IOException;
import java.io.OutputStream;

/** Writes only bounded, monochrome ESC/POS raster jobs built by the receipt view. */
final class ThermalRaster {
    static final int MAX_HEIGHT=7040;
    private static final int STRIPE=80;
    private ThermalRaster(){}
    static int bytes(int width,int height){
        if((width!=384&&width!=512&&width!=576)||height<1||height>MAX_HEIGHT)return -1;
        return (width/8)*height;
    }
    static boolean request(int width,int height,String base64){
        int n=bytes(width,height);
        return n>0&&base64!=null&&base64.length()==4*((n+2)/3);
    }
    static void write(OutputStream out,int width,int height,byte[] image)throws IOException {
        int size=bytes(width,height);
        if(size<1||image==null||image.length!=size)throw new IOException("Invalid receipt bitmap");
        int scan=width/8;
        out.write(new byte[]{0x1b,0x40}); // initialise, no cash drawer command
        for(int y=0;y<height;y+=STRIPE){
            int h=Math.min(STRIPE,height-y);
            out.write(new byte[]{0x1d,0x76,0x30,0,(byte)scan,(byte)(scan>>8),(byte)h,(byte)(h>>8)});
            out.write(image,y*scan,h*scan);
        }
        out.write(new byte[]{0x1b,0x64,0x03}); // feed; cutting is not required on portable paper rolls
        out.flush();
    }
}
