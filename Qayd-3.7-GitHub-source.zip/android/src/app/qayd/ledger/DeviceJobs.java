package app.qayd.ledger;

import android.Manifest;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.DocumentsContract;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.OutputStream;
import java.io.File;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TreeSet;

final class DeviceJobs {
    private static final String PREF="qayd-jobs";
    static final String BACKUP="app.qayd.ledger.AUTO_BACKUP", REMIND="app.qayd.ledger.REMIND";
    private static final String CHANNEL="qayd-ledger-events";
    static SharedPreferences prefs(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE);}
    static String day(Calendar time){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(time.getTime());}
    static String today(){return day(new GregorianCalendar());}
    static String status(Context c){
        SharedPreferences p=prefs(c);JSONObject o=new JSONObject();
        try {o.put("folder",p.getString("folderLabel",""));o.put("time",p.getString("time","00:00"));o.put("enabled",p.getBoolean("auto",false));o.put("last",p.getString("savedDate",""));o.put("error",p.getBoolean("backupError",false));}catch(Exception ignored){}
        return o.toString();
    }
    static String configureBackup(Context c,boolean enabled,String time){
        if(time==null||!time.matches("(?:[01][0-9]|2[0-3]):[0-5][0-9]"))return "اختر وقتًا صالحًا.";
        SharedPreferences p=prefs(c);if(enabled&&p.getString("tree","").isEmpty())return "اختر مجلد الحفظ قبل تفعيل الجدولة.";
        p.edit().putString("time",time).putBoolean("auto",enabled).apply();schedule(c);return "ok";
    }
    static void useFolder(Context c,Uri tree){
        SharedPreferences p=prefs(c);String old=p.getString("tree","");
        c.getContentResolver().takePersistableUriPermission(tree,Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        String label=DocumentsContract.getTreeDocumentId(tree);int index=Math.max(label.lastIndexOf('/'),label.lastIndexOf(':'));
        p.edit().putString("tree",tree.toString()).putString("folderLabel",label.substring(index+1)).remove("digest").remove("savedDate").putBoolean("backupError",false).apply();
        if(!old.isEmpty()&&!tree.toString().equals(old))try{c.getContentResolver().releasePersistableUriPermission(Uri.parse(old),Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);}catch(Exception ignored){}
        schedule(c);
    }
    static void reminderDates(Context c,String json){
        if(json==null||json.length()>140000)return;
        try{
            TreeSet<String> set=new TreeSet<>();JSONArray a=new JSONArray(json);String today=today();
            for(int i=0;i<a.length();i++){String date=a.optString(i,"");if(date.matches("[1-9][0-9]{3}-[0-9]{2}-[0-9]{2}")&&date.compareTo(today)>=0)set.add(date);}
            String list=android.text.TextUtils.join(",",set); SharedPreferences p=prefs(c);
            if(!list.equals(p.getString("reminders",""))){p.edit().putString("reminders",list).apply();schedule(c);}
        }catch(Exception ignored){}
    }
    private static PendingIntent alarm(Context c,String action,int id){return PendingIntent.getBroadcast(c,id,new Intent(c,JobReceiver.class).setAction(action),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
    static synchronized void schedule(Context c){
        SharedPreferences p=prefs(c); AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);if(am==null)return;
        try {
            PendingIntent backup=alarm(c,BACKUP,840),reminder=alarm(c,REMIND,841);
            am.cancel(backup);am.cancel(reminder);
            long now=System.currentTimeMillis();Calendar cur=new GregorianCalendar();
            if(p.getBoolean("auto",false)&&!p.getString("tree","").isEmpty()){
                String t=p.getString("time","00:00");Calendar next=(Calendar)cur.clone();
                next.set(Calendar.HOUR_OF_DAY,Integer.parseInt(t.substring(0,2)));next.set(Calendar.MINUTE,Integer.parseInt(t.substring(3,5)));next.set(Calendar.SECOND,0);next.set(Calendar.MILLISECOND,0);
                if(next.getTimeInMillis()<=now)next.add(Calendar.DAY_OF_MONTH,1);
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,next.getTimeInMillis(),backup);
            }
            String today=day(cur),attempted=p.getString("triedReminder","");
            for(String d:p.getString("reminders","").split(",")){
                if(d.compareTo(today)<0||d.equals(attempted))continue;
                int y=Integer.parseInt(d.substring(0,4)),m=Integer.parseInt(d.substring(5,7))-1,j=Integer.parseInt(d.substring(8,10));
                Calendar when=new GregorianCalendar(y,m,j,9,0,0);
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,Math.max(now+5000,when.getTimeInMillis()),reminder);break;
            }
        }catch(RuntimeException ignored){}
    }
    static void saveDaily(Context c){
        SharedPreferences p=prefs(c);if(!p.getBoolean("auto",false))return;
        String dir=p.getString("tree",""),today=today();if(dir.isEmpty()||today.equals(p.getString("savedDate","")))return;
        Uri created=null;File prepared=null;
        try {
            byte[] b=new LedgerStorage(c).bytes(true);if(b==null||b.length==0)return;
            String digest="db1:"+android.util.Base64.encodeToString(MessageDigest.getInstance("SHA-256").digest(b),android.util.Base64.NO_WRAP);
            if(digest.equals(p.getString("digest","")))return;
            Uri tree=Uri.parse(dir), parent=DocumentsContract.buildDocumentUriUsingTree(tree,DocumentsContract.getTreeDocumentId(tree));
            prepared=File.createTempFile("qayd-daily-",".db",c.getCacheDir());
            BackupDbFile.write(prepared,b);
            created=DocumentsContract.createDocument(c.getContentResolver(),parent,BackupDbFile.MIME,"qayd-daily-"+today+".db");
            if(created==null)throw new IllegalStateException();
            try(OutputStream os=c.getContentResolver().openOutputStream(created,"w")) {if(os==null)throw new IllegalStateException();BackupDbFile.copy(prepared,os);}
            p.edit().putString("digest",digest).putString("savedDate",today).putBoolean("backupError",false).apply();
        }catch(Exception e){if(created!=null)try{DocumentsContract.deleteDocument(c.getContentResolver(),created);}catch(Exception ignored){}p.edit().putBoolean("backupError",true).apply();}
        finally{BackupDbFile.delete(prepared);}
    }
    static void remind(Context c){
        SharedPreferences p=prefs(c);String d=today();if(d.equals(p.getString("triedReminder","")))return;
        for(String day:p.getString("reminders","").split(","))if(d.equals(day)){
            p.edit().putString("triedReminder",d).apply();
            notify(c,807,"لديك تذكير حساب مستحق اليوم.");return;
        }
    }
    static void notify(Context c,int id,String text){
        if(Build.VERSION.SDK_INT>=33&&c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
        NotificationManager nm=c.getSystemService(NotificationManager.class);if(nm==null||!nm.areNotificationsEnabled())return;
        Notification.Builder b;
        if(Build.VERSION.SDK_INT>=26){nm.createNotificationChannel(new NotificationChannel(CHANNEL,"تنبيهات قيد",NotificationManager.IMPORTANCE_DEFAULT));b=new Notification.Builder(c,CHANNEL);}else b=new Notification.Builder(c);
        Intent view=new Intent(c,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        b.setSmallIcon(R.drawable.qayd_notice).setContentTitle("قيد").setContentText(text).setAutoCancel(true).setVisibility(Notification.VISIBILITY_PRIVATE).setContentIntent(PendingIntent.getActivity(c,802,view,PendingIntent.FLAG_IMMUTABLE));
        try{nm.notify(id,b.build());}catch(RuntimeException ignored){}
    }
}
