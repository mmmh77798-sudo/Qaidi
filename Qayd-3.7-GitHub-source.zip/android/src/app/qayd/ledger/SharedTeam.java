package app.qayd.ledger;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.util.Iterator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.net.ssl.SSLException;
import static app.qayd.ledger.TeamHttp.Route;

/** Maintains one in-memory owner session, independent of the offline ledger and the WebView cookie jar. */
final class SharedTeam {
    interface Callback {void reply(String ticket,int status,String value);}
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private String origin=null,cookie=null;
    private long generation;
    private boolean busy,closed;
    static boolean ticket(String s){return s!=null&&s.matches("team-[0-9]{1,15}");}
    private static Route route(String op){
        if(op==null)return null;
        switch(op){
            case "login":return Route.LOGIN;
            case "team":return Route.TEAM;
            case "member":return Route.MEMBER;
            case "create":return Route.CREATE;
            case "update":return Route.UPDATE;
            case "reset":return Route.RESET;
            case "revoke":return Route.REVOKE;
            case "logout":return Route.LOGOUT;
            default:return null;
        }
    }
    private static String[] fields(Route r){
        switch(r){
            case LOGIN:return new String[]{"login","password","otp"};
            case MEMBER:return new String[]{"id"};
            case CREATE:return new String[]{"login","name","grants"};
            case UPDATE:return new String[]{"id","version","name","grants","enabled"};
            case RESET:case REVOKE:return new String[]{"id","version"};
            default:return new String[0];
        }
    }
    private static JSONObject payload(Route route,String raw)throws JSONException,TeamHttp.Fault{
        if(raw==null||raw.length()>TeamHttp.REQUEST_LIMIT)throw new TeamHttp.Fault("request");
        JSONObject in=new JSONObject(raw),out=new JSONObject();String[] fields=fields(route);
        for(Iterator<String> keys=in.keys();keys.hasNext();){
            String key=keys.next();boolean found=false;
            for(String f:fields)if(f.equals(key)){found=true;break;}
            if(!found)throw new TeamHttp.Fault("request");out.put(key,in.get(key));
        }
        if((out.has("id")&&!TeamHttp.memberId(string(out,"id",36)))||(out.has("version")&&!TeamHttp.memberId(string(out,"version",36))))throw new TeamHttp.Fault("request");
        switch(route){
            case LOGIN:string(out,"login",32);string(out,"password",128);if(out.has("otp"))string(out,"otp",30);break;
            case MEMBER:if(!out.has("id"))throw new TeamHttp.Fault("request");break;
            case CREATE:case UPDATE:
                string(out,"name",60);out.put("grants",grantList(out));
                if(route==Route.CREATE)string(out,"login",32);
                else if(!out.has("id")||!out.has("version")||!(out.opt("enabled") instanceof Boolean))throw new TeamHttp.Fault("request");
                break;
            case RESET:case REVOKE:if(!out.has("id")||!out.has("version"))throw new TeamHttp.Fault("request");break;
            default:break;
        }
        return out;
    }
    private static JSONObject error(String code,String message) {
        try{return new JSONObject().put("code",code).put("error",message);}catch(JSONException impossible){return new JSONObject();}
    }
    private static JSONObject fault(String code){
        String m;
        switch(code){
            case "origin":m="أدخل عنوان HTTPS صحيحًا ومباشرًا لخادم الدفتر.";break;
            case "request":m="لم يُرسل الطلب؛ حقوله أو حجمه غير مدعوم.";break;
            case "credentials":m="اسم المستخدم أو كلمة السر غير صحيحة.";break;
            case "mfa-invalid":m="اسم الدخول أو كلمة السر أو رمز التحقق غير صالح. جرّب مرة أخرى أو استخدم رمز استرداد.";break;
            case "login":m="انتهت جلسة الفريق. سجّل دخول المالك من جديد.";break;
            case "owner":m="هذه الصفحة لحساب المالك. يدخل الموظف من رابط الدفتر باسمه المستقل.";break;
            case "demo":m="هذا عنوان المعاينة، لا دفتر حقيقي. لا تستخدم فيه بيانات دخولك.";break;
            case "inactive":m="ارجع إلى التطبيق في الواجهة ثم أعد الاتصال.";break;
            case "busy":m="تجري عملية اتصال بالفعل. انتظر قليلًا ثم حدّث القائمة.";break;
            case "tls":m="لم يتم التحقق من شهادة HTTPS للخادم. تأكد من العنوان والشهادة ووقت الجهاز.";break;
            case "redirect":m="عنوان الخادم يعيد التوجيه. احفظ رابط HTTPS النهائي المباشر.";break;
            case "oversize":m="استجابة الخادم أكبر من الحد. حدّث خادم قيد إلى إصدار 3.1 أو أحدث.";break;
            case "protocol":m="لم يرد خادم قيد بالصيغة المتوقعة. راجع عنوان الاتصال وإصدار الخادم.";break;
            default:m="تعذّر تأكيد الاتصال. تحقّق من الإنترنت والعنوان. بعد محاولة حفظ، حدّث قبل تكرارها.";
        }
        return error(code,m);
    }
    static String inactive(){return fault("inactive").toString();}
    private static String string(JSONObject x,String name,int max)throws JSONException{
        Object v=x.get(name);
        if(!(v instanceof String)||((String)v).length()>max)throw new JSONException("shape");
        return (String)v;
    }
    private static JSONArray array(JSONObject x,String name,int max)throws JSONException{
        JSONArray value=x.getJSONArray(name);if(value.length()>max)throw new JSONException("shape");return value;
    }
    private static JSONArray grantList(JSONObject x)throws JSONException{
        JSONArray grants=array(x,"grants",201),out=new JSONArray();
        for(int i=0;i<grants.length();i++){
            JSONObject g=grants.getJSONObject(i);String category=string(g,"category",80);JSONArray allow=array(g,"allow",32),safe=new JSONArray();
            if(g.length()!=2||!category.matches("[A-Za-z0-9_-]{0,80}"))throw new JSONException("grant");
            for(int j=0;j<allow.length();j++){
                Object v=allow.get(j);if(!(v instanceof String)||!((String)v).matches("[a-zA-Z][a-zA-Z0-9_]{0,31}"))throw new JSONException("grant");safe.put(v);
            }
            out.put(new JSONObject().put("category",category).put("allow",safe));
        }
        return out;
    }
    private static JSONObject profile(JSONObject x,boolean details)throws JSONException{
        String id=string(x,"id",40),version=string(x,"version",40),login=string(x,"login",32);
        if(!TeamHttp.memberId(id)||!TeamHttp.memberId(version)||!login.matches("[a-z0-9][a-z0-9._-]{2,31}"))throw new JSONException("profile");
        JSONObject u=new JSONObject().put("id",id).put("version",version).put("login",login).put("name",string(x,"name",60))
            .put("owner",x.getBoolean("owner")).put("enabled",x.getBoolean("enabled")).put("mustChange",x.getBoolean("mustChange")).put("mfa",x.optBoolean("mfa",false));
        if(details){
            JSONArray grants=grantList(x);u.put("grants",grants).put("scopeCount",grants.length());
        }else{
            JSONArray grants=x.optJSONArray("grants");int count=grants==null?x.optInt("scopeCount",0):grants.length();u.put("scopeCount",Math.max(0,Math.min(count,201)));
        }
        return u;
    }
    private static JSONObject operations(JSONObject src)throws JSONException{
        JSONObject x=src.getJSONObject("actions"),out=new JSONObject();
        if(x.length()>32||!x.has("view"))throw new JSONException("actions");
        for(Iterator<String> it=x.keys();it.hasNext();){String k=it.next();if(!k.matches("[A-Za-z][A-Za-z0-9_]{0,31}"))throw new JSONException("action");out.put(k,string(x,k,100));}
        return out;
    }
    private static JSONObject team(JSONObject meta,JSONObject people)throws JSONException{
        JSONObject actor=profile(meta.getJSONObject("me"),false);if(!actor.getBoolean("owner"))throw new JSONException("owner");
        JSONArray cats=array(meta,"categories",201),users=array(people,"users",100),cleanCats=new JSONArray(),cleanUsers=new JSONArray();
        for(int i=0;i<cats.length();i++){
            JSONObject row=cats.getJSONObject(i);String id=string(row,"id",80);if(!id.matches("[A-Za-z0-9_-]{0,80}"))throw new JSONException("category");
            cleanCats.put(new JSONObject().put("id",id).put("name",string(row,"name",50)));
        }
        for(int i=0;i<users.length();i++){JSONObject row=profile(users.getJSONObject(i),false);if(!row.getBoolean("owner"))cleanUsers.put(row);}
        JSONObject answer=new JSONObject().put("me",actor).put("categories",cleanCats).put("users",cleanUsers);
        if(meta.has("actions"))answer.put("actions",operations(meta));
        return answer;
    }
    private static final class Result {
        final int status;final JSONObject value;final String issued;
        Result(int status,JSONObject value,String issued){this.status=status;this.value=value;this.issued=issued;}
    }
    private static Result failure(int n,String code){return new Result(n,fault(code),null);}
    private static Result failed(TeamHttp.Reply r,JSONObject raw){
        String e=raw.optString("error",""),c=raw.optString("code","");
        if(e.length()==0||e.length()>350)e="تعذّر إتمام الطلب على الخادم. حدّث البيانات وتحقق من الاتصال.";
        if(c.length()>40)c="";
        return new Result(r.status,error(c,e),null);
    }
    private static JSONObject read(TeamHttp.Reply r)throws JSONException{return new JSONObject(r.json);}
    private static Result run(String at,Route route,JSONObject in,String saved)throws IOException,JSONException{
        JSONObject available=null;
        if(route==Route.LOGIN){
            TeamHttp.Reply info=TeamHttp.call(at,Route.INFO,null,null,null);JSONObject p=read(info);
            if(info.status!=200)return failed(info,p);
            if(!p.has("demo"))return failure(502,"protocol");
            if(p.getBoolean("demo"))return failure(403,"demo");
            available=operations(p);
        }
        String member=route==Route.MEMBER?in.getString("id"):null;
        TeamHttp.Reply r=TeamHttp.call(at,route,member,saved,route.post?in.toString():null);
        if(r.status==401){
            if(route!=Route.LOGIN)return failure(401,"login");
            if(r.json.isEmpty())return failure(401,in.has("otp")?"mfa-invalid":"credentials");
        }
        JSONObject json=read(r);
        // Backward compatibility with already deployed shared servers. Only projected team information crosses the bridge.
        if((route==Route.TEAM||route==Route.MEMBER)&&r.status==404&&"not-found".equals(json.optString("code"))){
            TeamHttp.Reply oldUsers=TeamHttp.call(at,Route.OLD_USERS,null,saved,null);JSONObject people=read(oldUsers);
            if(oldUsers.status!=200)return failed(oldUsers,people);
            if(route==Route.MEMBER){
                JSONArray users=array(people,"users",100);
                for(int i=0;i<users.length();i++){JSONObject x=users.getJSONObject(i);if(member.equals(x.optString("id"))&&!x.getBoolean("owner"))return new Result(200,new JSONObject().put("user",profile(x,true)),null);}
                return failed(r,json);
            }
            TeamHttp.Reply oldDesk=TeamHttp.call(at,Route.OLD_DESK,null,saved,null);JSONObject meta=read(oldDesk);
            if(oldDesk.status!=200)return failed(oldDesk,meta);
            return new Result(200,team(meta,people),null);
        }
        if(r.status<200||r.status>=300)return failed(r,json);
        JSONObject value;
        switch(route){
            case LOGIN:{
                JSONObject me=profile(json.getJSONObject("me"),false);
                if(!me.getBoolean("owner")||me.getBoolean("mustChange"))return failure(403,"owner");
                if(!TeamHttp.sessionValue(r.cookie))return failure(502,"protocol");
                value=new JSONObject().put("me",me).put("actions",available);
                return new Result(r.status,value,r.cookie);
            }
            case TEAM:value=team(json,json);break;
            case MEMBER:value=new JSONObject().put("user",profile(json.getJSONObject("user"),true));break;
            case CREATE:case RESET:case UPDATE:case REVOKE:
                value=new JSONObject().put("user",profile(json.getJSONObject("user"),true));
                if(route==Route.CREATE||route==Route.RESET){String once=string(json,"temporary",24);if(!once.matches("[A-Za-z0-9_-]{24}"))throw new JSONException("temporary");value.put("temporary",once);}
                break;
            case LOGOUT:value=new JSONObject().put("ok",true);break;
            default:return failure(502,"protocol");
        }
        return new Result(r.status,value,null);
    }
    synchronized void request(String ticket,String candidate,String operation,String raw,Callback callback){
        if(closed||!ticket(ticket))return;
        final Route route=route(operation);final String at=SharedOrigin.canonical(candidate);
        if(at==null){callback.reply(ticket,400,fault("origin").toString());return;}
        if(route==null){callback.reply(ticket,400,fault("request").toString());return;}
        if(busy){callback.reply(ticket,409,fault("busy").toString());return;}
        final JSONObject fields;
        try{fields=payload(route,raw);}catch(Exception invalid){callback.reply(ticket,400,fault("request").toString());return;}
        final String prior=at.equals(origin)?cookie:null;
        if(route!=Route.LOGIN&&prior==null){callback.reply(ticket,401,fault("login").toString());return;}
        if(route==Route.LOGIN||route==Route.LOGOUT){cookie=null;origin=null;}
        final long when=generation;busy=true;
        io.execute(()->{
            Result result;
            try{result=run(at,route,fields,route==Route.LOGIN?null:prior);}
            catch(TeamHttp.Fault failure){result=failure(502,failure.code);}
            catch(SSLException badTls){result=failure(502,"tls");}
            catch(JSONException invalid){result=failure(502,"protocol");}
            catch(Exception noReply){result=failure(502,"network");}
            synchronized(this){
                busy=false;if(closed||generation!=when)return;
                if(route==Route.LOGIN&&result.issued!=null){cookie=result.issued;origin=at;}
                else if(route!=Route.LOGIN&&result.status==401){cookie=null;origin=null;}
            }
            callback.reply(ticket,result.status,result.value.toString());
        });
    }
    synchronized void clear(){generation++;cookie=null;origin=null;}
    synchronized void close(){clear();closed=true;io.shutdownNow();}
}
