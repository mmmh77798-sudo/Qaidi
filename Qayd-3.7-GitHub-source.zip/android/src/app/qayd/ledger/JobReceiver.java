package app.qayd.ledger;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public final class JobReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context ctx,Intent i){
        final String a=i.getAction();final Context c=ctx.getApplicationContext();
        if(DeviceJobs.BACKUP.equals(a)){
            final PendingResult pending=goAsync();
            Thread t=new Thread(()->{try{DeviceJobs.schedule(c);DeviceJobs.saveDaily(c);}finally{pending.finish();}},"qayd-daily-backup");t.start();
        }else{
            if(DeviceJobs.REMIND.equals(a))DeviceJobs.remind(c);
            DeviceJobs.schedule(c);
        }
    }
}
