package app.qayd.ledger;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import org.json.JSONObject;

/** Password stays on the Java side. Origin is authenticated as part of ciphertext. */
final class StaffLogin {
    interface Keeper {
        boolean available();
        boolean has();
        StaffLogin read();
        boolean write(StaffLogin login);
        boolean forget();
    }
    final String login, password, user;
    StaffLogin(String login,String password,String user){
        if(login==null||!login.matches("[a-z0-9][a-z0-9._-]{2,31}")||password==null||password.length()>128||password.trim().length()<12||!TeamHttp.memberId(user))throw new IllegalArgumentException("staff login");
        this.login=login;this.password=password;this.user=user;
    }
    private static byte[] aad(String at){
        if(at==null||!at.equals(SharedOrigin.canonical(at)))throw new IllegalArgumentException("origin");
        return ("Qayd/staff-login/v1\n"+at).getBytes(StandardCharsets.UTF_8);
    }
    byte[] seal(SecretKey key,String at)throws Exception{
        Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key);c.updateAAD(aad(at));
        byte[] iv=c.getIV();if(iv==null||iv.length!=12)throw new IllegalStateException("GCM IV");
        byte[] raw=new JSONObject().put("login",login).put("password",password).put("user",user).toString().getBytes(StandardCharsets.UTF_8);
        try{
            byte[] ct=c.doFinal(raw),out=new byte[iv.length+ct.length];System.arraycopy(iv,0,out,0,iv.length);System.arraycopy(ct,0,out,iv.length,ct.length);return out;
        }finally{Arrays.fill(raw,(byte)0);}
    }
    static StaffLogin open(SecretKey key,String at,byte[] value)throws Exception{
        if(value==null||value.length<29||value.length>2048)throw new IllegalArgumentException("ciphertext");
        Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key,new GCMParameterSpec(128,value,0,12));c.updateAAD(aad(at));
        byte[] raw=c.doFinal(value,12,value.length-12);
        try{JSONObject j=new JSONObject(new String(raw,StandardCharsets.UTF_8));return new StaffLogin(j.getString("login"),j.getString("password"),j.getString("user"));}
        finally{Arrays.fill(raw,(byte)0);}
    }
}
