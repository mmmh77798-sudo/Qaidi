package app.qayd.ledger;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipDescription;
import android.content.ClipboardManager;
import android.content.pm.PackageManager;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Insets;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.LinkAddress;
import android.net.LinkProperties;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.provider.ContactsContract;
import android.provider.ContactsContract.CommonDataKinds.Phone;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.print.PrintAttributes;
import android.print.PrintManager;

import android.view.WindowInsets;
import android.view.View;
import android.view.WindowInsetsController;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.InputStream;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.StandardCharsets;
import java.net.Inet4Address;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String ASSETS = "file:///android_asset/app/";
    private static final String ENTRY = ASSETS + "index.html";
    private static final int PICK = 120, SAVE = 121, TREE = 122, CAPTURE = 123, BACKUP_PICK = 125, CONTACT_PICK = 126, CONTACT_CREATE = 127, CATEGORY_PICK = 128;
    private static final String DRIVE_PACKAGE = "com.google.android.apps.docs";
    private static final int IMPORT_CHUNK = 49152;
    private static final int MAX_EXPORT = LedgerStorage.MAX_DOC;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final SharedTeam team=new SharedTeam();
    private WebView web;
    private FrameLayout root;
    private Boolean night;
    private LedgerStorage ledger;
    private LanPreview lan;
    private ThermalPrinter thermal;
    private Uri pendingCapture;
    private boolean resumed;
    private long teamUiEpoch; // Used only on the UI thread, as are team bridge dispatch and lifecycle.
    private ValueCallback<Uri[]> pendingPicker;
    private DocumentSave pendingSave;
    private boolean closing;
    private boolean choosingBackup;
    private String contactTicket;
    private int contactRequest;
    private final Object backupLock = new Object();
    private BackupOffer pendingBackup;
    private BackupInput.Content readyBackup;
    private final ExecutorService backupIo = Executors.newSingleThreadExecutor();

    private static final class DocumentSave {
        final byte[] bytes;
        final File db;
        final String ticket;
        DocumentSave(byte[] bytes,File db,String ticket){this.bytes=bytes;this.db=db;this.ticket=ticket;}
        void release(){if(db!=null)BackupDbFile.delete(db);}
        void transfer(OutputStream out)throws java.io.IOException {if(db!=null)BackupDbFile.copy(db,out);else out.write(bytes);}
    }
    private static final class BackupOffer {
        final String id = UUID.randomUUID().toString();
        final Uri uri;
        final boolean categoryOnly;
        boolean reading;
        BackupOffer(Uri uri,boolean categoryOnly){this.uri=uri;this.categoryOnly=categoryOnly;}
    }

    private boolean forwardLaunch(Intent intent){
        DeviceProfile profile=new DeviceProfile(this);
        if(DeviceRole.MANAGER.equals(profile.initial()))return false;
        String at=profile.origin();
        if(intent!=null&&Intent.ACTION_SEND.equals(intent.getAction()))android.widget.Toast.makeText(this,
            "اختر وضع المدير أولًا، ثم شارك ملف النسخة مرة أخرى.",android.widget.Toast.LENGTH_LONG).show();
        startActivity(at==null?new Intent(this,ProfileActivity.class):SharedDeskActivity.employeeIntent(this,at));
        finish();return true;
    }
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        if(forwardLaunch(getIntent()))return; // Do not initialize or expose the offline ledger on staff devices.
        ledger = new LedgerStorage(this);
        DeviceJobs.schedule(this);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(245, 247, 251));
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                Insets ime = insets.getInsets(WindowInsets.Type.ime());
                v.setPadding(bars.left, bars.top, bars.right, Math.max(ime.bottom, bars.bottom));
                return WindowInsets.CONSUMED;
            });
        }
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(245, 247, 251));
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false); // android_asset remains available
        settings.setAllowContentAccess(true); // only for users' document-picker selections
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setBlockNetworkLoads(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setTextZoom(100);
        android.webkit.CookieManager.getInstance().setAcceptCookie(false);
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView v,String url){if(ENTRY.equals(url))notifyBackup(false);}
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest request) {
                final String url = request.getUrl().toString();
                return !request.isForMainFrame() || !(ENTRY.equals(url) || url.startsWith(ENTRY + "#"));
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String url = uri.toString();
                if (url.startsWith(ASSETS) && !url.contains("..") && !url.contains("%")) return null;
                // Chromium reads imported <input type=file> documents through granted URIs, not navigation.
                return new WebResourceResponse("text/plain", "utf-8", 403, "Blocked", Collections.emptyMap(), new ByteArrayInputStream(new byte[0]));
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (pendingPicker != null) pendingPicker.onReceiveValue(null);
                pendingPicker = cb;
                boolean image=false;
                for(String mime:params.getAcceptTypes())if(mime!=null&&mime.startsWith("image/"))image=true;
                if(image&&params.isCaptureEnabled()&&capture())return true;
                Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType(image?"image/*":"*/*");
                try { startActivityForResult(pick, PICK); }
                catch (ActivityNotFoundException e) { pendingPicker = null; cb.onReceiveValue(null); result("لا يوجد مدير ملفات متاح.", true); }
                return true;
            }
        });
        thermal=new ThermalPrinter(this,this::result);
        web.addJavascriptInterface(new Bridge(), "QaydAndroid");
        web.loadUrl(ENTRY);
        if(saved==null)receiveBackup(getIntent());
    }

    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);if(!isFinishing()&&!forwardLaunch(intent))receiveBackup(intent);}
    @SuppressWarnings("deprecation")
    private void receiveBackup(Intent intent){
        if(intent==null||!Intent.ACTION_SEND.equals(intent.getAction()))return;
        Uri uri=null;
        try {
            if(Build.VERSION.SDK_INT>=33)uri=intent.getParcelableExtra(Intent.EXTRA_STREAM,Uri.class);
            else uri=intent.getParcelableExtra(Intent.EXTRA_STREAM);
            ClipData cl=intent.getClipData();
            if(cl!=null&&cl.getItemCount()!=1)return;
            if(uri==null&&cl!=null)uri=cl.getItemAt(0).getUri();
        }catch(RuntimeException ignored){return;}
        // Do not dereference arbitrary paths/URLs supplied by another app.
        if(uri!=null&&"content".equals(uri.getScheme())&&!getPackageName().concat(".share").equals(uri.getAuthority())&&
                checkUriPermission(uri,android.os.Process.myPid(),android.os.Process.myUid(),Intent.FLAG_GRANT_READ_URI_PERMISSION)==PackageManager.PERMISSION_GRANTED)offerBackup(uri,false,false);
        else result("لم يصل ملف قابل للقراءة. شارك ملف النسخة من Drive أو افتحه من خيارات الحفظ.",true);
    }
    private void offerBackup(Uri uri,boolean autoReview,boolean categoryOnly){
        synchronized(backupLock){pendingBackup=new BackupOffer(uri,categoryOnly);readyBackup=null;}
        notifyBackup(autoReview);
    }
    private void notifyBackup(boolean autoReview){
        final String id;
        synchronized(backupLock){if(pendingBackup==null)return;id=pendingBackup.id;}
        script("window.qaydBackupOffered && window.qaydBackupOffered("+JSONObject.quote(id)+","+autoReview+")");
    }
    private void openBackupPicker(boolean drive,boolean categoryOnly){
        if(closing||choosingBackup)return;
        choosingBackup=true;
        final int request=categoryOnly?CATEGORY_PICK:BACKUP_PICK;
        if(drive){
            Intent direct=new Intent(Intent.ACTION_GET_CONTENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE).setPackage(DRIVE_PACKAGE);
            try{startActivityForResult(direct,request);return;}catch(ActivityNotFoundException|SecurityException ignored){}
        }
        Intent picker=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
        try{startActivityForResult(picker,request);}catch(ActivityNotFoundException|SecurityException e){choosingBackup=false;result("لا يوجد منتقي ملفات متاح. يمكنك مشاركة ملف النسخة إلى قيد من مدير الملفات.",true);}
    }
    private void loadBackup(String id){
        final BackupOffer item;
        synchronized(backupLock){
            if(pendingBackup==null||!pendingBackup.id.equals(id)||pendingBackup.reading)return;
            item=pendingBackup;item.reading=true;
        }
        backupIo.execute(()->{
            try{
                String label="";long statedSize=-1;
                try(Cursor rows=getContentResolver().query(item.uri,new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE},null,null,null)){
                    if(rows!=null&&rows.moveToFirst()){
                        int n=rows.getColumnIndex(OpenableColumns.DISPLAY_NAME),z=rows.getColumnIndex(OpenableColumns.SIZE);
                        if(n>=0)label=BackupInput.label(rows.getString(n));if(z>=0&&!rows.isNull(z))statedSize=rows.getLong(z);
                    }
                }catch(Exception ignored){}
                if(statedSize>BackupDbFile.MAX_FILE)throw new BackupInput.LimitExceeded();
                final BackupInput.Content content;
                try(InputStream file=getContentResolver().openInputStream(item.uri)){
                    if(file==null)throw new IllegalStateException();content=BackupInput.document(file,MAX_EXPORT,BackupDbFile.MAX_FILE);
                }
                synchronized(backupLock){if(pendingBackup!=item)return;readyBackup=content;item.reading=false;}
                final String name=label;
                runOnUiThread(()->script("window.qaydBackupReady && window.qaydBackupReady("+JSONObject.quote(id)+","+JSONObject.quote(name)+","+content.length()+","+JSONObject.quote(content.db==null?"json":"db")+","+item.categoryOnly+")"));
            }catch(Exception error){
                synchronized(backupLock){if(pendingBackup!=item)return;item.reading=false;}
                String msg=error instanceof BackupInput.LimitExceeded?"حجم النسخة يتجاوز الحد: 48 ميغابايت لملف DB و20 ميغابايت لملف JSON.":error instanceof CharacterCodingException?"لم نجد ملف DB مقروءًا ولا نسخة JSON سليمة بترميز UTF-8.":"تعذّرت قراءة الملف. تأكد من اكتمال تنزيله ومن صلاحية الوصول إليه في Drive أو مدير الملفات.";
                runOnUiThread(()->script("window.qaydBackupFailed && window.qaydBackupFailed("+JSONObject.quote(id)+","+JSONObject.quote(msg)+")"));
            }
        });
    }
    private void result(String message, boolean error) {
        runOnUiThread(() -> {
            if (web != null && !closing) web.evaluateJavascript("window.qaydNativeResult && window.qaydNativeResult(" + JSONObject.quote(message) + "," + error + ")", null);
        });
    }

    private boolean validExport(String name, String mime, String value) {
        return name != null && value != null && name.matches("qayd-[A-Za-z0-9_-]{1,105}\\.(csv|json)") &&
            (("text/csv".equals(mime) && name.endsWith(".csv")) || ("application/json".equals(mime) && name.endsWith(".json"))) && value.length() <= MAX_EXPORT;
    }

    private boolean capture() {
        try {
            File root=new File(getCacheDir(),"captures");
            File[] prior=root.listFiles();if(prior!=null)for(File d:prior)if(d.isDirectory()&&d.lastModified()<System.currentTimeMillis()-86400000L){new File(d,"receipt.jpg").delete();d.delete();}
            String token=UUID.randomUUID().toString();File dir=new File(root,token);
            if(!dir.mkdirs())return false;
            pendingCapture=new Uri.Builder().scheme("content").authority(getPackageName()+".share").appendPath("capture").appendPath(token).appendPath("receipt.jpg").build();
            Intent i=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);i.putExtra(MediaStore.EXTRA_OUTPUT,pendingCapture);
            i.setClipData(ClipData.newRawUri("receipt",pendingCapture));
            i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(i,CAPTURE);return true;
        }catch(RuntimeException e){pendingCapture=null;return false;}
    }
    private void script(String js){if(web!=null&&!closing)web.evaluateJavascript(js,null);}
    private void clearTeamSession(){teamUiEpoch++;team.clear();}
    private void teamReply(long epoch,String ticket,int status,String json){
        if(!SharedTeam.ticket(ticket)||json==null||json.length()>TeamHttp.REPLY_LIMIT)return;
        String safe=android.util.Base64.encodeToString(json.getBytes(StandardCharsets.UTF_8),android.util.Base64.NO_WRAP);
        runOnUiThread(()->{if(!closing&&epoch==teamUiEpoch)script("window.qaydTeamReply && window.qaydTeamReply("+JSONObject.quote(ticket)+","+status+","+JSONObject.quote(safe)+")");});
    }
    private Inet4Address wifiIp() {
        ConnectivityManager cm=getSystemService(ConnectivityManager.class);if(cm==null)return null;
        for(Network n:cm.getAllNetworks()) {
            NetworkCapabilities cap=cm.getNetworkCapabilities(n);
            if(cap==null||!cap.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)||cap.hasTransport(NetworkCapabilities.TRANSPORT_VPN))continue;
            LinkProperties props=cm.getLinkProperties(n);if(props==null)continue;
            for(LinkAddress address:props.getLinkAddresses())
                if(address.getAddress() instanceof Inet4Address&&(address.getAddress().isSiteLocalAddress()||address.getAddress().isLinkLocalAddress()))return (Inet4Address) address.getAddress();
        }
        return null;
    }
    private void stopLocal(boolean inform){
        if(lan!=null){lan.close();lan=null;if(inform)script("window.qaydLanStopped && window.qaydLanStopped()");}
    }
    private void contactResult(String ticket,String state,String phone){
        script("window.qaydPhoneContactResult && window.qaydPhoneContactResult("+JSONObject.quote(ticket)+","+JSONObject.quote(state)+","+JSONObject.quote(phone)+")");
    }
    private void chooseContact(String ticket,String name,int request){
        if(ticket==null||!ticket.matches("contact[1-9][0-9]{0,9}"))return;
        if(closing||!resumed){contactResult(ticket,"unavailable","");return;}
        if(contactTicket!=null){contactResult(ticket,"busy","");return;}
        final Intent i;
        if(request==CONTACT_CREATE){
            if(name==null||name.trim().isEmpty()||name.length()>90){contactResult(ticket,"invalid","");return;}
            i=new Intent(Intent.ACTION_INSERT).setType(ContactsContract.Contacts.CONTENT_TYPE)
                .putExtra(ContactsContract.Intents.Insert.NAME,name)
                .putExtra("finishActivityOnSaveCompleted",true);
        }else i=new Intent(Intent.ACTION_PICK).setType(Phone.CONTENT_TYPE);
        contactTicket=ticket;contactRequest=request;
        try{startActivityForResult(i,request);}catch(ActivityNotFoundException|SecurityException e){finishContact(ticket,"unavailable","");}
    }
    private void finishContact(String ticket,String state,String phone){
        if(!ticket.equals(contactTicket))return;
        contactTicket=null;contactRequest=0;contactResult(ticket,state,phone);
    }
    private void receiveContact(int request,int code,Uri uri){
        final String ticket=contactTicket;
        if(ticket==null||contactRequest!=request)return;
        if(request==CONTACT_CREATE){finishContact(ticket,"returned","");return;}
        if(code!=RESULT_OK){finishContact(ticket,"cancelled","");return;}
        // Accept the selected data/# (or data/phones/#) row, not a contacts list.
        if(uri==null||!ContactsContract.AUTHORITY.equals(uri.getAuthority())){finishContact(ticket,"invalid","");return;}
        final List<String> path=uri.getPathSegments();
        final boolean row=path.size()==2||(path.size()==3&&"phones".equals(path.get(1)));
        if(!row||!"data".equals(path.get(0))||!path.get(path.size()-1).matches("[1-9][0-9]{0,18}")){
            finishContact(ticket,"invalid","");return;
        }
        io.execute(()->{
            String phone="";
            try(Cursor c=getContentResolver().query(uri,new String[]{Phone.NUMBER,Phone.NORMALIZED_NUMBER,ContactsContract.Data.MIMETYPE},null,null,null)){
                if(c!=null&&c.moveToFirst()&&Phone.CONTENT_ITEM_TYPE.equals(c.getString(2))){
                    final String raw=c.getString(0),full=c.getString(1);
                    if(c.isLast()){
                        if(full!=null&&full.matches("\\+[1-9][0-9]{7,14}"))phone=full;
                        else if(raw!=null&&raw.length()<=48)phone=raw;
                    }
                }
            }catch(RuntimeException ignored){}
            final String selected=phone;
            runOnUiThread(()->finishContact(ticket,selected.isEmpty()?"invalid":"picked",selected));
        });
    }
    private void openMessage(String medium,String number,String text,boolean business){
        if(text==null||text.isEmpty()||text.length()>6000||number==null||!number.matches("\\+[1-9][0-9]{7,14}")){result("تحقق من رقم الهاتف وطول الرسالة.",true);return;}
        Intent intent;
        if("sms".equals(medium))intent=new Intent(Intent.ACTION_SENDTO,Uri.parse("smsto:"+number)).putExtra("sms_body",text);
        else if("wa".equals(medium)){
            Uri uri=new Uri.Builder().scheme("https").authority("wa.me").appendPath(number.substring(1)).appendQueryParameter("text",text).build();
            intent=new Intent(Intent.ACTION_VIEW,uri).setPackage(business?"com.whatsapp.w4b":"com.whatsapp");
        }else return;
        try{startActivity(intent);}catch(ActivityNotFoundException|SecurityException e){
            if("wa".equals(medium))try{
                Uri fallback=new Uri.Builder().scheme("whatsapp").authority("send").appendQueryParameter("phone",number.substring(1)).appendQueryParameter("text",text).build();
                startActivity(new Intent(Intent.ACTION_VIEW,fallback).setPackage(business?"com.whatsapp.w4b":"com.whatsapp"));return;
            }catch(ActivityNotFoundException|SecurityException ignored){}
            result("sms".equals(medium)?"لم يُفتح تطبيق الرسائل النصية. تحقّق من التطبيق الافتراضي للرسائل أو انسخ النص.":business?"لم يُفتح واتساب للأعمال. تحقّق من تثبيته أو عطّل خياره من إعدادات قيد.":"لم يُفتح واتساب. تحقّق من تثبيته أو انسخ النص.",true);
        }
    }
    private void saveResult(String ticket,String status,String message){
        if(ticket==null){if(!"cancelled".equals(status))result(message,"error".equals(status));return;}
        runOnUiThread(()->script("window.qaydRestoreCopyResult && window.qaydRestoreCopyResult("+JSONObject.quote(ticket)+","+JSONObject.quote(status)+","+JSONObject.quote(message)+")"));
    }
    private void queueSave(String name,String mime,DocumentSave job){
        runOnUiThread(()->{
            if(closing){job.release();return;}
            if(pendingSave!=null){job.release();saveResult(job.ticket,"error","أغلق منتقي الملفات أولًا.");return;}
            Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(mime).putExtra(Intent.EXTRA_TITLE,name);
            pendingSave=job;
            try{startActivityForResult(i,SAVE);}
            catch(ActivityNotFoundException|SecurityException e){pendingSave=null;job.release();saveResult(job.ticket,"error","لم يُفتح منتقي الحفظ. اختر مكانًا آخر أو حاول مجددًا.");}
        });
    }
    private void saveDocument(String name,String mime,String value){
        if(!validExport(name,mime,value)){result("اسم الملف أو حجمه غير صالح.",true);return;}
        final byte[] bytes=value.getBytes(StandardCharsets.UTF_8);
        if(bytes.length>MAX_EXPORT){result("حجم الملف أكبر من الحد المسموح.",true);return;}
        queueSave(name,mime,new DocumentSave(bytes,null,null));
    }
    private void stageShare(String name,String mime,byte[] bytes,boolean sqlite,boolean drive){
        io.execute(()->{
            File dir=null,temp=null;
            try{
                String token=UUID.randomUUID().toString();
                File root=new File(getCacheDir(),"shares");
                File[] prior=root.listFiles();
                if(prior!=null)for(File stale:prior){
                    if(stale.isDirectory()&&stale.lastModified()<System.currentTimeMillis()-86400000L){
                        File[] children=stale.listFiles();if(children!=null)for(File child:children)child.delete();stale.delete();
                    }
                }
                dir=new File(root,token);if(!dir.mkdirs())throw new IllegalStateException();
                temp=new File(dir,name);
                if(sqlite)BackupDbFile.write(temp,bytes);
                else try(FileOutputStream out=new FileOutputStream(temp)){out.write(bytes);}
                final File ready=temp,folder=dir;
                Uri uri=new Uri.Builder().scheme("content").authority(getPackageName()+".share").appendPath(token).appendPath(name).build();
                Intent send=new Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM,uri).putExtra(Intent.EXTRA_TITLE,name);
                send.setClipData(ClipData.newRawUri(name,uri));send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                runOnUiThread(()->{
                    if(closing){ready.delete();folder.delete();return;}
                    if(!drive){choose(send);return;}
                    try{startActivity(send.setPackage(DRIVE_PACKAGE));}
                    catch(ActivityNotFoundException|SecurityException unavailable){ready.delete();folder.delete();result("لم يُفتح Google Drive. احفظ النسخة على الجهاز وارفعها إليه يدويًا، أو تحقّق من تثبيت Drive.",true);}
                });
            }catch(Exception e){if(temp!=null)temp.delete();if(dir!=null)dir.delete();result("تعذّر تجهيز الملف للمشاركة.",true);}
        });
    }
    private void prepareShare(String name,String mime,String value){
        if(!validExport(name,mime,value)){result("اسم الملف أو حجمه غير صالح.",true);return;}
        final byte[] bytes=value.getBytes(StandardCharsets.UTF_8);
        if(bytes.length>MAX_EXPORT){result("حجم الملف أكبر من الحد المسموح.",true);return;}
        stageShare(name,mime,bytes,false,false);
    }
    private void prepareBinaryExport(String name,String encoded,String mode,boolean workbook){
        final String mime=workbook?WorkbookExport.MIME:PdfExport.MIME;
        final boolean valid=workbook?WorkbookExport.request(name,encoded,mode):PdfExport.request(name,encoded,mode);
        if(!valid){result("اسم الملف أو حجمه غير صالح.",true);return;}
        io.execute(()->{
            final byte[] bytes;
            try{bytes=android.util.Base64.decode(encoded,android.util.Base64.DEFAULT);}
            catch(IllegalArgumentException e){result("تعذّر قراءة بيانات الملف.",true);return;}
            if(!(workbook?WorkbookExport.zipEnvelope(bytes):PdfExport.pdfHeaderAndTrailer(bytes))){result("تعذّر التحقق من صيغة الملف.",true);return;}
            if("share".equals(mode))stageShare(name,mime,bytes,false,false);
            else queueSave(name,mime,new DocumentSave(bytes,null,null));
        });
    }
    private void prepareBackupDb(String name,String value,String mode,String ticket){
        if(name==null||!name.matches("qayd-[A-Za-z0-9_-]{1,105}\\.db")||value==null||value.isEmpty()||value.length()>MAX_EXPORT){saveResult(ticket,"error","اسم الملف أو حجم النسخة غير صالح.");return;}
        byte[] bytes=value.getBytes(StandardCharsets.UTF_8);
        if(bytes.length>MAX_EXPORT){saveResult(ticket,"error","حجم النسخة أكبر من الحد المسموح.");return;}
        if("drive".equals(mode)||"share".equals(mode)){stageShare(name,BackupDbFile.MIME,bytes,true,"drive".equals(mode));return;}
        if(!"local".equals(mode)){saveResult(ticket,"error","طريقة حفظ غير صالحة.");return;}
        io.execute(()->{
            File prepared=null;
            try{
                prepared=File.createTempFile("qayd-transport-",".db",getCacheDir());
                BackupDbFile.write(prepared,bytes);
                queueSave(name,BackupDbFile.MIME,new DocumentSave(null,prepared,ticket));
            }catch(Exception e){BackupDbFile.delete(prepared);saveResult(ticket,"error","تعذّر إنشاء نسخة DB. تحقق من المساحة المتوفرة.");}
        });
    }
    final class Bridge {
        @JavascriptInterface public String readLedger(){try{byte[] b=ledger.bytes(false);return b==null?null:new String(b,StandardCharsets.UTF_8);}catch(Exception e){return "!";}}
        @JavascriptInterface public boolean writeLedger(String json,String withoutPhotos){return ledger.put(json,withoutPhotos);}
        @JavascriptInterface public void setNight(boolean now){runOnUiThread(()->{
            if(closing||web==null||(night!=null&&night==now))return;night=now;
            int bg=now?Color.rgb(17,24,39):Color.rgb(245,247,251);root.setBackgroundColor(bg);web.setBackgroundColor(bg);
            if(Build.VERSION.SDK_INT<35){getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(Build.VERSION.SDK_INT>=26?bg:Color.BLACK);}
            if(Build.VERSION.SDK_INT>=30){WindowInsetsController ctrl=getWindow().getInsetsController();if(ctrl!=null){int mask=WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS|WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;ctrl.setSystemBarsAppearance(now?0:mask,mask);}}
            else {int flags=now?0:View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;if(!now&&Build.VERSION.SDK_INT>=26)flags|=View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;getWindow().getDecorView().setSystemUiVisibility(flags);}
        });}
        @JavascriptInterface public String backupStatus(){return DeviceJobs.status(MainActivity.this);}
        @JavascriptInterface public String backupSchedule(boolean enabled,String time){return DeviceJobs.configureBackup(MainActivity.this,enabled,time);}
        @JavascriptInterface public void selectBackupFolder(){runOnUiThread(()->{
            Intent tree=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            try{startActivityForResult(tree,TREE);}catch(ActivityNotFoundException e){result("لا يوجد منتقي مجلدات متاح.",true);}
        });}
        @JavascriptInterface public void setReminderDates(String dates){DeviceJobs.reminderDates(MainActivity.this,dates);}
        @JavascriptInterface public void amountAdded(){runOnUiThread(()->DeviceJobs.notify(MainActivity.this,806,"حُفظت حركة جديدة في الدفتر."));}
        @JavascriptInterface public void requestNoticePermission(){runOnUiThread(()->{
            if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},124);
            else result("يمكنك إدارة الإذن من إعدادات إشعارات التطبيق.",false);
        });}
        @JavascriptInterface public void pickPhoneContact(String ticket){runOnUiThread(()->chooseContact(ticket,null,CONTACT_PICK));}
        @JavascriptInterface public void createPhoneContact(String ticket,String name){runOnUiThread(()->chooseContact(ticket,name,CONTACT_CREATE));}
        @JavascriptInterface public void compose(String medium,String number,String text,boolean business){runOnUiThread(()->openMessage(medium,number,text,business));}
        @JavascriptInterface public void copyText(String text){if(text==null||text.length()>6000)return;runOnUiThread(()->{
            ClipboardManager c=getSystemService(ClipboardManager.class);if(c!=null)c.setPrimaryClip(ClipData.newPlainText("قيد",text));
        });}
        @JavascriptInterface public void startLan(String snapshot){runOnUiThread(()->{
            if(!resumed||closing)return;
            stopLocal(false);
            try{
                Inet4Address ip=wifiIp();if(ip==null)throw new IllegalStateException();
                if(snapshot==null||snapshot.length()>4*1024*1024)throw new IllegalArgumentException();
                lan=new LanPreview(ip,snapshot);final LanPreview own=lan;
                script("window.qaydLanReady && window.qaydLanReady("+JSONObject.quote(lan.url())+")");
                web.postDelayed(()->{if(lan==own)stopLocal(true);},10*60*1000L);
            }catch(Exception e){script("window.qaydLanFailed && window.qaydLanFailed()");}
        });}
        @JavascriptInterface public void stopLan(){runOnUiThread(()->stopLocal(false));}
        @JavascriptInterface public void saveFile(String name,String mime,String value){saveDocument(name,mime,value);}
        @JavascriptInterface public void shareFile(String name,String mime,String value){prepareShare(name,mime,value);}
        @JavascriptInterface public void exportPdf(String name,String encoded,String mode){prepareBinaryExport(name,encoded,mode,false);}
        @JavascriptInterface public void exportWorkbook(String name,String encoded,String mode){prepareBinaryExport(name,encoded,mode,true);}
        @JavascriptInterface public void printThermal(int width,int height,String bits){if(thermal!=null)thermal.offer(width,height,bits);}
        @JavascriptInterface public void backupDb(String name,String value,String mode,String ticket){
            if(ticket==null||(!ticket.isEmpty()&&!ticket.matches("restore-save-[0-9]{1,15}")))return;
            prepareBackupDb(name,value,mode,ticket.isEmpty()?null:ticket);
        }
        @JavascriptInterface public void pickBackup(boolean drive){runOnUiThread(()->openBackupPicker(drive,false));}
        @JavascriptInterface public void pickCategoryBackup(){runOnUiThread(()->openBackupPicker(false,true));}
        @JavascriptInterface public void dialSupport(){runOnUiThread(()->{
            if(closing)return;
            Intent dial=new Intent(Intent.ACTION_DIAL,Uri.fromParts("tel","777456253",null));
            try{startActivity(dial);}catch(ActivityNotFoundException|SecurityException e){result("لا يتوفر تطبيق اتصال. رقم التواصل: 777456253",true);}
        });}
        @JavascriptInterface public void teamRequest(String ticket,String origin,String operation,String json){runOnUiThread(()->{
            if(closing)return;
            final long epoch=teamUiEpoch;
            if(!resumed){teamReply(epoch,ticket,409,SharedTeam.inactive());return;}
            team.request(ticket,origin,operation,json,(id,status,value)->teamReply(epoch,id,status,value));
        });}
        @JavascriptInterface public void teamClear(){runOnUiThread(MainActivity.this::clearTeamSession);}
        @JavascriptInterface public void configureDeviceMode(String supplied){
            final String at=SharedOrigin.canonical(supplied);
            runOnUiThread(()->{
                if(closing||!resumed||!DeviceRole.MANAGER.equals(new DeviceProfile(MainActivity.this).role()))return;
                clearTeamSession();
                startActivity(new Intent(MainActivity.this,ProfileActivity.class).putExtra(ProfileActivity.SEED,at));
            });
        }
        private void openDesk(String supplied,boolean quickPost){
            final String at=SharedOrigin.canonical(supplied);
            runOnUiThread(()->{
                if(closing||!resumed||at==null||!DeviceRole.MANAGER.equals(new DeviceProfile(MainActivity.this).role()))return;
                clearTeamSession();
                // This intent carries only the HTTPS origin and a one-shot navigation flag.
                // It never sends details of a local account, form, or ledger.
                startActivity(new Intent(MainActivity.this,SharedDeskActivity.class)
                    .putExtra(SharedDeskActivity.ORIGIN,at).putExtra(SharedDeskActivity.QUICK_POST,quickPost));
            });
        }
        @JavascriptInterface public void openSharedDesk(String supplied){openDesk(supplied,false);}
        @JavascriptInterface public void openSharedPosting(String supplied){openDesk(supplied,true);}
        @JavascriptInterface public void teamCopyTemporary(String value){
            if(value==null||!value.matches("[A-Za-z0-9_-]{24}"))return;
            runOnUiThread(()->{
                if(closing||!resumed)return;ClipboardManager c=getSystemService(ClipboardManager.class);if(c==null)return;
                ClipData clip=ClipData.newPlainText("كلمة سر مؤقتة من قيد",value);
                PersistableBundle flags=new PersistableBundle();flags.putBoolean("android.content.extra.IS_SENSITIVE",true);
                ClipDescription description=clip.getDescription();description.setExtras(flags);c.setPrimaryClip(clip);
            });
        }
        @JavascriptInterface public String pendingBackupId(){synchronized(backupLock){return pendingBackup==null?null:pendingBackup.id;}}
        @JavascriptInterface public void readPendingBackup(String id){loadBackup(id);}
        @JavascriptInterface public String backupPart(String id,int start){
            synchronized(backupLock){
                if(pendingBackup==null||!pendingBackup.id.equals(id)||readyBackup==null||start<0||start>=readyBackup.length())return null;
                int end=Math.min(start+IMPORT_CHUNK,readyBackup.length());
                if(readyBackup.db!=null)return android.util.Base64.encodeToString(readyBackup.db,start,end-start,android.util.Base64.NO_WRAP);
                String text=readyBackup.json;
                // Do not split a surrogate pair between JavaScript bridge calls.
                if(end<text.length()&&Character.isHighSurrogate(text.charAt(end-1)))end--;
                return text.substring(start,end);
            }
        }
        @JavascriptInterface public void discardBackup(String id){
            synchronized(backupLock){if(pendingBackup!=null&&pendingBackup.id.equals(id)){pendingBackup=null;readyBackup=null;}}
        }
        @JavascriptInterface public void shareText(String value) {
            if (value == null || value.length() > 60000) { result("النص طويل جدًا. شارك الملف بدلًا منه.", true); return; }
            runOnUiThread(() -> choose(new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, value)));
        }
        @JavascriptInterface public void printPage(String label){systemPrint(label,0);}
        @JavascriptInterface public void printReceipt(String label,int mm){if(mm==58||mm==80)systemPrint(label,mm);}
    }
    private void systemPrint(String label,int widthMm){
        if(label==null||label.length()>190)return;
        runOnUiThread(()->{
            if(closing||web==null)return;
            try{
                PrintManager manager=(PrintManager)getSystemService(PRINT_SERVICE);
                if(manager==null)throw new IllegalStateException();
                PrintAttributes.MediaSize paper=PrintAttributes.MediaSize.ISO_A4;
                if(widthMm!=0)paper=new PrintAttributes.MediaSize("QAYD_ROLL_"+widthMm,widthMm+" mm",(int)Math.round(widthMm*1000/25.4),(int)Math.round(225*1000/25.4));
                PrintAttributes.Builder attrs=new PrintAttributes.Builder().setMediaSize(paper);
                if(widthMm!=0)attrs.setColorMode(PrintAttributes.COLOR_MODE_MONOCHROME);
                manager.print(label,web.createPrintDocumentAdapter(label),attrs.build());
            }catch(Exception e){result("تعذّر فتح الطباعة على الجهاز.",true);}
        });
    }
    private void choose(Intent send) {
        try { if (!closing) startActivity(Intent.createChooser(send, "مشاركة من قيد")); }
        catch (ActivityNotFoundException e) { result("لا يوجد تطبيق متاح للمشاركة.", true); }
    }
    @Override protected void onActivityResult(int request, int code, Intent intent) {
        super.onActivityResult(request, code, intent);
        Uri uri = (code == RESULT_OK && intent != null) ? intent.getData() : null;
        if((request==BACKUP_PICK||request==CATEGORY_PICK)&&uri==null&&code==RESULT_OK&&intent!=null){
            ClipData clips=intent.getClipData();
            if(clips!=null&&clips.getItemCount()==1)uri=clips.getItemAt(0).getUri();
        }
        if (uri != null && !"content".equals(uri.getScheme())) uri = null;
        if(request==CONTACT_PICK||request==CONTACT_CREATE){receiveContact(request,code,uri);return;}
        if(request==BACKUP_PICK||request==CATEGORY_PICK){
            choosingBackup=false;
            if(uri!=null)offerBackup(uri,true,request==CATEGORY_PICK);
            else if(code==RESULT_OK)result("لم يصل ملف صالح للقراءة. نزّل النسخة أولًا أو اختر ملفًا آخر.",true);
        }else if(request==TREE){
            if(uri!=null)try {DeviceJobs.useFolder(this,uri); script("window.qaydNativeRefresh && window.qaydNativeRefresh()"); result("اختير مجلد النسخ.",false);}
            catch(Exception e){result("تعذّر حفظ إذن المجلد. اختر مجلدًا يمكن الكتابة فيه.",true);}
        } else if(request==CAPTURE){
            Uri image=pendingCapture;pendingCapture=null;
            ValueCallback<Uri[]> cb=pendingPicker;pendingPicker=null;
            if(cb!=null)cb.onReceiveValue(code==RESULT_OK&&image!=null?new Uri[]{image}:null);
            if(image!=null)revokeUriPermission(image,Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } else if (request == PICK) {
            ValueCallback<Uri[]> cb = pendingPicker; pendingPicker = null;
            if(cb != null) cb.onReceiveValue(uri == null ? null : new Uri[]{uri});
        } else if (request == SAVE) {
            final DocumentSave job=pendingSave;pendingSave=null;
            final String ticket=job==null?null:job.ticket;
            if(code!=RESULT_OK){if(job!=null)job.release();saveResult(ticket,"cancelled","أُلغي الحفظ. لم يُحفظ ملف النسخة.");return;}
            if(uri==null){if(job!=null)job.release();saveResult(ticket,"error","لم يُحدّد مكان صالح لحفظ النسخة.");return;}
            if(job==null){result("أُعيد تشغيل التطبيق. اطلب الحفظ مرة أخرى.",true);return;}
            final Uri dest=uri;
            io.execute(()->{
                try(OutputStream out=getContentResolver().openOutputStream(dest,"wt")){
                    if(out==null)throw new IllegalStateException();
                    job.transfer(out);
                }catch(Exception e){saveResult(ticket,"error","لم يُحفظ الملف. اختر مكانًا آخر وحاول مجددًا.");return;}
                finally{job.release();}
                saveResult(ticket,"saved",ticket==null?"حُفظ الملف في المكان المحدد.":"حُفظت النسخة الحالية. لم يبدأ الاسترجاع بعد.");
            });
        }
    }
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] grants){
        super.onRequestPermissionsResult(request,permissions,grants);
        if(request==ThermalPrinter.PERMISSION_RESULT&&thermal!=null)thermal.permissionResult(grants.length>0&&grants[0]==PackageManager.PERMISSION_GRANTED);
    }
    @Override protected void onResume(){super.onResume();resumed=true;}
    @Override protected void onPause(){resumed=false;stopLocal(true);super.onPause();}
    @Override protected void onStop(){clearTeamSession();script("window.qaydTeamSuspended && window.qaydTeamSuspended()");super.onStop();}
    @Override public void onBackPressed() {
        if(web == null) { super.onBackPressed(); return; }
        web.evaluateJavascript("window.qaydBack ? window.qaydBack() : false", result -> { if (!"true".equals(result) && !closing) finish(); });
    }
    @Override protected void onDestroy() {
        closing = true;
        team.close();
        contactTicket=null;contactRequest=0;
        if(thermal!=null){thermal.close();thermal=null;}
        stopLocal(false);
        if(pendingPicker != null) { pendingPicker.onReceiveValue(null); pendingPicker = null; }
        if(pendingSave!=null)pendingSave.release();pendingSave=null;
        io.shutdown();
        synchronized(backupLock){pendingBackup=null;readyBackup=null;}
        backupIo.shutdownNow();
        if(web != null) { web.removeJavascriptInterface("QaydAndroid"); web.destroy(); web = null; }
        super.onDestroy();
    }
}
