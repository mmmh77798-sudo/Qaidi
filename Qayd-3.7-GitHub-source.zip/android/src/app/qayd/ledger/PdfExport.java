package app.qayd.ledger;

import java.util.regex.Pattern;

/** Guards the binary report export bridge; it is not a PDF interpreter. */
final class PdfExport {
    static final String MIME="application/pdf";
    static final int MAX_BYTES=20*1024*1024;
    private static final int MAX_BASE64=4*((MAX_BYTES+2)/3);
    private static final Pattern NAME=Pattern.compile("qayd-(?:statement|report)-[A-Za-z0-9_-]{1,85}\\.pdf");
    private PdfExport(){}
    static boolean request(String name,String value,String mode){
        return name!=null&&NAME.matcher(name).matches()&&("local".equals(mode)||"share".equals(mode))
                &&value!=null&&value.length()>=20&&value.length()<=MAX_BASE64&&(value.length()&3)==0;
    }
    static boolean pdfHeaderAndTrailer(byte[] value){
        if(value==null||value.length<14||value.length>MAX_BYTES)return false;
        if(value[0]!='%'||value[1]!='P'||value[2]!='D'||value[3]!='F'||value[4]!='-'||
                (value[5]!='1'&&value[5]!='2')||value[6]!='.'||value[7]<'0'||value[7]>'9'||(value[8]!='\n'&&value[8]!='\r'))return false;
        int end=value.length;
        while(end>9&&(value[end-1]=='\n'||value[end-1]=='\r'||value[end-1]==' '||value[end-1]=='\t'))end--;
        return end>=14&&value[end-5]=='%'&&value[end-4]=='%'&&value[end-3]=='E'&&value[end-2]=='O'&&value[end-1]=='F';
    }
}
