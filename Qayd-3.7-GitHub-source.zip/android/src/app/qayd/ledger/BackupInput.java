package app.qayd.ledger;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/** Bounded document intake. Format is determined by the bytes, not a filename or MIME type. */
final class BackupInput {
    private static final byte[] SQLITE="SQLite format 3\0".getBytes(StandardCharsets.US_ASCII);
    static final class Content {
        final String json;
        final byte[] db;
        Content(String text,byte[] binary){json=text;db=binary;}
        int length(){return db==null?json.length():db.length;}
    }
    static Content document(InputStream source,int maxJson,int maxDb)throws IOException {
        BufferedInputStream in=new BufferedInputStream(source);in.mark(SQLITE.length);
        byte[] header=new byte[SQLITE.length];int n,have=0;
        while(have<header.length&&(n=in.read(header,have,header.length-have))>0)have+=n;
        in.reset();
        if(have==header.length&&Arrays.equals(header,SQLITE))return new Content(null,bytes(in,maxDb));
        return new Content(read(in,maxJson),null);
    }
    private static byte[] bytes(InputStream in,int limit)throws IOException {
        byte[] chunk=new byte[16*1024];int total=0;
        ByteArrayOutputStream out=new ByteArrayOutputStream(Math.min(limit,32*1024));
        for(int n;(n=in.read(chunk))!=-1;){
            if(n>limit-total)throw new LimitExceeded();
            out.write(chunk,0,n);total+=n;
        }
        return out.toByteArray();
    }
    static String read(InputStream in,int limit) throws IOException {
        return StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes(in,limit))).toString();
    }
    static String label(String s){
        if(s==null)return "";
        String safe=s.replaceAll("[\\p{Cntrl}\\u061c\\u200e\\u200f\\u202a-\\u202e\\u2066-\\u2069]", "").trim();
        return safe.substring(0,Math.min(safe.length(),160));
    }
    static final class LimitExceeded extends IOException {}
}
