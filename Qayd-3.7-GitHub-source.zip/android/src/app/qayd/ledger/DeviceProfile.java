package app.qayd.ledger;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import java.io.File;

/** One explicit staff-to-origin binding, independent from the local ledger and its backups. */
final class DeviceProfile {
    private static final String PREFS="qayd.device.profile.v1", ROLE="role", ORIGIN="staffOrigin", SEALED="staffAuth";
    private static final Object LOCK=new Object();
    private final Context context;
    private final SharedPreferences p;
    DeviceProfile(Context c){context=c.getApplicationContext();p=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE);}
    String role(){return p.getString(ROLE,"");}
    String origin(){return DeviceRole.staffOrigin(role(),p.getString(ORIGIN,""));}
    boolean bound(String at){return DeviceRole.sameBinding(role(),p.getString(ORIGIN,""),at);}
    String initial(){
        String saved=role();
        if(DeviceRole.MANAGER.equals(saved)||DeviceRole.STAFF.equals(saved))return saved;
        boolean upgraded=false;
        try{PackageInfo n=context.getPackageManager().getPackageInfo(context.getPackageName(),0);upgraded=n.lastUpdateTime>n.firstInstallTime;}
        catch(Exception ignored){}
        File dir=context.getFilesDir();
        String next=DeviceRole.initial(saved,upgraded,new File(dir,"ledger-v1.json").isFile()||new File(dir,"ledger-v1.json.bak").isFile());
        if(DeviceRole.MANAGER.equals(next)&&!next.equals(saved))chooseManager();
        return next;
    }
    boolean chooseManager(){synchronized(LOCK){return p.edit().putString(ROLE,DeviceRole.MANAGER).remove(ORIGIN).remove(SEALED).commit();}}
    boolean chooseStaff(String origin){
        String at=SharedOrigin.canonical(origin);if(at==null)return false;
        synchronized(LOCK){
            SharedPreferences.Editor e=p.edit().putString(ROLE,DeviceRole.STAFF).putString(ORIGIN,at);
            if(!bound(at))e.remove(SEALED);
            return e.commit();
        }
    }
    String sealed(String at){synchronized(LOCK){return bound(at)?p.getString(SEALED,""):"";}}
    boolean keep(String at,String value){synchronized(LOCK){return bound(at)&&p.edit().putString(SEALED,value).commit();}}
    boolean forget(String at){synchronized(LOCK){return !bound(at)||p.edit().remove(SEALED).commit();}}
}
