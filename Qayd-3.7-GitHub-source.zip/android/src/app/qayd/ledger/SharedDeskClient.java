package app.qayd.ledger;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import javax.net.ssl.SSLException;
import org.json.JSONException;
import org.json.JSONObject;

/** Separate in-memory session for one shared desk screen. The server, not the
 * Android client, is authoritative for roles, category grants and versions. */
final class SharedDeskClient {
    interface Reply { void send(String ticket,int status,String data); }
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private final String origin;
    private final StaffLogin.Keeper keeper; // null for the regular/manager channel
    private String cookie;
    private boolean closed;
    private long generation;
    private Future<?> pending;
    SharedDeskClient(String origin){this(origin,null);}
    SharedDeskClient(String origin,StaffLogin.Keeper keeper){
        this.origin=SharedOrigin.canonical(origin);
        if(this.origin==null||!this.origin.equals(origin))throw new IllegalArgumentException("origin");
        this.keeper=keeper;
    }
    boolean canKeep(){return keeper!=null&&keeper.available();}
    boolean kept(){return keeper!=null&&keeper.has();}
    synchronized boolean forget(){return keeper==null||keeper.forget();}
    static boolean ticket(String id){return id!=null&&id.matches("desk-[0-9]{1,15}");}
    static String fault(String code){
        String message;
        switch(code){
            case "request":message="هذا الطلب غير متاح في تطبيق قيد.";break;
            case "tls":message="تعذّر التحقق من شهادة HTTPS. راجع عنوان خادم الدفتر.";break;
            case "redirect":message="الخادم أعاد توجيه الطلب. احفظ عنوان HTTPS النهائي.";break;
            case "oversize":message="هذه الاستجابة أكبر من حد الهاتف. قلّل نطاق العرض أو استخدم المتصفح.";break;
            case "protocol":message="لم يصل رد صالح من قيد. تأكّد من عنوان الخادم وجرّب التحديث.";break;
            case "demo":message="هذه معاينة تجريبية، وليست دفتر فريق. لا تدخل بيانات دخولك فيها.";break;
            case "version":message="تتطلب هذه الشاشة خادم قيد إصدار 3.1 أو أحدث من السلسلة 3.";break;
            case "owner-not-initialized":message="الخادم متصل لكن المالك لم يهيّئ الدفتر المشترك بعد.";break;
            case "busy":message="يجري اتصال آخر. انتظر قليلًا ثم اضغط تحديث.";break;
            case "login":message="انتهت الجلسة. سجّل الدخول من جديد.";break;
            case "credentials":message="اسم الدخول أو كلمة السر غير صحيحة.";break;
            case "staff-role":message="هذا الجهاز في وضع الموظف. استخدم حساب موظف أنشأه مدير هذا الدفتر.";break;
            case "saved-login":message="لم يعد الدخول المحفوظ صالحًا. اكتب بيانات الموظف من جديد.";break;
            case "mfa-invalid":message="لم يقبل الخادم رمز التحقق. راجع بيانات الدخول وأدخل رمزًا جديدًا.";break;
            default:message="لم يُؤكَّد الطلب. تحقّق من الاتصال وحدّث الدفتر قبل تكرار الحفظ.";
        }
        return error(code,message);
    }
    private static String error(String code,String message){
        try{return new JSONObject().put("code",code).put("error",message).toString();}
        catch(JSONException impossible){return "{}";}
    }
    private static TeamHttp.Reply call(String at,DeskRoute r,String login)throws Exception{
        return TeamHttp.exchange(at,r.path,r.post,login,r.body,r.passive,r.csv,r.issue,r.cap);
    }
    private static final class Result {
        final int status;final String data,issue;final boolean lost;
        Result(int status,String data,String issue,boolean lost){this.status=status;this.data=data;this.issue=issue;this.lost=lost;}
    }
    private static Result failed(int status,String code){return new Result(status,fault(code),null,"login".equals(code));}
    private static Result serverError(TeamHttp.Reply r,DeskRoute route)throws JSONException{
        if(r.status==401&&r.json.isEmpty())return route.name.equals("login")?
            failed(401,new JSONObject(route.body).has("otp")?"mfa-invalid":"credentials"):failed(401,"login");
        JSONObject o=new JSONObject(r.json);String code=o.optString("code",""),m=o.optString("error","");
        if(!code.matches("[a-z0-9-]{0,40}"))code="";
        if(m.isEmpty()||m.length()>400)return failed(r.status,r.status>=500?"network":"protocol");
        return new Result(r.status,error(code,m),null,r.status==401&&"login".equals(code));
    }
    private static Result checkInfo(String origin)throws Exception{
        DeskRoute route=DeskRoute.parse("info","",false);TeamHttp.Reply r=call(origin,route,null);
        if(r.status!=200)return serverError(r,route);
        JSONObject j=new JSONObject(r.json);
        if(!(j.opt("demo") instanceof Boolean))return failed(502,"protocol");
        if(j.getBoolean("demo"))return failed(403,"demo");
        if(j.has("initialized")&&!j.optBoolean("initialized",false))return failed(503,"owner-not-initialized");
        String version=j.optString("version","");
        if(!version.matches("3\\.(?:[1-9][0-9]?)(?:\\.[0-9]{1,3})?"))return failed(409,"version");
        if(j.optJSONObject("actions")==null||!j.getJSONObject("actions").has("view"))return failed(502,"protocol");
        return new Result(200,j.toString(),null,false);
    }
    private Result run(DeskRoute r,String prior)throws Exception{
        if(r.name.equals("info"))return checkInfo(origin);
        if(r.name.equals("login")){
            Result info=checkInfo(origin);if(info.status!=200)return info;
        }
        TeamHttp.Reply out=call(origin,r,prior);
        if(out.status<200||out.status>=300){
            // Some HTTPS clients drop streamed 401 bodies. For the two MFA-
            // checked session changes, distinguish a wrong factor from logout
            // with a passive session read, never by repeating the write.
            if(out.status==401&&out.json.isEmpty()&&prior!=null&&
                (r.name.equals("password")||r.name.equals("mfa/disable"))&&new JSONObject(r.body).has("otp")){
                TeamHttp.Reply probe=call(origin,DeskRoute.parse("me","",true),prior);
                if(probe.status==200)return failed(401,"mfa-invalid");
            }
            return serverError(out,r);
        }
        if(r.issue&&!TeamHttp.sessionValue(out.cookie))return new Result(502,fault("protocol"),null,true);
        JSONObject json=r.csv?new JSONObject().put("csv",out.json):new JSONObject(out.json);
        if(r.issue){
            JSONObject me=json.optJSONObject("me");
            if(me==null||!(me.opt("owner") instanceof Boolean)||!(me.opt("mustChange") instanceof Boolean))return new Result(502,fault("protocol"),null,true);
            if(keeper!=null){
                if(me.getBoolean("owner")){
                    // Discard the wrong account and close only the just-issued temporary session.
                    try{call(origin,DeskRoute.parse("logout","{}",false),out.cookie);}catch(Exception ignored){}
                    return new Result(403,fault("staff-role"),null,true);
                }
                if(!TeamHttp.memberId(me.optString("id"))||!me.optString("login").matches("[a-z0-9][a-z0-9._-]{2,31}"))return new Result(502,fault("protocol"),null,true);
            }
        }
        return new Result(out.status,json.toString(),out.cookie,false);
    }
    private Result complete(DeskRoute r,StaffLogin saved,boolean remember,Result x)throws JSONException{
        if(keeper==null)return x;
        if(saved!=null){
            if(x.status==401||x.status==428||(x.status==403&&"staff-role".equals(new JSONObject(x.data).optString("code")))){
                keeper.forget();return failed(401,"saved-login");
            }
            if(x.issue==null)return x;
            JSONObject o=new JSONObject(x.data),m=o.getJSONObject("me");
            if(!saved.user.equals(m.optString("id"))||!saved.login.equals(m.optString("login"))||m.optBoolean("mustChange",true)||m.optBoolean("mfa")){
                keeper.forget();return failed(401,"saved-login");
            }
            return new Result(x.status,o.put("deviceSaved",true).toString(),x.issue,false);
        }
        if(x.issue==null||r==null||!(r.name.equals("login")||r.name.equals("password")))return x;
        JSONObject o=new JSONObject(x.data),m=o.getJSONObject("me");
        boolean written=false,eligible=!m.optBoolean("mustChange",true)&&!m.optBoolean("mfa");
        if(remember&&eligible){
            try{written=keeper.write(new StaffLogin(m.getString("login"),new JSONObject(r.body).getString("password"),m.getString("id")));}
            catch(Exception ignored){}
        }
        if(!written)keeper.forget(); // Never retain a previous or temporary password after a new successful sign-in.
        o.put("deviceSaved",written);
        if(remember&&eligible&&!written)o.put("deviceSaveFailed",true);
        return new Result(x.status,o.toString(),x.issue,false);
    }
    void request(String ticket,String route,String raw,boolean passive,Reply out){request(ticket,route,raw,passive,false,out);}
    synchronized void request(String ticket,String route,String raw,boolean passive,boolean remember,Reply out){
        if(closed||!ticket(ticket))return;
        final boolean stored="device-login".equals(route);
        final DeskRoute parsed;
        try{
            if(stored){if(keeper==null||passive||remember||!"".equals(raw))throw new JSONException("request");parsed=null;}
            else parsed=DeskRoute.parse(route,raw,passive);
        }catch(Exception invalid){out.send(ticket,400,fault("request"));return;}
        if(pending!=null){out.send(ticket,409,fault("busy"));return;}
        final String name=stored?"device-login":parsed.name;
        final boolean info="info".equals(name),login=stored||"login".equals(name),logout="logout".equals(name);
        final String prior=info||login?null:cookie;
        if(logout&&keeper!=null)keeper.forget();
        if(!info&&!login&&prior==null){out.send(ticket,401,fault("login"));return;}
        if(login||logout)cookie=null;
        final long when=generation;
        pending=io.submit(()->{
            StaffLogin saved=null;DeskRoute r=parsed;Result result;
            try{
                if(stored){
                    saved=keeper.read();
                    if(saved!=null)r=DeskRoute.parse("login",new JSONObject().put("login",saved.login).put("password",saved.password).toString(),false);
                }
                result=r==null?failed(401,"saved-login"):run(r,prior);
            }
            catch(TeamHttp.Fault e){result=failed(502,e.code);}
            catch(SSLException tls){result=failed(502,"tls");}
            catch(JSONException shape){result=failed(502,"protocol");}
            catch(Exception ignored){result=failed(502,"network");}
            synchronized(this){
                if(closed||generation!=when)return;
                try{result=complete(r,saved,remember,result);}catch(Exception invalid){result=new Result(502,fault("protocol"),null,true);}
                pending=null;
                if(result.lost)cookie=null;
                else if(result.issue!=null)cookie=result.issue;
            }
            out.send(ticket,result.status,result.data);
        });
    }
    synchronized void clear(){generation++;cookie=null;if(pending!=null){pending.cancel(true);pending=null;}}
    synchronized void close(){clear();closed=true;io.shutdownNow();}
}
