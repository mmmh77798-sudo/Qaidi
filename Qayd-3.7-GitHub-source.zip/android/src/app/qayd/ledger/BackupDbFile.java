package app.qayd.ledger;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Arrays;

/** Qayd transport SQLite container. Stores the same UTF-8/Vault envelope in ordered BLOBs. */
final class BackupDbFile {
    static final String MIME="application/octet-stream";
    static final int MAX_FILE=48*1024*1024;
    private static final int APP_ID=0x51415944, CHUNK=65536;
    static void write(File path,byte[] bytes)throws IOException {
        if(bytes.length<1||bytes.length>LedgerStorage.MAX_DOC)throw new IOException("Payload size");
        boolean complete=false;
        try {
            try(SQLiteDatabase db=SQLiteDatabase.openDatabase(path.getAbsolutePath(),null,
                    SQLiteDatabase.CREATE_IF_NECESSARY|SQLiteDatabase.NO_LOCALIZED_COLLATORS)){
                db.disableWriteAheadLogging();
                try(Cursor cur=db.rawQuery("PRAGMA journal_mode=DELETE",null)){
                    if(!cur.moveToFirst()||!"delete".equalsIgnoreCase(cur.getString(0)))throw new IOException("Backup journal mode");
                }
                db.execSQL("PRAGMA application_id="+APP_ID);
                db.setVersion(1);
                db.execSQL("CREATE TABLE qayd_backup(part INTEGER PRIMARY KEY, payload BLOB NOT NULL)");
                db.beginTransaction();
                try(SQLiteStatement put=db.compileStatement("INSERT INTO qayd_backup(part,payload) VALUES(?,?)")){
                    for(int start=0;start<bytes.length;start+=CHUNK){
                        put.bindLong(1,start/CHUNK);
                        put.bindBlob(2,Arrays.copyOfRange(bytes,start,Math.min(start+CHUNK,bytes.length)));
                        put.executeInsert();
                    }
                    db.setTransactionSuccessful();
                }finally{db.endTransaction();}
            }
            if(path.length()==0||path.length()>MAX_FILE||new File(path.getPath()+"-wal").exists())throw new IOException("Incomplete backup");
            complete=true;
        }finally{if(!complete)delete(path);}
    }
    static void delete(File f){if(f!=null)try{SQLiteDatabase.deleteDatabase(f);}catch(RuntimeException ignored){}}
    static void copy(File file,OutputStream out)throws IOException {
        try(FileInputStream in=new FileInputStream(file)){
            byte[] buffer=new byte[32768];for(int n;(n=in.read(buffer))!=-1;)out.write(buffer,0,n);
        }
    }
}
