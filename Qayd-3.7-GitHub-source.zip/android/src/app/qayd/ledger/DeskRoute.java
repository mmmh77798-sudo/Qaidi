package app.qayd.ledger;

import java.net.URLDecoder;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/** Only 3.1 shared-ledger API calls. A file path, arbitrary URL, local backup,
 * import, or caller-supplied header can never become a network request. */
final class DeskRoute {
    final String name, path, body;
    final boolean post, csv, issue, passive;
    final int cap;
    private DeskRoute(String name,String path,String body,boolean csv,boolean issue,boolean passive,int cap){
        this.name=name;this.path=path;this.body=body;this.post=body!=null;this.csv=csv;this.issue=issue;this.passive=passive;this.cap=cap;
    }
    private static boolean in(String key,String values){return (" "+values+" ").contains(" "+key+" ")&&!key.isEmpty()&&key.indexOf(' ')<0;}
    private static void yes(boolean ok)throws JSONException{if(!ok)throw new JSONException("request");}
    private static void keys(JSONObject o,String allowed)throws JSONException{
        for(Iterator<String> i=o.keys();i.hasNext();)yes(in(i.next(),allowed));
    }
    private static String text(JSONObject o,String key,int length,boolean required)throws JSONException{
        if(!required&&!o.has(key))return "";
        Object v=o.opt(key);yes(v instanceof String&&((String)v).length()<=length&&(!required||!((String)v).isEmpty()));return (String)v;
    }
    private static void id(JSONObject o,String name)throws JSONException{yes(TeamHttp.memberId(text(o,name,40,true)));}
    private static void grants(JSONObject o)throws JSONException{
        JSONArray a=o.optJSONArray("grants");yes(a!=null&&a.length()<=201);
        for(int i=0;i<a.length();i++){
            JSONObject g=a.getJSONObject(i);keys(g,"category allow");yes(g.has("category"));
            yes(text(g,"category",80,false).matches("[a-zA-Z0-9_-]{0,80}"));
            JSONArray allow=g.optJSONArray("allow");yes(allow!=null&&allow.length()<=32);
            for(int j=0;j<allow.length();j++){
                Object v=allow.get(j);yes(v instanceof String&&((String)v).matches("[a-zA-Z][a-zA-Z0-9_]{0,31}"));
            }
        }
    }
    private static void change(JSONObject o)throws JSONException{
        keys(o,"action id fields");
        String a=text(o,"action",30,true),allowed;
        switch(a){
            case "account-add":case "account-edit":allowed="name category phone note";break;
            case "movement-add":allowed="kind account from to code day time amount memo due method reference target";break;
            case "movement-edit":allowed="day time amount memo due";break;
            case "collection-followup":allowed="code kind day note";break;
            case "category-add":case "category-edit":allowed="name";break;
            case "account-delete":case "movement-delete":allowed="";break;
            default:throw new JSONException("action");
        }
        // Ledger identifiers include built-in categories and imported records.
        // Only account-user IDs and concurrency versions are UUIDs.
        if(!a.endsWith("-add"))yes(text(o,"id",80,true).matches("[a-zA-Z0-9_-]{1,80}"));
        else if(o.has("id"))yes(text(o,"id",80,false).isEmpty());
        JSONObject f=o.getJSONObject("fields");keys(f,"version "+allowed);id(f,"version");
        for(Iterator<String> i=f.keys();i.hasNext();)text(f,i.next(),700,false);
    }
    private static void payload(String name,JSONObject o)throws JSONException{
        switch(name){
            case "login":keys(o,"login password otp");yes(text(o,"login",32,true).matches("[A-Za-z0-9][A-Za-z0-9._-]{2,31}"));text(o,"password",128,true);text(o,"otp",30,false);break;
            case "password":keys(o,"current password otp");text(o,"current",128,true);text(o,"password",128,true);text(o,"otp",30,false);break;
            case "logout":yes(o.length()==0);break;
            case "book/change":change(o);break;
            case "users/create":keys(o,"name login grants");text(o,"name",60,true);text(o,"login",32,true);grants(o);break;
            case "users/update":keys(o,"id version name enabled grants");id(o,"id");id(o,"version");text(o,"name",60,true);yes(o.opt("enabled") instanceof Boolean);grants(o);break;
            case "users/reset":case "users/revoke":keys(o,"id version");id(o,"id");id(o,"version");break;
            case "mfa/start":keys(o,"current");text(o,"current",128,true);break;
            case "mfa/enable":keys(o,"setup otp");text(o,"setup",32,true);text(o,"otp",30,true);break;
            case "mfa/disable":keys(o,"current otp");text(o,"current",128,true);text(o,"otp",30,true);break;
            default:throw new JSONException("post");
        }
    }
    private static void queries(String name,String q)throws Exception{
        if(q.isEmpty())return;
        String keys=name.equals("desk")?"code":in(name,"movements report report.csv collection collection.csv collection/detail audit")?
            "code category account q from to offset type state asOf":"";
        Set<String> seen=new HashSet<>();
        for(String item:q.split("&",-1)){
            String[] p=item.split("=",-1);
            yes(p.length==2&&in(p[0],keys)&&seen.add(p[0])&&p[1].matches("[a-zA-Z0-9.%_+*~\\-]*"));
            String value=URLDecoder.decode(p[1],"UTF-8");
            yes(value.length()<=160&&!value.matches("(?s).*[\\x00-\\x1f\\x7f].*"));
            if(!p[0].equals("q"))yes(value.matches("[A-Za-z0-9_.*\\-]{0,80}"));
        }
    }
    static DeskRoute parse(String raw,String json,boolean passive)throws Exception{
        yes(raw!=null&&!raw.isEmpty()&&raw.length()<=4000);
        int n=raw.indexOf('?');String name=n<0?raw:raw.substring(0,n),q=n<0?"":raw.substring(n+1);
        boolean post=json!=null&&!json.isEmpty(),csv=in(name,"report.csv collection.csv");
        if(post){
            yes(n<0&&!passive&&json.length()<=TeamHttp.REQUEST_LIMIT);
            JSONObject obj=new JSONObject(json);payload(name,obj);json=obj.toString();
        }else{
            yes(in(name,"info me status desk movements report collection collection/detail users audit report.csv collection.csv"));
            queries(name,q);json=null;
        }
        boolean issue=post&&in(name,"login password mfa/enable mfa/disable");
        int cap=in(name,"desk movements report collection collection/detail users audit")?TeamHttp.LEGACY_LIMIT:csv?2*1024*1024:TeamHttp.REPLY_LIMIT;
        return new DeskRoute(name,"/api/"+name+(q.isEmpty()?"":"?"+q),json,csv,issue,passive,cap);
    }
}
