package app.qayd.ledger;

/** Device navigation preference only. The server independently grants privileges. */
final class DeviceRole {
    static final String MANAGER="manager", STAFF="staff";
    private DeviceRole(){}
    static String initial(String saved,boolean upgraded,boolean hasLedger){
        if(MANAGER.equals(saved)||STAFF.equals(saved))return saved;
        return upgraded||hasLedger?MANAGER:"";
    }
    static String staffOrigin(String role,String saved){return STAFF.equals(role)?SharedOrigin.canonical(saved):null;}
    static boolean sameBinding(String role,String stored,String origin){
        return origin!=null&&origin.equals(staffOrigin(role,stored));
    }
}
