package app.qayd.ledger;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Base64;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/** Paired Bluetooth Classic SPP only. No discovery, background sending or printer data retention. */
final class ThermalPrinter implements AutoCloseable {
    static final int PERMISSION_RESULT=176;
    private static final UUID SPP=UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");
    interface Notice { void result(String text,boolean error); }
    private final Activity host;
    private final Notice notice;
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private final ScheduledExecutorService timer=Executors.newSingleThreadScheduledExecutor();
    private final AtomicBoolean busy=new AtomicBoolean();
    private final Object lock=new Object();
    private volatile boolean closed=false;
    private BluetoothSocket inFlight;
    // These are only accessed on the UI thread.
    private Job pendingPermission;
    private AlertDialog picker;
    private static final class Job {
        final int w,h; final String base64;
        Job(int w,int h,String base64){this.w=w;this.h=h;this.base64=base64;}
    }
    private static final class Destination {
        final BluetoothDevice device; final String label;
        Destination(BluetoothDevice device){
            this.device=device;
            String name=device.getName(),address=device.getAddress();
            if(name!=null)name=name.trim();
            if(name!=null&&name.length()>70)name=name.substring(0,70);
            label=(name==null||name.isEmpty()?"جهاز بلوتوث":name)+(address==null||address.length()<5?"":" · "+address.substring(address.length()-5));
        }
    }
    ThermalPrinter(Activity host,Notice notice){this.host=host;this.notice=notice;}
    private void say(String text,boolean error){if(!closed)notice.result(text,error);}
    private void failed(String s){busy.set(false);say(s,true);}
    void offer(int w,int h,String base64){
        if(!ThermalRaster.request(w,h,base64)){say("بيانات الإيصال غير صالحة أو طويلة جدًا.",true);return;}
        host.runOnUiThread(()->{
            if(closed||host.isFinishing())return;
            if(!busy.compareAndSet(false,true)){say("توجد طباعة حرارية قيد المعالجة.",true);return;}
            Job job=new Job(w,h,base64);
            if(Build.VERSION.SDK_INT>=31&&host.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){
                pendingPermission=job;
                try{host.requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},PERMISSION_RESULT);}
                catch(RuntimeException e){pendingPermission=null;failed("لم يُفتح طلب إذن الأجهزة القريبة. يمكنك استخدام طباعة النظام.");}
            }else choose(job);
        });
    }
    void permissionResult(boolean granted){
        final Job job=pendingPermission;pendingPermission=null;
        if(closed||job==null)return;
        if(granted)choose(job);else failed("لم يُسمح بالاتصال بطابعة بلوتوث. اختر طباعة النظام أو اسمح بالأجهزة القريبة.");
    }
    private void choose(Job job){
        if(closed||host.isFinishing()){busy.set(false);return;}
        try{
            BluetoothManager manager=host.getSystemService(BluetoothManager.class);
            BluetoothAdapter adapter=manager==null?null:manager.getAdapter();
            if(adapter==null||!adapter.isEnabled()){failed("شغّل البلوتوث واقترن بالطابعة من إعدادات الهاتف أولًا.");return;}
            List<Destination> peers=new ArrayList<>();
            for(BluetoothDevice d:adapter.getBondedDevices()){
                // BLE-only devices cannot accept this SPP print job.
                if(d.getType()!=BluetoothDevice.DEVICE_TYPE_LE)peers.add(new Destination(d));
            }
            peers.sort(Comparator.comparing(x->x.label,String.CASE_INSENSITIVE_ORDER));
            if(peers.isEmpty()){failed("لا توجد أجهزة بلوتوث كلاسيكية مقترنة. اقترن بالطابعة من إعدادات الهاتف أولًا.");return;}
            final String[] names=new String[peers.size()];for(int i=0;i<names.length;i++)names[i]=peers.get(i).label;
            final AtomicBoolean picked=new AtomicBoolean();
            picker=new AlertDialog.Builder(host).setTitle("اختر طابعة ESC/POS المقترنة فقط")
                .setItems(names,(dialog,i)->{picked.set(true);start(peers.get(i).device,job);})
                .setNegativeButton("إلغاء",null).create();
            picker.setOnDismissListener(d->{picker=null;if(!picked.get())busy.set(false);});picker.show();
        }catch(RuntimeException e){picker=null;failed("تعذّر عرض الأجهزة المقترنة. تحقق من البلوتوث وإذنه.");}
    }
    private void start(BluetoothDevice device,Job job){
        if(closed){busy.set(false);return;}
        say("جارٍ الاتصال بالطابعة…",false);
        io.execute(()->{
            BluetoothSocket sock=null;
            ScheduledFuture<?> deadline=null;
            AtomicBoolean timeout=new AtomicBoolean();
            try {
                final byte[] pixels=Base64.decode(job.base64,Base64.DEFAULT);
                if(pixels.length!=ThermalRaster.bytes(job.w,job.h))throw new IllegalArgumentException();
                if(closed)return;
                sock=device.createRfcommSocketToServiceRecord(SPP);
                synchronized(lock){if(closed)return;inFlight=sock;}
                final BluetoothSocket active=sock;
                deadline=timer.schedule(()->{timeout.set(true);quietClose(active);},50,TimeUnit.SECONDS);
                sock.connect();
                try(OutputStream out=sock.getOutputStream()){ThermalRaster.write(out,job.w,job.h,pixels);}
                if(!timeout.get())say("أُرسلت بيانات الإيصال إلى الطابعة.",false);
                else say("انتهت مهلة الطباعة. تحقق من الورق والاتصال قبل إعادة المحاولة.",true);
            }catch(IOException|RuntimeException e){
                say(timeout.get()?"انتهت مهلة الاتصال بالطابعة. تحقّق من مدى البلوتوث.":"تعذّرت الطباعة. تحقّق من أن الطابعة تدعم ESC/POS عبر Bluetooth Classic، أو جرّب طباعة النظام.",true);
            }finally{
                if(deadline!=null)deadline.cancel(false);
                quietClose(sock);
                synchronized(lock){if(inFlight==sock)inFlight=null;}
                busy.set(false);
            }
        });
    }
    private static void quietClose(BluetoothSocket s){if(s!=null)try{s.close();}catch(IOException ignored){}}
    @Override public void close(){
        if(closed)return;
        closed=true;pendingPermission=null;
        if(picker!=null){picker.dismiss();picker=null;}
        final BluetoothSocket active;
        synchronized(lock){active=inFlight;inFlight=null;}
        quietClose(active);timer.shutdownNow();io.shutdownNow();
    }
}
