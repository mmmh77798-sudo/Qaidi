package app.qayd.ledger;

import java.net.URI;
import java.util.Locale;

/** Defense in depth: the team channel accepts only a bare HTTPS origin. */
final class SharedOrigin {
    private SharedOrigin() {}
    static String canonical(String candidate) {
        String v=verify(candidate);if(v==null)return null;
        URI uri=URI.create(v);int port=uri.getPort();
        String host=uri.getHost().toLowerCase(Locale.ROOT);
        return "https://"+host+(port<0||port==443?"":":"+port);
    }
    static String verify(String candidate) {
        if (candidate==null||candidate.length()>253||!candidate.startsWith("https://")||candidate.indexOf('%')>=0||candidate.indexOf('\\')>=0) return null;
        try {
            URI uri=new URI(candidate);
            int port=uri.getPort();
            if (!"https".equals(uri.getScheme())||uri.getHost()==null||uri.getRawUserInfo()!=null||uri.getRawQuery()!=null||uri.getRawFragment()!=null||
                    !(uri.getRawPath().isEmpty()||"/".equals(uri.getRawPath()))||port==0||port>65535) return null;
            return uri.toASCIIString();
        } catch (Exception error) { return null; }
    }
}
