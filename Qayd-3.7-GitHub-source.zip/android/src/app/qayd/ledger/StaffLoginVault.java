package app.qayd.ledger;

import android.app.KeyguardManager;
import android.content.Context;
import android.os.Build;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.security.Key;
import java.security.KeyStore;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

/** Staff opt-in only, on a locked-capable device. No OTPs, cookies or plaintext files. */
final class StaffLoginVault implements StaffLogin.Keeper {
    private static final String ALIAS="qayd.staff.login.gcm.v1";
    private static final Object KEY_LOCK=new Object();
    private final DeviceProfile profile;
    private final KeyguardManager keyguard;
    private final String origin;
    StaffLoginVault(Context c,DeviceProfile p,String origin){profile=p;keyguard=c.getSystemService(KeyguardManager.class);this.origin=origin;}
    @Override public boolean available(){
        if(!profile.bound(origin)||keyguard==null)return false;
        if(!keyguard.isDeviceSecure()){if(!profile.sealed(origin).isEmpty())forget();return false;}
        return !keyguard.isDeviceLocked();
    }
    @Override public boolean has(){return available()&&!profile.sealed(origin).isEmpty();}
    private static SecretKey key(boolean create)throws Exception{
        synchronized(KEY_LOCK){
            KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);
            Key old=store.getKey(ALIAS,null);if(old instanceof SecretKey)return (SecretKey)old;
            if(!create||old!=null)throw new IllegalStateException("Key unavailable");
            KeyGenerator g=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
            KeyGenParameterSpec.Builder spec=new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
                .setKeySize(256).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true);
            // Earlier versions have platform issues with unlocked-device-only keys.
            // They still check the current screen lock above before every operation.
            if(Build.VERSION.SDK_INT>=35)spec.setUnlockedDeviceRequired(true);
            g.init(spec.build());return g.generateKey();
        }
    }
    @Override public StaffLogin read(){
        if(!available())return null;
        String v=profile.sealed(origin);if(v.isEmpty())return null;
        try{if(v.length()>3000)throw new IllegalArgumentException("sealed");return StaffLogin.open(key(false),origin,Base64.decode(v,Base64.NO_WRAP));}
        catch(Exception e){if(available())forget();return null;}
    }
    @Override public boolean write(StaffLogin auth){
        if(!available())return false;
        try{return profile.keep(origin,Base64.encodeToString(auth.seal(key(true),origin),Base64.NO_WRAP));}
        catch(Exception e){return false;}
    }
    @Override public boolean forget(){return profile.forget(origin);}
}
