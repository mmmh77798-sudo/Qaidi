package app.qayd.ledger;

import android.content.Context;
import android.util.AtomicFile;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/** Atomically saves the ledger and (only when needed) a matching backup snapshot without photos. */
final class LedgerStorage {
    static final int MAX_DOC = 20*1024*1024;
    private static final byte[] WRAP="QAYD2\n".getBytes(StandardCharsets.US_ASCII);
    private static final Object mutex=new Object();
    private final AtomicFile file;
    LedgerStorage(Context c){file=new AtomicFile(new File(c.getFilesDir(),"ledger-v1.json"));}
    private int split(byte[] all)throws IOException {
        if(all.length<WRAP.length||!Arrays.equals(Arrays.copyOf(all,WRAP.length),WRAP))return -1;
        for(int i=WRAP.length;i<Math.min(all.length,WRAP.length+12);i++)if(all[i]=='\n')return i;
        throw new IOException("Invalid ledger header");
    }
    byte[] bytes(boolean forBackup) throws IOException {
        synchronized(mutex) {
            byte[] all;
            try{all=file.readFully();}catch(FileNotFoundException e){return null;}
            if(all.length>MAX_DOC*2+64)throw new IOException("Ledger too large");
            int s=split(all);if(s<0)return all;
            int n;
            try{n=Integer.parseInt(new String(all,WRAP.length,s-WRAP.length,StandardCharsets.US_ASCII));}catch(NumberFormatException e){throw new IOException(e);}
            if(n<=0||n>MAX_DOC||s+1+n>=all.length)throw new IOException("Invalid ledger header");
            return forBackup?Arrays.copyOfRange(all,s+1+n,all.length):Arrays.copyOfRange(all,s+1,s+1+n);
        }
    }
    boolean put(String main,String withoutPhotos) {
        if(main==null||main.isEmpty()||main.length()>MAX_DOC||(withoutPhotos!=null&&withoutPhotos.length()>MAX_DOC))return false;
        byte[] one=main.getBytes(StandardCharsets.UTF_8),two=withoutPhotos==null?null:withoutPhotos.getBytes(StandardCharsets.UTF_8);
        if(one.length>MAX_DOC||(two!=null&&(two.length<1||two.length>MAX_DOC)))return false;
        synchronized(mutex){
            FileOutputStream out=null;
            try {
                out=file.startWrite();
                if(two!=null){out.write(WRAP);out.write((Integer.toString(one.length)+"\n").getBytes(StandardCharsets.US_ASCII));}
                out.write(one);if(two!=null)out.write(two);
                file.finishWrite(out);return true;
            }catch(IOException e){if(out!=null)file.failWrite(out);return false;}
        }
    }
}
