package app.qayd.ledger;

import java.util.regex.Pattern;

/** Bounds locally generated XLSX bytes at the Android share/save bridge. */
final class WorkbookExport {
    static final String MIME="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    static final int MAX_BYTES=20*1024*1024;
    private static final Pattern NAME=Pattern.compile("qayd-(?:statement|report)-[A-Za-z0-9_-]{1,85}\\.xlsx");
    private WorkbookExport(){}
    static boolean request(String name,String value,String mode){
        return name!=null&&NAME.matcher(name).matches()&&("local".equals(mode)||"share".equals(mode))&&
               value!=null&&value.length()>=80&&value.length()<=4*((MAX_BYTES+2)/3)&&(value.length()&3)==0;
    }
    static boolean zipEnvelope(byte[] a){
        // The workbook writer does not add a ZIP comment; keep the bridge narrow.
        if(a==null||a.length<76||a.length>MAX_BYTES||a[0]!='P'||a[1]!='K'||a[2]!=3||a[3]!=4)return false;
        int end=a.length-22;
        if(a[end]!='P'||a[end+1]!='K'||a[end+2]!=5||a[end+3]!=6||a[end+20]!=0||a[end+21]!=0)return false;
        long offset=u32(a,end+16),size=u32(a,end+12);
        return offset>=30&&size>=46&&offset+size==end&&a[(int)offset]=='P'&&a[(int)offset+1]=='K'&&a[(int)offset+2]==1&&a[(int)offset+3]==2;
    }
    private static long u32(byte[] a,int p){return (a[p]&255L)|((a[p+1]&255L)<<8)|((a[p+2]&255L)<<16)|((a[p+3]&255L)<<24);}
}
