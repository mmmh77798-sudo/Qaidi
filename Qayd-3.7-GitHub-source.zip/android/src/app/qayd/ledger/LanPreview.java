package app.qayd.ledger;

import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Locale;

/** A short-lived, capability-URL server. Serves one immutable HTML snapshot and no other assets. */
final class LanPreview implements Closeable {
    private final ServerSocket server;
    private final String path;
    private final String url;
    private final byte[] payload;
    private final long end = System.nanoTime() + 10L * 60L * 1_000_000_000L;
    private volatile boolean closed;
    private volatile Socket connection;

    LanPreview(Inet4Address address,String html) throws IOException {
        byte[] data=html.getBytes(StandardCharsets.UTF_8);
        if(data.length==0||data.length>4*1024*1024)throw new IOException("snapshot size");
        this.payload=data;
        byte[] random=new byte[24];new SecureRandom().nextBytes(random);
        StringBuilder token=new StringBuilder();for(byte b:random)token.append(String.format(Locale.ROOT,"%02x",b&0xff));
        this.path="/view/"+token+"/";
        this.server=new ServerSocket();
        try {server.bind(new InetSocketAddress(address,0),4);server.setSoTimeout(1000);}
        catch(IOException e){server.close();throw e;}
        this.url="http://"+address.getHostAddress()+":"+server.getLocalPort()+path;
        Thread thread=new Thread(this::run,"qayd-lan-view");thread.setDaemon(true);thread.start();
    }
    String url(){return url;}
    boolean alive(){return !closed;}
    private void run(){
        try {
            while(!closed&&System.nanoTime()<end) {
                Socket s;
                try{s=server.accept();}catch(SocketTimeoutException e){continue;}
                connection=s;
                try(Socket ignored=s) {
                    if(closed)break;
                    s.setSoTimeout(1800);serve(s);
                }catch(IOException ignored){}finally{connection=null;}
            }
        }catch(IOException ignored){}finally{close();}
    }
    private void serve(Socket s)throws IOException {
        InputStream in=s.getInputStream(); ByteArrayOutputStream headers=new ByteArrayOutputStream(512);
        int tail=0, n; final long deadline=System.nanoTime()+2L*1_000_000_000L;
        while(headers.size()<8192&&System.nanoTime()<deadline) {
            n=in.read();if(n<0)return;headers.write(n);tail=(tail<<8)|n;if(tail==0x0d0a0d0a)break;
        }
        if(tail!=0x0d0a0d0a){reply(s,400,"Bad Request",false,new byte[0]);return;}
        String text=new String(headers.toByteArray(),StandardCharsets.US_ASCII);
        String[] line=text.substring(0,text.indexOf("\r\n")).split(" ",-1);
        if(line.length!=3||!("HTTP/1.1".equals(line[2])||"HTTP/1.0".equals(line[2]))){reply(s,400,"Bad Request",false,new byte[0]);return;}
        boolean head="HEAD".equals(line[0]);
        if(!head&&!"GET".equals(line[0])){reply(s,405,"Method Not Allowed",false,new byte[0]);return;}
        if (!MessageDigest.isEqual(line[1].getBytes(StandardCharsets.US_ASCII),path.getBytes(StandardCharsets.US_ASCII))){reply(s,404,"Not Found",head,new byte[0]);return;}
        reply(s,200,"OK",head,payload);
    }
    private static void reply(Socket s,int code,String status,boolean head,byte[] body)throws IOException {
        OutputStream out=s.getOutputStream();
        String hs="HTTP/1.1 "+code+" "+status+"\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: "+body.length+"\r\n"+
          "Cache-Control: no-store, private\r\nPragma: no-cache\r\nReferrer-Policy: no-referrer\r\nX-Content-Type-Options: nosniff\r\nX-Frame-Options: DENY\r\n"+
          "Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'\r\nConnection: close\r\n\r\n";
        out.write(hs.getBytes(StandardCharsets.US_ASCII));if(!head)out.write(body);out.flush();
    }
    @Override public void close(){closed=true;try{server.close();}catch(IOException ignored){}Socket s=connection;if(s!=null)try{s.close();}catch(IOException ignored){}}
}
