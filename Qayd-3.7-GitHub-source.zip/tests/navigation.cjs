'use strict';
// Drive the visible navigation, including collapsed tools, without changing UI state directly.
async function reveal(locator){
  const parent=locator.locator('xpath=ancestor::details[not(@open)][last()]/summary[1]');
  while(await parent.count())await parent.click();
  return locator;
}
const localBar=(p,key)=>p.locator(`#sidebar [data-view=${key}]:visible,#mobilebar [data-view=${key}]:visible`).first();
async function localNav(p,key){
  if(['home','accounts','moves','settings'].includes(key))return localBar(p,key).click();
  await localBar(p,'settings').click();
  return p.locator(`#page [data-action=go][data-view=${key}]:visible`).click();
}
async function localSetting(p,key){
  await localNav(p,'settings');
  return (await reveal(p.locator(`#page [data-action=settings-open][data-key=${key}]`))).click();
}
async function localCollection(p,key){
  if(key==='receipts')await localNav(p,'moves');else await localNav(p,'settings');
  return p.locator(`#page [data-action=collection-open][data-key=${key}]:visible`).click();
}
const deskBar=(p,key)=>p.locator(`nav [data-page=${key}]:visible`).first();
async function deskNav(p,key){
  if(['home','accounts','movements','more'].includes(key))return deskBar(p,key).click();
  await deskBar(p,'more').click();
  return p.locator(`#page [data-action=go][data-page=${key}]:visible`).click();
}
module.exports={reveal,localNav,localSetting,localCollection,deskNav};
