/* Synthetic ledger shared by category portability and browser assertions. */
const L=require('../app/ledger.js');
const C=require('../app/collections-model.js');
const photo='data:image/jpeg;base64,/9j/2Q==';
const target='clients';
const make=(d,id,fields)=>{const e=L.saveEntry(d,{code:'YER',day:'2025-04-24',time:'09:30',...fields});e.id=id;return e;};
function fixture(){
  const d=L.empty();
  d.currencies[0].name='محلي';d.currencies.push({code:'OMR',name:'ريال عماني',symbol:'ر.ع'});
  d.settings.business='GLOBAL-PROFILE-TEST';d.settings.profile.logo=photo;
  d.accounts=[['a','مؤسسة الفجر','clients'],['b','متجر الندى','clients'],['x','مورد الساحة الخارجي','suppliers'],['y','مورد النخيل الخارجي','suppliers'],['u','حساب بلا فئة','']].map(([id,name,category])=>({id,name,category,phone:id==='x'?'+967770001223':'',note:id==='x'?'OUTSIDE-ACCOUNT-ONLY':'',color:'mint'}));
  make(d,'opening',{kind:'credit',account:'a',amount:'125.125',day:'2025-02-06',due:'2025-02-20',memo:'بضاعة تجريبية',photo});
  make(d,'inside',{kind:'transfer',from:'a',to:'b',amount:'17.125',day:'2025-03-01',memo:'مناولة داخل التصنيف'});
  make(d,'out-move',{kind:'transfer',from:'a',to:'x',amount:'37.250',day:'2025-04-02',due:'2025-06-30',memo:'SHARED-MEMO-OUTSIDE',photo});
  make(d,'in-move',{kind:'transfer',from:'x',to:'a',amount:'90.500',code:'SAR',day:'2025-04-03',due:'2025-06-18',memo:'SHARED-MEMO-IN'});
  make(d,'supplies',{kind:'credit',account:'y',amount:'99.250',code:'USD',memo:'OUTSIDE-POSTING-ONLY'});
  make(d,'unassigned',{kind:'debit',account:'u',code:'USD',amount:'0.005'});
  const r=C.saveReceipt(d,{account:'a',code:'SAR',amount:'20.125',day:'2025-05-04',time:'14:10',receipt:{method:'wallet',reference:'CAT-REF-1',target:'in-move'}});r.id='receipt-a';
  const v=C.saveReceipt(d,{account:'x',code:'YER',amount:'8.125',day:'2025-05-09',time:'14:11',receipt:{method:'cash',reference:'OUTSIDE-REF',target:'out-move'}});v.id='receipt-x';
  L.setAccountLimit(d,'a','OMR',{direction:'credit',minor:300125});
  L.setFollowup(d,'b','YER',{kind:'promise',day:'2025-06-10',note:'متابعة محلية للفئة',at:1730000000000});
  L.closeBalance(d,'a','YER','2025-02-10');
  L.recordActivity(d,{type:'entry-add',subject:'AUDIT-PRIVATE-OTHER-CATEGORY',detail:'OUTSIDE-POSTING-ONLY'});
  return L.validate(d);
}
function currentFrom(base){
  const d=L.stateClone(base);
  d.settings.business='DESTINATION-ONLY';d.settings.digits='arabic';d.lastBackup='2025-06-01';
  d.categories.find(c=>c.id===target).name='عملاء هذا الجهاز';
  d.accounts.push({id:'extra',name:'عميل أضيف بعد النسخ',category:target,phone:'',color:'sky'});
  make(d,'extra-sale',{kind:'credit',account:'extra',amount:'60.375',day:'2025-06-12'});
  make(d,'outside-recent',{kind:'debit',account:'y',code:'USD',amount:'3.023',memo:'OUTSIDE-RECENT-STAYS',day:'2025-06-12'});
  const rr=C.saveReceipt(d,{account:'y',code:'USD',amount:'8.005',day:'2025-06-13',receipt:{method:'other',reference:'STAYS-REF'}});rr.id='receipt-y';
  L.closeBalance(d,'y','USD','2025-05-31');
  return L.validate(d);
}
function outside(d,id=target){
  const accounts=d.accounts.filter(a=>a.category!==id),ids=new Set(accounts.map(a=>a.id));
  return {accounts,entries:d.entries.filter(e=>e.legs.some(l=>ids.has(l.account))),closures:d.closures.filter(c=>ids.has(c.account)),categories:d.categories.filter(c=>c.id!==id),settings:d.settings,years:d.years,lastBackup:d.lastBackup};
}
module.exports={fixture,currentFrom,outside,make,target,photo};
