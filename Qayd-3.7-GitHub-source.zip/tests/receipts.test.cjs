const {test}=require('node:test');
const assert=require('node:assert/strict');
const L=require('../app/ledger.js');
const C=require('../app/collections-model.js');

const today='2024-12-13',day=n=>L.offset(n,today);
function fixture(){
  const d=L.empty();d.accounts=['A','B','C'].map(id=>({id,name:'حساب '+id,phone:'',category:'clients',color:'mint'}));return d;
}
const post=(d,minor,n,extra={})=>L.saveEntry(d,{account:'A',code:'YER',day:day(n),time:'09:00',kind:minor>0?'credit':'debit',amount:L.decimal(Math.abs(minor)),...extra});
const recv=(d,minor,n,{id='',account='A',code='YER',method='cash',reference='',target='',date=day(n)}={})=>C.saveReceipt(d,{id,account,code,day:date,time:'13:30',amount:L.decimal(minor),receipt:{method,reference,target}});
const room=(d,n,account='A',code='YER',extra={})=>C.snapshot(d,code,day(n),{accountId:account,...extra}).index.get(account);
const portions=row=>(row?.items||[]).map(x=>[x.id,x.open]);

function assertUnchanged(d,reject,pattern){
  const before=JSON.stringify(d);assert.throws(reject,pattern);assert.equal(JSON.stringify(d),before);
}

test('new receipts are numbered across accounts and currencies, edits keep their number, and delete never recycles it',()=>{
  const d=fixture();post(d,102000,-9);post(d,90000,-8,{account:'B',code:'SAR'});
  const ordinary=post(d,-1000,-7);assert.equal(ordinary.receipt,undefined);assert.equal(d.receiptSerial,undefined);
  const a=recv(d,1125,-1,{reference:'  QR-001  ',method:'bank'}),b=recv(d,2001,-2,{account:'B',code:'SAR',method:'wallet'});
  assert.deepEqual(a.receipt,{number:1,method:'bank',reference:'QR-001'});assert.deepEqual(a.legs,[{account:'A',code:'YER',minor:-1125}]);
  assert.equal(L.receiptNumber(a.receipt.number),'000001');assert.equal(b.receipt.number,2);
  const edited=recv(d,2000,-1,{id:a.id,method:'check',reference:'TX-02'});
  assert.equal(edited.id,a.id);assert.equal(edited.created,a.created);assert.equal(edited.receipt.number,1);assert.equal(edited.receipt.method,'check');
  assertUnchanged(d,()=>recv(d,2000,-1,{id:a.id,account:'B',code:'SAR'}),/حساب أو عملة أخرى/);
  assertUnchanged(d,()=>recv(d,1000,-7,{id:ordinary.id}),/لم يعد سند/);
  const copy=L.validate(JSON.parse(JSON.stringify(d)));L.removeEntry(copy,b.id);L.removeEntry(copy,a.id);
  assert.equal(L.validate(copy).receiptSerial,2);
  const next=recv(copy,5000,0,{method:'other'});assert.equal(next.receipt.number,3);
  const high=L.stateClone(copy);high.receiptSerial=999999999;
  assertUnchanged(high,()=>recv(high,1000,0),/الحد الأقصى/);
});

test('date-by-date specific allocations run before FIFO and agree with the dated statement',()=>{
  const d=fixture(),old=post(d,100125,-20,{due:day(-16)}),young=post(d,175500,-7,{due:day(-4)});
  post(d,-35250,-15); // ordinary (not numbered)
  const r=recv(d,60125,-3,{method:'bank',target:young.id});
  assert.deepEqual(portions(room(d,-4)),[[old.id,64875],[young.id,175500]]);
  const v=room(d,0);
  assert.deepEqual(portions(v),[[old.id,64875],[young.id,115375]]);
  assert.equal(v.total,180250);assert.equal(v.total,L.statement(d,'A','YER',{to:today,archive:true}).ending);
  assert.deepEqual(portions(room(d,0,'A','YER',{omitReceipt:r.id})),[[old.id,64875],[young.id,175500]]);
  assert.equal(room(d,0,'A','SAR'),undefined);
  const fifo=L.validate(L.stateClone(d));L.clearReceiptTarget(fifo,r.id);
  assert.deepEqual(portions(room(fifo,0)),[[old.id,4750],[young.id,175500]]);
  assert.equal(room(fifo,0).total,v.total);assert.equal(fifo.receiptSerial,d.receiptSerial);
});

test('receipt amount caps depend on selected day and lot, excluding superseded amount; rejected commands are atomic',()=>{
  const d=fixture(),a=post(d,100125,-6),b=post(d,200250,-3);
  post(d,-25000,-5);
  assertUnchanged(d,()=>recv(d,6000,-4,{target:b.id}),/لا يتبقى/);
  assertUnchanged(d,()=>recv(d,75126,-4),/أكبر من الذمة/);
  assertUnchanged(d,()=>recv(d,75126,-4,{target:a.id}),/أكبر من المتبقي/);
  assertUnchanged(d,()=>recv(d,1000,0,{date:L.offset(1)}),/لا يتجاوز اليوم/);
  assertUnchanged(d,()=>recv(d,1000,0,{method:'invalid'}),/طريقة قبض/);
  assertUnchanged(d,()=>recv(d,1000,0,{reference:'X'.repeat(91)}),/نصية/);
  const r=recv(d,150000,-2,{target:b.id,method:'wallet'});
  const edit=recv(d,195125,-2,{id:r.id,target:b.id,method:'wallet'});
  assert.equal(edit.receipt.number,1);assert.equal(d.receiptSerial,1);assert.equal(room(d,0).total,80250);
  assertUnchanged(d,()=>recv(d,200251,-2,{id:r.id,target:b.id}),/أكبر من المتبقي/);
  assertUnchanged(d,()=>recv(d,195125,-4,{id:r.id,target:b.id}),/لا يتبقى/);
  post(d,-100000,-2); // other, independently edited postings may consume the dated balance
  assert.equal(room(d,0),undefined);
  const methodOnly=recv(d,195125,-2,{id:r.id,target:b.id,method:'bank'});
  assert.equal(methodOnly.receipt.number,1);assert.equal(methodOnly.receipt.method,'bank');assert.equal(room(d,0),undefined);
});

test('a linked charge cannot be deleted, moved, redated or reduced below its explicit allocations',()=>{
  const d=fixture(),a=post(d,150125,-5);post(d,88125,-6,{account:'B'});
  const r=recv(d,60125,-2,{target:a.id}),s=recv(d,40000,-1,{target:a.id});
  assertUnchanged(d,()=>L.removeEntry(d,a.id),/ألغِ التخصيص/);
  assertUnchanged(d,()=>post(d,150125,-5,{id:a.id,code:'SAR'}),/الحساب أو العملة أو التاريخ/);
  assertUnchanged(d,()=>post(d,150125,-5,{id:a.id,account:'B'}),/الحساب أو العملة أو التاريخ/);
  assertUnchanged(d,()=>post(d,150125,-1,{id:a.id}),/الحساب أو العملة أو التاريخ/);
  assertUnchanged(d,()=>post(d,100124,-5,{id:a.id}),/مجموع سندات القبض/);
  post(d,100125,-5,{id:a.id}); // still matches both receipts exactly
  assert.equal(room(d,0),undefined);assert.equal(L.clearReceiptTarget(d,r.id),true);
  assert.equal(L.clearReceiptTarget(d,r.id),false);assertUnchanged(d,()=>L.removeEntry(d,a.id),/ألغِ التخصيص/);
  L.removeEntry(d,s.id);assert.equal(L.validate(d).receiptSerial,2);
  L.removeEntry(d,a.id);assert.equal(L.validate(d).entries.find(e=>e.id===r.id).receipt.target,undefined);
  assert.equal(L.statement(d,'A','YER').ending,-60125);
});

test('archived transfer leg accepts allocation; unlink can change metadata without changing closed postings',()=>{
  const d=fixture();const t=L.saveEntry(d,{kind:'transfer',from:'B',to:'A',code:'YER',amount:'68.555',day:day(-8)});
  assertUnchanged(d,()=>recv(d,5555,0,{target:t.id,account:'B'}),/لا يتبقى/);
  L.closeBalance(d,'A','YER',day(-7));assert.equal(L.isLocked(d,t.id),true);
  assertUnchanged(d,()=>recv(d,5555,-8,{target:t.id}),/فترة مغلقة/);
  const r=recv(d,5555,-4,{target:t.id,method:'bank'});
  assert.equal(room(d,0).total,63000);assert.equal(room(d,0).items[0].transfer,true);
  assert.equal(L.statement(d,'B','YER').ending,-68555);assert.equal(L.statement(d,'A','YER').ending,63000);
  L.openBalance(d,'A','YER');assertUnchanged(d,()=>L.removeAccount(d,'B'),/سند قبض في حساب آخر/);
  L.closeYear(d,2024);const closed=JSON.stringify(d.closures);
  const locked=JSON.stringify(d.entries.map(e=>[e.id,e.legs,e.day]));
  assertUnchanged(d,()=>recv(d,5555,-4,{id:r.id,target:t.id,method:'cash'}),/السنة مغلقة|إغلاق الرصيد/);
  assert.equal(L.clearReceiptTarget(d,r.id),true);assert.equal(JSON.stringify(d.closures),closed);
  assert.equal(JSON.stringify(L.validate(d).entries.map(e=>[e.id,e.legs,e.day])),locked);
  assert.equal(L.isLocked(d,r.id),true);
  L.openYear(d);L.removeAccount(d,'B');assert.equal(L.validate(d).entries.length,1);assert.equal(d.receiptSerial,1);
});

test('invalid receipt metadata on restore is rejected instead of silently dropping issued numbers',()=>{
  const d=fixture(),lot=post(d,120000,-9);post(d,160000,-9,{account:'B'});post(d,100000,-9,{code:'SAR'});
  recv(d,54000,-2,{target:lot.id});recv(d,30000,-1,{target:lot.id});
  const valid=L.validate(d);assert.deepEqual(L.validate(valid),valid);
  const invalid=(edit,pattern)=>{const x=L.stateClone(valid);edit(x,x.entries.at(-1));assert.throws(()=>L.validate(x),pattern);};
  invalid(x=>delete x.receiptSerial,/تسلسل/);
  invalid(x=>{x.receiptSerial=1;},/تسلسل/);
  invalid(x=>{x.receiptSerial='2';},/رقم آخر/);
  invalid((x,r)=>{r.receipt.number=1;},/مكرر/);
  invalid((x,r)=>{r.receipt.method='swift';},/بيانات سند/);
  invalid((x,r)=>{r.legs[0].minor=30000;},/بيانات سند/);
  invalid((x,r)=>{r.receipt.target='does-not-exist';},/الحساب أو العملة أو التاريخ/);
  invalid((x,r)=>{r.receipt.target=x.entries[1].id;},/الحساب أو العملة أو التاريخ/);
  invalid((x,r)=>{r.receipt.target=x.entries[2].id;},/الحساب أو العملة أو التاريخ/);
  invalid((x,r)=>{r.legs[0].minor=-66001;},/مجموع سندات القبض/);
  invalid((x,r)=>{r.day=day(-10);},/الحساب أو العملة أو التاريخ/);
});

test('reconciles mixed explicit receipts, FIFO and transfers through multiple cutoffs without remainders or decimals drifting',()=>{
  const d=fixture();let x=95735;
  const rand=n=>{x=(Math.imul(x,1664525)+1013904223)>>>0;return (x>>>7)%n;};
  for(let i=0;i<306;i++){
    const account=['A','B','C'][rand(3)],code=['YER','SAR','USD'][rand(3)],n=-150+Math.floor(i/3);
    const amt=rand(78755)+1,config={account,code};
    if(rand(5)<3)post(d,amt,n,{...config,...(rand(2)?{due:day(n+rand(70))}:{})});
    else if(rand(2))L.saveEntry(d,{kind:'transfer',from:account,to:account==='A'?'B':'A',code,day:day(n),amount:L.decimal(amt)});
    else{
      const v=room(d,n,account,code);if(!v){post(d,-amt,n,config);continue;}
      const lot=rand(2)?v.items[rand(v.items.length)]:null;
      recv(d,Math.min(amt,lot?.open||v.total),n,{...config,method:L.receiptMethods[rand(5)],target:lot?.id||''});
    }
  }
  const checked=L.validate(d);
  assert.ok(checked.entries.filter(e=>e.receipt?.target).length>10);
  for(const code of ['YER','SAR','USD'])for(const n of [-170,-138,-112,-78,-45,0]){
    const v=C.snapshot(checked,code,day(n));
    for(const a of checked.accounts){
      const r=v.index.get(a.id),s=L.statement(checked,a.id,code,{to:day(n),archive:true});
      assert.equal(r?.total||0,Math.max(0,s.ending));if(!r)continue;
      assert.equal(r.items.reduce((sum,l)=>sum+l.open,0),r.total);assert.ok(r.items.every(l=>l.open>0&&l.open<=l.original));
      assert.equal(Object.keys(C.fields).reduce((sum,k)=>sum+r[k],0),r.total);
    }
  }
});
