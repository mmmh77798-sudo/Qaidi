const {test}=require('node:test');
const assert=require('node:assert/strict');
const S=require('../app/shared-link.js');
test('the app saves only a bare HTTPS origin; credentials, paths and non-HTTPS schemes are refused',()=>{
  assert.equal(S.origin(' https://QAYD.example.test:443/ '),'https://qayd.example.test');
  assert.equal(S.origin('https://[2001:db8::1]:8843'),'https://[2001:db8::1]:8843');
  for(const url of ['javascript:alert(1)','file:///android_asset/app/index.html','http://qayd.test','https://qayd.test:0','https://u:p@qayd.test','https://qayd.test/secret','https://qayd.test/..','https://qayd.test?password=test','https://qayd.test/#token','https://qayd.test\\another','https://qayd.test\u202e.evil','https://bad_name.test','//qayd.test','https:///qayd.test','https://qayd.test:65536'])assert.throws(()=>S.origin(url),undefined,url);
});
test('link preference stores the address only and can be forgotten without ledger access',()=>{
  const rows=new Map(),storage={getItem:k=>rows.get(k),setItem:(k,v)=>rows.set(k,v),removeItem:k=>rows.delete(k)};
  assert.equal(S.read(storage),'');S.write(storage,'https://qayd.test/');assert.equal(S.read(storage),'https://qayd.test');
  assert.deepEqual([...rows.values()],['https://qayd.test']);S.forget(storage);assert.equal(rows.size,0);
});
