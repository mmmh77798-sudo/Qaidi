const {execFileSync}=require('node:child_process');
function readContainer(file){
  const b=execFileSync('python3',['-c',`import sqlite3, sys
con = sqlite3.connect('file:'+sys.argv[1]+'?mode=ro', uri=True)
assert con.execute('PRAGMA application_id').fetchone()==(0x51415944,)
assert con.execute('PRAGMA user_version').fetchone()==(1,)
assert con.execute('PRAGMA integrity_check').fetchone()==('ok',)
parts=con.execute('SELECT part,payload FROM qayd_backup ORDER BY part').fetchall()
assert all(i==part and type(payload) is bytes and 1<=len(payload)<=65536 for i,(part,payload) in enumerate(parts))
sys.stdout.buffer.write(b''.join(x[1] for x in parts))
`,file],{maxBuffer:21*1024*1024});
  return JSON.parse(b.toString('utf8'));
}
function legacyDb(path,kind='standard'){
  execFileSync('python3',['-c',`import sqlite3, sys
cx=sqlite3.connect(sys.argv[1])
cx.executescript('''
PRAGMA user_version=4;
CREATE TABLE customers (ID INTEGER PRIMARY KEY, name TEXT, gsm TEXT, g_id INTEGER, f1 TEXT, online_ref2 TEXT);
CREATE TABLE groups (ID INTEGER PRIMARY KEY, name TEXT);
CREATE TABLE currency (ID INTEGER PRIMARY KEY, name TEXT);
CREATE TABLE doc_hdr (id INTEGER PRIMARY KEY, tr_id INTEGER, cus_id INTEGER, "in" TEXT, "out" TEXT);
CREATE TABLE transactions (ID INTEGER PRIMARY KEY, cus_id INTEGER, "in" TEXT, "out" TEXT, date_ TEXT, remarks TEXT, now_ TEXT, t_cus_id INTEGER, curr_id INTEGER, online_ref2 TEXT);
CREATE TABLE transactions_d AS SELECT * FROM transactions;
CREATE TABLE transactions_bk4 AS SELECT * FROM transactions;
CREATE TABLE customers_d AS SELECT * FROM customers;
CREATE TABLE valid (imei TEXT, imei_code TEXT);
INSERT INTO valid VALUES ('PRIVATE_TEST_IMEI','PRIVATE_TEST_KEY');
INSERT INTO groups VALUES (1,'تصنيف وهمي');
INSERT INTO currency VALUES (31,'ريال يمني'),(32,'ريال سعودي');
INSERT INTO customers VALUES (10,'مخزن اختباري','',1,'PRIVATE_TEST_ATTACHMENT','PRIVATE_TEST_SYNC'), (20,'حساب مقابل','',1,NULL,NULL);
INSERT INTO transactions VALUES
(1,10,'١٬٢٠٠٫٥٠٠', NULL, '١٣/٠٢/٢٠٢٦', 'قيد وهمي', '13:04:25', NULL,31, NULL),
(2,10,NULL,'50.25','02/03/2026','حركة بالمبلغ الثاني',NULL,0,31,NULL),
(3,10,NULL,'100','2026-04-06','تحويل متقابل','09:15:23',20,31,NULL),
(4,20,'100','0','2026-04-06','تحويل متقابل','09:15:23',10,31,NULL),
(5,10,NULL,'15.75','2026-04-11','تحويل من سجل واحد','14:01',20,31,NULL),
(6,20,'50.00',NULL,'2026-04-12 12:24 م','عينة عادية',NULL,0,32,NULL);
INSERT INTO transactions_d SELECT * FROM transactions;
INSERT INTO transactions_bk4 SELECT * FROM transactions;
INSERT INTO doc_hdr VALUES (6,6,20,'50.00',NULL);
INSERT INTO customers_d VALUES (900,'مخزن محذوف','',1,NULL,NULL);
''')
if sys.argv[2]=='signed':
    cx.executemany('INSERT INTO transactions VALUES (?,?,?,?,?,?,?,?,?,?)', [
        (7,10,None,'−١٢٫٣٤','2026-04-13','سالب في الخانة الثانية','09:10',0,31,None),
        (8,20,'-200.32',None,'2026-04-14','سالب في الخانة الأولى','09:10',0,31,None),
    ])
if sys.argv[2]=='signed-only':
    cx.execute('DELETE FROM transactions')
    cx.executemany('INSERT INTO transactions VALUES (?,?,?,?,?,?,?,?,?,?)', [
        (1,10,None,'-3.21','2026-04-13','سالب فقط','09:10',0,31,None),
        (2,20,'-0.09',None,'2026-04-14','سالب فقط','09:10',0,32,None),
    ])
if sys.argv[2]=='dual':
    cx.executemany('INSERT INTO transactions VALUES (?,?,?,?,?,?,?,?,?,?)', [
        (9010,20,'-١٥٠٫٢٥','٣٠٫٥١','2026-04-20','صف تجريبي بمبلغين','09:13:15',10,31,None),
        (9011,10,'5.00','5.00','2026-04-21','مبلغان يتساويان','09:17',0,32,None),
        (9012,10,'30.51',None,'2026-04-20','صف تجريبي بمبلغين','09:13:15',20,31,None),
    ])
if sys.argv[2] in ('flags','flags-unconfirmed'):
    cx.execute('DELETE FROM transactions')
    cx.execute('INSERT INTO customers VALUES (30,?,?,1,NULL,NULL)',('حساب تحقق وهمي',''))
    cx.executemany('INSERT INTO transactions VALUES (?,?,?,?,?,?,?,?,?,?)', [
        (300,10,'1','1234.512','13-02-2026','إضافة بثلاث منازل','2026-02-13',None,31,None),
        (301,20,'1','12.111','02-03-2026','رصيد سابق','2026-03-02',None,31,None),
        (302,10,'1','7.105','21-03-2026','طرف مثبت بالأرصدة','2026-03-21',20,31,None),
        (303,10,'-1','11.002','23-03-2026','خصم دقيق','2026-03-23',None,31,None),
        (304,30,'-1','3.005','27-03-2026','عملة ثانية','2026-03-27',None,32,None),
        (305,None,'-1','12.321','30-03-2026','صف بلا حساب','2026-03-30',None,31,None),
        (306,10,'1','0','01-04-2026','صفر — لا قيد','2026-04-01',None,31,None),
    ])
    if sys.argv[2]=='flags':
        cx.execute('CREATE TABLE cus_search_tmp(id INT,curr_id INT,balance,max_id INT,"cnt:1" INT)')
        cx.executemany('INSERT INTO cus_search_tmp VALUES (?,?,?,?,?)',[(10,31,1230.61500000001,306,4),(20,31,5.006,302,2),(30,32,-3.005,304,1)])
if sys.argv[2]=='bad-amount':
    cx.execute('UPDATE transactions SET "out"=? WHERE id=1',('50.5011',))
if sys.argv[2]=='bad-link':
    cx.execute('UPDATE transactions SET curr_id=777 WHERE id=1')
if sys.argv[2]=='wrong-version':
    cx.execute('PRAGMA user_version=777')
cx.commit();cx.close()
`,path,kind]);
}
module.exports={readContainer,legacyDb};
