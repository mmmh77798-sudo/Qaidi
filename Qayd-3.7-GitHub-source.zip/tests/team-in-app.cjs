'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),https=require('node:https'),readline=require('node:readline');
const {execFileSync,spawn}=require('node:child_process');const {once}=require('node:events');
const {pathToFileURL}=require('node:url'),{chromium}=require('playwright');
const {setTimeout:wait}=require('node:timers/promises');
const P=require('../shared/policy.cjs'),A=require('../shared/auth.cjs'),T=require('../shared/totp.cjs');
const {createDesk}=require('../shared/server.cjs'),{SQLiteStore}=require('../shared/store.cjs');
const {fixture}=require('./category-fixtures.cjs');
const url=pathToFileURL(path.resolve(__dirname,'../app/index.html')).href;
const ownerPass='Synthetic-Mobile-Team-Owner-111',staffPass='Synthetic-Mobile-Staff-Password';
const cls=process.env.QAYD_TEAM_CLASSES,jar=process.env.QAYD_TEAM_JSON_JAR;
const java=process.env.JAVA_HOME?path.join(process.env.JAVA_HOME,'bin','java'):'java';
const keytool=process.env.JAVA_HOME?path.join(process.env.JAVA_HOME,'bin','keytool'):'keytool';
const display='مسؤول الفريق التجريبي';
const dialog=p=>p.locator('#dialog'),head=(p,s)=>dialog(p).getByRole('heading',{name:s,exact:true}).waitFor();
const click=(p,a)=>p.locator(`[data-action=${a}]:visible`).first().click();
const save=p=>dialog(p).locator('button[type=submit]').click();
const dfield=(p,n)=>dialog(p).locator(`[name=${n}]`);
const cat=(p,c)=>dialog(p).locator(`.team-scope[data-team-category="${c}"]`),perm=(p,c,k)=>cat(p,c).locator(`[data-team-perm=${k}]`);
const stop=s=>s?new Promise(ok=>s.close(ok)):Promise.resolve();
function askServer(url,ca,route,body,cookie){return new Promise((ok,no)=>{
  const data=body===undefined?null:JSON.stringify(body);
  const req=https.request(url+'/api/'+route,{ca,method:data?'POST':'GET',headers:{...(cookie?{Cookie:cookie}:{}),...(data?{Origin:url,'Content-Type':'application/json','Content-Length':Buffer.byteLength(data),'X-Qayd-Client':'desk-v1'}:{})}},r=>{
    const parts=[];r.on('data',b=>parts.push(b));r.on('end',()=>{try{ok({status:r.statusCode,data:JSON.parse(Buffer.concat(parts)),cookie:r.headers['set-cookie']?.[0].split(';')[0]});}catch(e){no(e);}});
  });req.on('error',no);req.end(data);
});}
(async()=>{
  assert.ok(cls&&jar,'Set QAYD_TEAM_CLASSES and QAYD_TEAM_JSON_JAR for the checked-in JVM harness.');
  const temp=fs.mkdtempSync(path.join(os.tmpdir(),'qayd-team-inapp-')),errors=[],waiters=new Map(),requests=[],unexpected=[];
  let jvm,browser,server,store,legacy,redirected,demo;let seq=3000,teamOutage=true,holdLogin=null;
  try{
    const k=path.join(temp,'key.pem'),c=path.join(temp,'certificate.pem'),ts=path.join(temp,'team-trust.p12');
    execFileSync('openssl',['req','-x509','-newkey','rsa:2048','-nodes','-days','1','-subj','/CN=127.0.0.1','-addext','subjectAltName=IP:127.0.0.1','-keyout',k,'-out',c],{stdio:'ignore'});
    execFileSync(keytool,['-importcert','-noprompt','-storetype','PKCS12','-storepass','synthetic123','-alias','qa','-file',c,'-keystore',ts],{stdio:'ignore'});
    // Desktop OpenJDK restricts Origin unless enabled; Android's platform client permits it.
    jvm=spawn(java,['-Dsun.net.http.allowRestrictedHeaders=true','-Dfile.encoding=UTF-8',`-Djavax.net.ssl.trustStore=${ts}`,'-Djavax.net.ssl.trustStorePassword=synthetic123','-cp',`${cls}${path.delimiter}${jar}`,'app.qayd.ledger.TeamBridgeHarness','relay'],{stdio:['pipe','pipe','pipe']});
    const out=readline.createInterface({input:jvm.stdout});out.on('line',line=>{
      try{const r=JSON.parse(line),p=waiters.get(r.ticket);if(p){waiters.delete(r.ticket);clearTimeout(p.timer);p.ok(r);}else unexpected.push(r.ticket);}
      catch{errors.push('Unreadable JVM result');}
    });
    jvm.on('exit',()=>{for(const p of waiters.values()){clearTimeout(p.timer);p.no(new Error('JVM relay stopped'));}waiters.clear();});
    jvm.stderr.on('data',b=>errors.push(String(b)));
    const relay=command=>new Promise((ok,no)=>{const timer=setTimeout(()=>{waiters.delete(command.ticket);no(new Error('JVM test call timed out'));},66000);waiters.set(command.ticket,{ok,no,timer});jvm.stdin.write(JSON.stringify(command)+'\n');});
    const call=(origin,op,body={})=>relay({ticket:'team-'+(++seq),origin,op,json:JSON.stringify(body)});
    const clear=()=>relay({ticket:'clear-'+(++seq),clear:true});
    const tls={key:fs.readFileSync(k),cert:fs.readFileSync(c)};
    const start=async(router)=>{const s=https.createServer(tls);s.listen(0,'127.0.0.1');await once(s,'listening');const u=`https://127.0.0.1:${s.address().port}`;s.on('request',router(u));return {s,u};};
    const data=fixture(),initial=P.fresh(data);
    const owner=A.makeUser('owner','مالك الدفتر التجريبي',await A.hash(ownerPass),{owner:true});
    const mfa=T.begin(T.seed(),T.step(Date.now())-1);owner.mfa=mfa.mfa;initial.users.push(owner);
    store=new SQLiteStore(path.join(temp,'desk.sqlite'));store.init(initial);
    const edge=await start(address=>{
      const real=createDesk({store,origin:address,onError:e=>errors.push(e.message)}).listeners('request')[0];
      return (req,res)=>{
        requests.push(req.url);
        if(holdLogin&&req.url==='/api/login'){const ready=holdLogin;holdLogin=null;ready(()=>real(req,res));return;}
        if(teamOutage&&req.url==='/api/team'){teamOutage=false;res.writeHead(503,{'Content-Type':'application/json'});res.end(JSON.stringify({error:'تعذّر جلب الفريق مؤقتًا.'}));return;}
        real(req,res);
      };
    });server=edge.s;const remote=edge.u,ca=tls.cert;
    let redirectedRequests=0;const redirect=await start(()=> (req,res)=>{redirectedRequests++;res.writeHead(302,{Location:remote+'/api/info'});res.end();});redirected=redirect.s;
    const invalid=await call(redirect.u,'login',{login:'owner',password:ownerPass});assert.equal(invalid.value.code,'redirect');assert.equal(redirectedRequests,1);assert.deepEqual(requests,[]);
    assert.equal((await call('http://127.0.0.1:1111','login',{login:'owner',password:ownerPass})).value.code,'origin');
    assert.equal((await call(redirect.u,'book/backup')).value.code,'request');
    assert.equal((await call(remote.replace('127.0.0.1','localhost'),'login',{login:'owner',password:ownerPass})).value.code,'tls');
    assert.deepEqual(requests,[]);
    const demoPaths=[],demoEdge=await start(host=>{
      const run=createDesk({demo:true,origin:host,onError:e=>errors.push(e.message)}).listeners('request')[0];
      return (req,res)=>{demoPaths.push(req.url);run(req,res);};
    });demo=demoEdge.s;
    assert.equal((await call(demoEdge.u,'login',{login:'owner',password:ownerPass})).value.code,'demo');assert.deepEqual(demoPaths,['/api/info']);
    browser=await chromium.launch();
    const p=await browser.newPage({viewport:{width:393,height:851},isMobile:true,hasTouch:true});p.setDefaultTimeout(14000);await p.context().setOffline(true);
    p.on('pageerror',e=>errors.push(e.message));const net=[];p.on('request',r=>{if(/^https?:/.test(r.url()))net.push(r.url());});
    await p.exposeFunction('nativeTeamCall',(ticket,origin,op,json)=>relay({ticket,origin,op,json}).then(r=>({status:r.status,value:Buffer.from(JSON.stringify(r.value)).toString('base64')})));
    await p.exposeFunction('nativeTeamClear',()=>clear());
    await p.addInitScript(raw=>{
      window.qa={opened:[],writes:[],copy:[],secrets:[]};window.open=(...a)=>qa.opened.push(a);
      window.QaydAndroid={readLedger:()=>raw,writeLedger:(...a)=>{qa.writes.push(a);return true;},
        teamRequest:(ticket,o,op,json)=>void nativeTeamCall(ticket,o,op,json).then(r=>qaydTeamReply(ticket,r.status,r.value)),teamClear:()=>void nativeTeamClear(),
        copyText:x=>qa.copy.push(x),teamCopyTemporary:x=>qa.secrets.push(x)};
    },JSON.stringify({...data,settings:{...data.settings,business:'LOCAL-ONLY-LEDGER-FOR-TEST'}}));
    const enter=async()=>{await p.locator('[data-action=go][data-view=settings]:visible').first().click();await p.locator('[data-action=settings-open][data-key=shared]').click();};
    await p.goto(url);await enter();await p.locator('#team-origin-form [name=origin]').fill(remote);await p.locator('#team-origin-form [type=submit]').click();
    const login=p.locator('#team-login-form'),loginError=p.locator('#team-login-error');
    const challenge=async()=>{
      await login.locator('[name=login]').fill('owner');await login.locator('[name=password]').fill(ownerPass);await login.locator('[type=submit]').click();
      try{await p.locator('#team-otp').waitFor({timeout:5500});}catch{throw new Error(`Owner challenge missing. Form: ${await loginError.textContent()} · API: ${requests.join(',')} · UI: ${errors.join(';')}`);}
    };
    const signWith=async code=>{await login.locator('[name=otp]').fill(code);await login.locator('[type=submit]').click();};
    await challenge();assert.equal(await p.locator('[data-action=team-create]').count(),0);
    await signWith('invalid');try{await p.getByText(/رمز التحقق غير صالح/).waitFor({timeout:4000});}catch{throw new Error(`Invalid factor result: ${await loginError.textContent()} · API ${requests.join(',')} · ${errors.join(';')}`);}
    await signWith(T.code(mfa.mfa.secret,T.step(Date.now())));
    await p.getByRole('button',{name:'جلب قائمة الفريق'}).waitFor();assert.equal(await login.count(),0);
    assert.equal(await p.locator('[data-action=team-create]').count(),0);
    await click(p,'team-refresh');await p.locator('[data-action=team-create]').waitFor();
    assert.equal(await p.locator('[data-action=team-refresh]').count(),1);
    const previousCount=requests.length;
    const malformed=await call(remote,'create',{name:'Test',login:'test',grants:[{category:'clients',allow:['view'],localData:'LOCAL-ONLY-LEDGER-FOR-TEST'}]});
    assert.equal(malformed.value.code,'request');assert.equal(requests.length,previousCount);
    await click(p,'team-create');await head(p,'فتح مستخدم فرعي');
    await dfield(p,'name').fill(display);await dfield(p,'login').fill('sales.test');
    assert.equal(await perm(p,'suppliers','view').isChecked(),false);assert.equal(await perm(p,'clients','addMovement').isDisabled(),true);
    await perm(p,'clients','view').check();await perm(p,'clients','addMovement').check();
    assert.equal(await perm(p,'clients','exportCsv').isDisabled(),true);
    await perm(p,'clients','reports').check();await perm(p,'clients','exportCsv').check();await perm(p,'clients','reports').uncheck();
    assert.equal(await perm(p,'clients','exportCsv').isChecked(),false);
    for(const width of [280,320,393,640,980,1250]){
      await p.setViewportSize({width,height:850});assert.ok(await p.evaluate(()=>document.documentElement.scrollWidth<=document.documentElement.clientWidth+1),`page fit at ${width}`);
      assert.ok(await dialog(p).evaluate(e=>e.scrollWidth<=e.clientWidth+1),`permissions fit at ${width}`);
    }
    await p.setViewportSize({width:393,height:851});
    if(process.env.QAYD_TEAM_SHOT)await p.screenshot({path:process.env.QAYD_TEAM_SHOT,fullPage:true});
    await save(p);await head(p,'بيانات دخول المستخدم');
    const tempPass=await dfield(p,'team-pass').inputValue();assert.equal(tempPass.length,24);
    assert.equal(await dfield(p,'team-link').inputValue(),remote+'/');assert.equal(await dfield(p,'team-login').inputValue(),'sales.test');
    await p.locator('[data-action=team-copy-invite][data-key=team-link]').click();
    await p.locator('[data-action=team-copy-invite][data-key=team-pass]').click();
    assert.deepEqual(await p.evaluate(()=>qa.copy),[remote+'/']);assert.deepEqual(await p.evaluate(()=>qa.secrets),[tempPass]);
    await click(p,'close-dialog');await dialog(p).waitFor({state:'hidden'});
    const list=p.locator('.team-list');assert.match(await list.innerText(),new RegExp(display));assert.ok(!(await list.innerText()).includes(tempPass));
    const first=await askServer(remote,ca,'login',{login:'sales.test',password:tempPass});assert.equal(first.status,200);assert.equal(first.data.me.mustChange,true);
    assert.equal((await askServer(remote,ca,'desk',undefined,first.cookie)).status,403);
    const changed=await askServer(remote,ca,'password',{current:tempPass,password:staffPass},first.cookie);assert.equal(changed.status,200);
    const before=await askServer(remote,ca,'desk',undefined,changed.cookie);
    assert.deepEqual(before.data.categories.map(x=>x.id),['clients']);assert.deepEqual(before.data.categories[0].allow,['view','addMovement']);
    assert.equal((await askServer(remote,ca,'team',undefined,changed.cookie)).status,403);
    // A stale write must not overwrite a simultaneous edit from another owner session.
    await click(p,'team-edit');await head(p,'صلاحيات المستخدم الفرعي');
    const prior=store.load(),priorUser=prior.s.users.find(x=>x.login==='sales.test');
    const renamed={...A.bump(priorUser),name:'مسؤول الفريق بعد المراجعة'};
    store.commit(prior,{...prior.s,users:prior.s.users.map(x=>x.id===renamed.id?renamed:x)});
    await dfield(p,'name').fill('اسم من نافذة قديمة');await save(p);await dialog(p).getByText(/تغيّرت بيانات المستخدم/).waitFor();
    assert.equal(store.load().s.users.find(x=>x.id===renamed.id).name,renamed.name);
    await click(p,'close-dialog');await click(p,'team-refresh');await p.getByText(renamed.name,{exact:true}).waitFor();
    // Member-only read, then scope modifications affect the staff's same authenticated session.
    await click(p,'team-edit');await head(p,'صلاحيات المستخدم الفرعي');
    assert.equal(await perm(p,'clients','addMovement').isChecked(),true);
    await perm(p,'clients','view').uncheck();await perm(p,'suppliers','view').check();await perm(p,'suppliers','reports').check();await save(p);
    await dialog(p).waitFor({state:'hidden'});
    const after=await askServer(remote,ca,'desk',undefined,changed.cookie);
    assert.deepEqual(after.data.categories.map(x=>x.id),['suppliers']);assert.deepEqual(after.data.categories[0].allow,['view','reports']);
    await click(p,'team-actions');await click(p,'team-toggle');await head(p,'إيقاف المستخدم');await save(p);
    await list.getByText('موقوف',{exact:true}).waitFor();assert.equal((await askServer(remote,ca,'desk',undefined,changed.cookie)).status,401);
    if(process.env.QAYD_TEAM_READY_SHOT)await p.screenshot({path:process.env.QAYD_TEAM_READY_SHOT,fullPage:true});
    await click(p,'team-actions');await click(p,'team-toggle');await head(p,'تفعيل المستخدم');await save(p);
    await list.getByText('نشط',{exact:true}).waitFor();
    const staffLogin=()=>askServer(remote,ca,'login',{login:'sales.test',password:staffPass});
    const revived=await staffLogin();assert.equal(revived.status,200);
    await click(p,'team-actions');await click(p,'team-revoke');await head(p,'إنهاء الجلسات');await save(p);await dialog(p).waitFor({state:'hidden'});
    assert.equal((await askServer(remote,ca,'desk',undefined,revived.cookie)).status,401);
    const newSession=await staffLogin();assert.equal(newSession.status,200);
    await click(p,'team-actions');await click(p,'team-reset');await head(p,'تعيين كلمة سر مؤقتة');await save(p);await head(p,'بيانات دخول المستخدم');
    const refreshedPassword=await dfield(p,'team-pass').inputValue();assert.equal(refreshedPassword.length,24);assert.notEqual(refreshedPassword,tempPass);
    assert.equal((await askServer(remote,ca,'desk',undefined,newSession.cookie)).status,401);assert.equal((await staffLogin()).status,401);
    const renewal=await askServer(remote,ca,'login',{login:'sales.test',password:refreshedPassword});assert.equal(renewal.status,200);assert.equal(renewal.data.me.mustChange,true);
    assert.equal((await askServer(remote,ca,'desk',undefined,renewal.cookie)).status,403);
    // The in-app session cannot be attached to a different saved address.
    assert.equal((await call(redirect.u,'team')).value.code,'login');assert.equal(redirectedRequests,1);
    // The stop hook closes the transient credential dialog and drops the owner session, retaining only the address.
    await p.evaluate(()=>window.qaydTeamSuspended());await login.waitFor();await clear();
    assert.equal((await call(remote,'team')).value.code,'login');assert.equal(await p.locator('[data-team-person]').count(),0);
    assert.equal(await dfield(p,'team-pass').count(),0);assert.equal(await login.locator('[name=password]').inputValue(),'');
    const wrongAccount=await call(remote,'login',{login:'sales.test',password:refreshedPassword});assert.equal(wrongAccount.value.code,'owner');
    assert.equal((await call(remote,'team')).value.code,'login');
    await challenge();await signWith(mfa.codes[0]);await p.locator('[data-action=team-create]').waitFor();
    const ownerBefore=store.load();
    store.commit(ownerBefore,{...ownerBefore.s,users:ownerBefore.s.users.map(x=>x.owner?A.bump(x,true):x)});
    await click(p,'team-refresh');await login.waitFor();assert.equal(await p.locator('[data-team-person]').count(),0);
    assert.match(await p.locator('#toast').innerText(),/انتهت جلسة الفريق/);
    await challenge();await signWith(mfa.codes[2]);await p.locator('[data-action=team-create]').waitFor();
    await p.evaluate(()=>window.qaydBack());await enter();await login.waitFor();
    assert.equal((await call(remote,'team')).value.code,'login');
    // Clearing while login is in flight must prevent the resulting cookie from being attached.
    const blocked=new Promise(resolve=>{holdLogin=resolve;});
    const cancelled='team-'+(++seq);
    jvm.stdin.write(JSON.stringify({ticket:cancelled,origin:remote,op:'login',json:JSON.stringify({login:'owner',password:ownerPass,otp:mfa.codes[3]})})+'\n');
    const release=await Promise.race([blocked,wait(3500).then(()=>{throw new Error('Missing in-flight QA login');})]);
    assert.equal((await call(remote,'team')).value.code,'busy');await clear();release();
    let noSession;for(let i=0;i<30;i++){noSession=await call(remote,'team');if(noSession.value.code!=='busy')break;await wait(40);}
    assert.equal(noSession.value.code,'login');assert.deepEqual(unexpected,[]);
    assert.equal(JSON.stringify(store.load().s.ledger),JSON.stringify(initial.ledger));
    assert.deepEqual(await p.evaluate(()=>[qa.opened,qa.writes]),[[],[]]);
    assert.deepEqual(await p.evaluate(()=>Object.entries(localStorage)),[['qayd.shared.origin.v1',remote]]);
    assert.deepEqual(net,[]);assert.equal(p.url(),url);
    assert.ok(!requests.includes('/api/desk?code=YER')&&!requests.some(x=>x.includes('/api/book/')));
    // Optional old release check uses genuine 3.0 server distribution, not a compatibility stub.
    const priorZip=process.env.QAYD_TEAM_PRIOR_SOURCE;
    if(priorZip){
      const dir=path.join(temp,'previous');fs.mkdirSync(dir);execFileSync('unzip',['-q',priorZip,'-d',dir]);
      const old=require(path.join(dir,'qayd/shared/server.cjs'));
      const oldEdge=await start(host=>old.createDesk({store,origin:host,onError:e=>errors.push(e.message)}).listeners('request')[0]);legacy=oldEdge.s;
      const a=await call(oldEdge.u,'login',{login:'owner',password:ownerPass,otp:mfa.codes[1]});assert.equal(a.status,200,JSON.stringify(a.value));
      const oldTeam=await call(oldEdge.u,'team');assert.equal(oldTeam.status,200,JSON.stringify(oldTeam.value));
      assert.equal(oldTeam.value.users.length,1);assert.equal(oldTeam.value.accounts,undefined);assert.equal(oldTeam.value.ledger,undefined);
      assert.equal((await call(oldEdge.u,'member',{id:oldTeam.value.users[0].id})).value.user.grants[0].category,'suppliers');
      const newOnOld=await call(oldEdge.u,'create',{name:'موظف متوافق',login:'old.release',grants:[{category:'clients',allow:['view']}]});
      assert.equal(newOnOld.status,201);assert.equal(newOnOld.value.temporary.length,24);
      assert.deepEqual((await call(oldEdge.u,'member',{id:newOnOld.value.user.id})).value.user.grants,[{category:'clients',allow:['view']}]);
      assert.equal((await call(oldEdge.u,'logout')).status,200);
    }
    assert.deepEqual(errors,[]);
    console.log('RTL in-app controls + native Java HTTPS: TLS, demo and shape checks, owner TOTP/recovery, failed refresh and stale edit recovery, create/edit by scope, temporary activation, suspend/re-enable/reset/revoke, reauth and in-flight session clearing, no browser, local writes or ledger upload'+(priorZip?', genuine 3.0 fallback/read/create.':'.'));
  }finally{
    await browser?.close();if(jvm&&jvm.exitCode===null){const finish=once(jvm,'exit');jvm.stdin.end();await finish;}
    await stop(legacy);await stop(redirected);await stop(demo);await stop(server);store?.close();fs.rmSync(temp,{recursive:true,force:true});
  }
})().catch(e=>{console.error(e);process.exitCode=1;});
