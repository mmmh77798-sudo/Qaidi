const {test}=require('node:test');
const a=require('node:assert/strict');
const L=require('../app/ledger.js');
const F=require('../app/account-features.js');
const strip=t=>t.replace(/[\u2066-\u2069]/g,'');

test('short drafts keep currency, signed thousandths and date without movement details',()=>{
  const p={day:'2025-05-12',minor:-350125,currency:'محلي',amount:'\u061c-350.125'};
  const sms=F.shortMessage(p);
  a.equal(strip(sms),'رصيدك حتى 2025-05-12: -350.125 محلي (لك).');
  a.ok(sms.length<=70);a.ok(!sms.includes('\n'));
  a.match(strip(F.shortMessage({...p,confirmation:true})),/تأكيد.*-350\.125 محلي.*ردّ بـ «موافق»/);
  a.match(strip(F.shortMessage({...p,minor:0,amount:'0'})),/0 محلي \(متوازن\)/);
});

test('advanced statement filters distinguish signed postings, transfer side and carried rows',()=>{
  const row=(minor,kind=1,closed=false)=>({minor,legs:Array.from({length:kind},()=>({minor})),closed});
  const f=F.blank();
  a.equal(F.hasFilters(f),false);
  a.equal(F.includesRow(row(-35125),{...f,kind:'debit',min:35125,max:35125}),true);
  a.equal(F.includesRow(row(-35126),{...f,kind:'debit',min:35125,max:35125}),false);
  a.equal(F.includesRow(row(-35125,2),{...f,kind:'debit'}),false);
  a.equal(F.includesRow(row(-35125,2),{...f,kind:'transfer'}),true);
  a.equal(F.includesRow(row(0,0,true),{...f,kind:'carried',min:0,max:0}),true);
  a.equal(F.hasFilters({...f,max:0}),true);
});

test('per-currency ceilings warn by direction, survive validation and account edits without touching postings',()=>{
  const d=L.empty();const x=L.addAccount(d,{name:'حساب اختبار سقف'});
  L.saveEntry(d,{account:x.id,code:'YER',kind:'debit',day:'2025-06-04',amount:'25.125'});
  const entries=L.stateClone(d.entries);
  L.setAccountLimit(d,x.id,'YER',{minor:25125,direction:'debit'});
  L.setAccountLimit(d,x.id,'SAR',{minor:3001,direction:'both'});
  const verified=L.validate(d);
  a.deepEqual(verified.accounts[0].limits,{YER:{minor:25125,direction:'debit'},SAR:{minor:3001,direction:'both'}});
  a.deepEqual(verified.entries,entries);
  const current=L.addAccount(verified,{id:x.id,name:'اختبار سقف بعد التعديل'});
  a.equal(L.limitStatus(current,'YER',-25125).reached,true);
  a.equal(L.limitStatus(current,'YER',-25125).exceeded,false);
  a.equal(L.limitStatus(current,'YER',25126).used,0);
  a.equal(L.limitStatus(current,'SAR',-4000).exceeded,true);
  a.equal(L.limitStatus(current,'USD',-5000000),null);
  a.throws(()=>L.setAccountLimit(verified,x.id,'SAR',{minor:0,direction:'credit'}),/السقف|سقف/);
  a.throws(()=>L.setAccountLimit(verified,x.id,'ZZ',{minor:1000,direction:'credit'}),/العملة/);
  const malformed=L.stateClone(verified);malformed.accounts[0].limits.YER.minor=-1;
  a.throws(()=>L.validate(malformed),/سقف/);
  L.setAccountLimit(verified,x.id,'YER');
  a.equal(L.limitStatus(current,'YER',-50000),null);
  a.deepEqual(L.validate(verified).accounts[0].limits,{SAR:{minor:3001,direction:'both'}});
});
