const {test}=require('node:test');
const assert=require('node:assert/strict');
const L=require('../app/ledger.js');
const C=require('../app/collections-model.js');
const asOf='2026-11-18';
const day=n=>L.offset(n,asOf);
function fixture(){
  const d=L.empty();
  d.accounts=['A','B','C'].map(id=>({id,name:'حساب '+id,phone:'',color:'mint'}));
  return d;
}
function post(d,account,amount,n,{due,code='YER',time='12:30'}={}){
  return L.saveEntry(d,{account,kind:amount<0?'debit':'credit',day:day(n),time,amount:String(Math.abs(amount)),due:due===undefined?undefined:day(due),code});
}
const bands=['d30','d60','d90','d91'];
const moneyKeys=['overdue','today','week','later','unscheduled'];

test('oldest charges absorb same-currency payments, including advances; archived records and exact remainders count',()=>{
  const d=fixture();
  const b=post(d,'A',200.25,-170,{due:-61}),old=post(d,'A',100.125,-200,{due:-91});
  const other=post(d,'A',50.125,-2);
  post(d,'A',-150.125,-220);
  post(d,'A',800,+1,{due:8}); // after cutoff, even with a later due date
  post(d,'A',-700,-1,{code:'SAR'});
  post(d,'B',-300,-5);post(d,'B',200,-4,{due:-3}); // credit balance, not a receivable
  L.closeBalance(d,'A','YER',day(-160));
  const checked=L.validate(d),before=JSON.stringify(checked);
  const snap=C.snapshot(checked,'YER',asOf),a=snap.index.get('A');
  assert.equal(snap.rows.length,1);assert.equal(a.total,200375);
  assert.deepEqual(a.items.map(x=>[x.id,x.open,x.due]),[[b.id,150250,day(-61)],[other.id,50125,'']]);
  assert.ok(!a.items.some(x=>x.id===old.id));
  assert.equal(a.firstDue,day(-61));assert.equal(a.oldestDays,61);assert.equal(a.d90,150250);assert.equal(a.d91,0);
  assert.equal(a.unscheduled,50125);assert.equal(a.overdue,150250);
  assert.equal(a.total,L.statement(checked,'A','YER',{to:asOf,archive:true}).ending);
  assert.equal(JSON.stringify(checked),before);
  assert.equal(C.snapshot(checked,'SAR',asOf).rows.length,0);
  assert.equal(C.snapshot(checked,'YER',day(-161)).index.get('A').total,150250);
});

test('all maturity and overdue-band cutoffs are inclusive and unknown dates never become overdue',()=>{
  const d=fixture();
  for(const due of [-91,-90,-61,-60,-31,-30,-1,0,1,7,8,undefined])post(d,'A',10,-150,{due});
  const a=C.snapshot(L.validate(d),'YER',asOf).index.get('A');
  assert.deepEqual(bands.map(k=>a[k]),[20000,20000,20000,10000]);
  assert.deepEqual(moneyKeys.map(k=>a[k]),[70000,10000,20000,10000,10000]);
  assert.equal(a.total,120000);assert.equal(C.duration('2024-02-28','2024-03-01'),2);
  assert.equal(C.duration('2026-03-08','2026-03-09'),1);
  assert.equal(C.matches(a,'unscheduled',asOf),true);
  assert.equal(C.matches(a,'followup',asOf),false);
});

test('transfers contribute only the proper leg, follow-up is not a promise recorded as payment',()=>{
  const d=fixture();post(d,'A',125.125,-7,{due:-2});
  L.saveEntry(d,{kind:'transfer',from:'A',to:'B',code:'YER',day:day(-2),amount:'50.001',due:asOf});
  post(d,'A',2000,-7,{due:-4,code:'SAR'});
  L.setFollowup(d,'A','YER',{kind:'promise',day:asOf,at:1700000000000,note:'وعد تجريبي'});
  L.setFollowup(d,'A','SAR',{kind:'contacted',day:day(2),at:1700000000001,note:''});
  const a=C.snapshot(L.validate(d),'YER',asOf),s=C.summary(a.rows);
  assert.equal(a.index.get('A').overdue,75124);assert.equal(a.index.get('B').today,50001);assert.equal(s.total,125125);
  assert.equal(C.followupDue(a.index.get('A'),asOf),true);
  assert.equal(C.followupDue(C.snapshot(d,'SAR',asOf).index.get('A'),asOf),false);
  const before=L.stateClone(d.entries);
  L.setFollowup(d,'A','YER');assert.equal(d.accounts[0].followups.YER,undefined);assert.deepEqual(d.entries,before);
});

test('checked optional metadata survives renames and backups, but never changes saved amounts',()=>{
  const d=fixture(),e=post(d,'A',11,-4),negative=post(d,'A',-5,-3);
  assert.throws(()=>L.setDueDate(d,e.id,day(-5)),/استحقاق/);
  assert.throws(()=>L.setDueDate(d,negative.id,asOf),/الحركة الموجبة|للحركة الموجبة/);
  assert.equal(L.setDueDate(d,e.id,asOf),true);assert.equal(L.setDueDate(d,e.id,asOf),false);
  L.setFollowup(d,'A','YER',{kind:'review',day:asOf,at:1700000000000,note:'مراجعة'});
  L.addAccount(d,{id:'A',name:'اسم بعد التعديل'});
  L.recordActivity(d,{type:'due',subject:'اسم بعد التعديل',detail:asOf,at:1700000000000});
  const copy=L.validate(L.stateClone(d));
  assert.equal(copy.entries[0].due,asOf);
  assert.equal(copy.accounts[0].followups.YER.note,'مراجعة');assert.equal(copy.activity.length,1);
  assert.equal(L.statement(copy,'A','YER',{to:asOf}).ending,6000);
  const invalid=L.stateClone(copy);invalid.entries[1].due=asOf;assert.throws(()=>L.validate(invalid),/استحقاق/);
  invalid.entries[1]={...negative};invalid.accounts[0].followups.BAD=invalid.accounts[0].followups.YER;
  assert.throws(()=>L.validate(invalid),/عملة/);
  L.saveEntry(copy,{id:e.id,account:'A',kind:'debit',day:e.day,amount:'11',code:'YER'});
  assert.equal(copy.entries[0].due,undefined);
  for(let i=0;i<L.ACTIVITY_MAX+5;i++)L.recordActivity(d,{type:'entry-edit',subject:'اختبار',detail:String(i),at:1700000000000+i});
  const capped=L.validate(d).activity;assert.equal(capped.length,L.ACTIVITY_MAX);assert.equal(capped[0].detail,'5');
  assert.throws(()=>L.recordActivity(d,{type:'guess',subject:'اختبار'}),/حدث/);
});

test('randomized reconciliation: positive dated balances partition exactly per account, day and currency',()=>{
  const d=fixture();let value=137;
  const rand=n=>{value=(Math.imul(value,1664525)+1013904223)>>>0;return value%n;};
  for(let i=0;i<840;i++){
    const a=d.accounts[rand(3)],code=['YER','SAR','USD'][rand(3)],n=rand(180)-150,gain=rand(7)<4;
    const amount=(rand(5000000)+1)*(gain?1:-1);
    L.saveEntry(d,{account:a.id,code,kind:gain?'credit':'debit',amount:L.decimal(Math.abs(amount)),day:day(n),due:gain&&rand(3)?day(n+rand(110)):undefined});
  }
  const verified=L.validate(d);
  for(const code of ['YER','SAR','USD'])for(const end of [-100,-40,0,29]){
    const cut=day(end),v=C.snapshot(verified,code,cut);
    for(const a of verified.accounts){
      const r=v.index.get(a.id),book=L.statement(d,a.id,code,{to:cut,archive:true}).ending;
      assert.equal(r?.total||0,Math.max(0,book));if(!r)continue;
      assert.equal(moneyKeys.reduce((sum,key)=>sum+r[key],0),r.total);
      assert.equal(bands.reduce((sum,key)=>sum+r[key],0),r.overdue);
      assert.equal(r.items.reduce((sum,x)=>sum+x.open,0),r.total);
    }
  }
});
