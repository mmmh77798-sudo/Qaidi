const test=require('node:test'),assert=require('node:assert/strict');
const L=require('../app/ledger.js'), M=require('../app/legacy.js');
const source=(transactions=[])=>({accounts:[['1','أحمد',null,'7'],['2','احمد',null,'7']],categories:[['7','تصنيف اختبار']],currencies:[['4','ريال يمني']],transactions});
const r=(id,a,n,m,date='2026-08-17',other=null,note='')=>[String(id),String(a),n,m,date,note,'19:13:44',other===null?null:String(other),'4'];
test('legacy amounts are exact signed minor units, including exponent and Arabic decimals',()=>{
  for(const [text,minor] of [
    ['١٬٢٣٤٫٥٠٠',1234500],['1.23E7',12300000000],['505E-2',5050],['+50,59',50590],
    ['-35.00',-35000],['\u061c−١٬٢٣٤٫٥٠٠',-1234500],['-505E-2',-5050],['-4,07',-4070],
    ['-0.000',0],['-999999999999.999',-L.MAX]
  ])assert.equal(M.amount(text),minor,text);
});
test('legacy refuses over-precision, malformed and invalid date data instead of guessing',()=>{
  for(const x of ['0.0001','-0.0001','-12.0e-4','bogus','--1','1234567891234','-1000000000000','١ ه'])assert.throws(()=>M.amount(x),/./);
  assert.throws(()=>M.prepare(source([r(107,1,'-3','0.0001')])),/أكثر من ثلاث منازل.*حركة 107/);
  assert.throws(()=>M.prepare(source([r(7,1,'-3','2'),r(7,2,'3','2')])),/المعرّف نفسه/);
  for(const day of ['2026-02-30','١٤٤٧/٠٢/١٣ هـ','not a date',''])assert.throws(()=>M.date(day),/تاريخ/);
  assert.equal(M.date('١٣/٠٢/٢٠٢٦ ٦:٠٧ م').time,'18:07');
  assert.equal(M.date('02/03/2026').dm,'2026-03-02');assert.equal(M.date('02/03/2026').md,'2026-02-03');
});
test('duplicate names are not merged; inverse columns preserve the explicit direction',()=>{
  const p=M.prepare(source([r(3,1,'500',null),r(4,2,null,'63.20')]));
  const mapped=M.convert(p,{inSign:-1});
  assert.equal(p.stats.accountsRenamed,1);assert.equal(mapped.checked.accounts.length,2);
  const bal=L.balances(mapped.checked,'YER');assert.equal(bal.get('old-a-1').minor,-500000);assert.equal(bal.get('old-a-2').minor,63200);
});
test('possible reciprocal rows with differing notes are never duplicated as extra postings',()=>{
  const p=M.prepare(source([r(1,1,null,'10','2026-08-17',2,'منه'),r(2,2,'10',null,'2026-08-17',1,'إليه')]));
  assert.equal(p.transferExample,null);
  const out=M.convert(p,{transfers:'complete'});
  assert.equal(out.uncertain,2);assert.equal(out.added,0);assert.equal(out.checked.entries.length,2);
});
test('negative amounts in either column keep their sign while positive magnitudes follow the selected direction',()=>{
  const p=M.prepare(source([r(1,1,'-35.01',null),r(2,2,null,'-6.02'),r(3,1,'10.50',null),r(4,2,null,'12.33')]));
  assert.equal(p.stats.negative,2);assert.ok(p.sideExample.amount>0);
  for(const inSign of [1,-1]){
    const {checked,comparisons}=M.convert(p,{inSign});
    assert.deepEqual(checked.entries.map(e=>e.legs[0].minor),[-35010,-6020,10500*inSign,-12330*inSign]);
    const a=-35010+10500*inSign,b=-6020-12330*inSign;
    assert.equal(L.statement(checked,'old-a-1','YER').ending,a);
    assert.equal(L.statement(checked,'old-a-2','YER').ending,b);
    assert.equal(comparisons.find(c=>c.key==='old-a-1|YER').minor,a);
    assert.equal(comparisons.find(c=>c.key==='old-a-2|YER').minor,b);
  }
});
test('pairing uses both real signed legs and is rechecked when the direction changes',()=>{
  const p=M.prepare(source([r(1,1,'-10.21',null,'2026-08-17',2),r(2,2,null,'10.21','2026-08-17',1)]));
  assert.equal(p.transferExample,null);
  const same=M.convert(p,{inSign:1,transfers:'complete'});
  assert.equal(same.paired,0);assert.equal(same.uncertain,2);assert.equal(same.added,0);
  assert.deepEqual(same.checked.entries.map(e=>e.legs[0].minor),[-10210,-10210]);
  const opposite=M.convert(p,{inSign:-1,transfers:'complete'});
  assert.equal(opposite.paired,1);assert.equal(opposite.uncertain,0);assert.equal(opposite.added,0);
  assert.equal(opposite.checked.entries.length,1);
  assert.deepEqual(opposite.checked.entries[0].legs,[{account:'old-a-1',code:'YER',minor:-10210},{account:'old-a-2',code:'YER',minor:10210}]);
  assert.deepEqual(M.convert(p,{inSign:1,transfers:'complete'}),same,'reviewing another direction must not mutate the draft');
});
test('negative reciprocal and orphan rows never gain a fabricated counterpart',()=>{
  const p=M.prepare(source([r(1,1,'-7.25',null,'2026-08-17',2),r(2,2,null,'-7.25','2026-08-17',1),r(3,2,null,'-8.15','2026-08-18',1)]));
  assert.equal(p.transferExample,null);assert.equal(p.sideExample,null);assert.equal(p.negativeExample.amount,-7250);
  for(const inSign of [1,-1]){
    const result=M.convert(p,{inSign,transfers:'complete'});
    assert.equal(result.paired,0);assert.equal(result.uncertain,3);assert.equal(result.added,0);
    assert.deepEqual(result.checked.entries.map(e=>e.legs.map(l=>l.minor)),[[-7250],[-7250],[-8150]]);
    assert.ok(result.comparisons.every(c=>!c.affected));
  }
});
test('an ambiguous reciprocal amount or a signed reciprocal context blocks inferred completion',()=>{
  for(const [date,otherAmount] of [['2026-08-18','-5'],['2026-08-17','-4.99']]){
    const p=M.prepare(source([r(1,1,'5',null,'2026-08-17',2),r(2,2,'0',otherAmount,date,1)]));
    assert.equal(p.transferExample,null);
    const out=M.convert(p,{transfers:'complete'});
    assert.equal(out.uncertain,2);assert.equal(out.paired,0);assert.equal(out.added,0);
    assert.deepEqual(out.checked.entries.map(e=>e.legs.map(l=>l.minor)),[[5000],[M.amount(otherAmount)]]);
  }
});
test('two populated columns keep both amounts and metadata under either mapping, even when they cancel',()=>{
  const data=source([
    r(1,1,'100.50','20.25','02/03/2026',null,'صف بمبلغين'),
    r(2,1,'-35.01','10.11'),
    r(3,2,'15.25','-4.56'),
    r(-4,2,'-0.01','-0.02'),
    r(5,1,'3.15','3.15'),
    r(6,2,'-0.000','2.00')
  ]), before=JSON.stringify(data), p=M.prepare(data);
  assert.equal(p.stats.dual,5);assert.equal(p.stats.negative,4);
  assert.equal(p.sideExample.id,'6','positive single-column example is preferred');
  for(const inSign of [1,-1]){
    const res=M.convert(p,{inSign,dates:'md',transfers:'complete'}), {entries}=res.checked;
    assert.deepEqual(entries.map(e=>[e.id,e.legs[0].minor]),[
      ['old-t-1-in',100500*inSign],['old-t-1-out',-20250*inSign],
      ['old-t-2-in',-35010],['old-t-2-out',-10110*inSign],
      ['old-t-3-in',15250*inSign],['old-t-3-out',-4560],
      ['old-t--4-in',-10],['old-t--4-out',-20],
      ['old-t-5-in',3150*inSign],['old-t-5-out',-3150*inSign],['old-t-6',-2000*inSign]
    ]);
    for(const e of entries.slice(0,2)){
      assert.equal(e.day,'2026-02-03');assert.equal(e.time,'19:13');assert.equal(e.memo,'صف بمبلغين');
      assert.deepEqual(e.legs.map(l=>[l.account,l.code]),[['old-a-1','YER']]);
    }
    assert.ok(entries.every(e=>e.legs.length===1));
    const account1=70140*inSign-35010, account2=13250*inSign-4590;
    assert.equal(L.statement(res.checked,'old-a-1','YER').ending,account1);
    assert.equal(L.statement(res.checked,'old-a-2','YER').ending,account2);
    const c=res.comparisons.find(c=>c.key==='old-a-1|YER');
    assert.equal(c.minor,account1);
    assert.deepEqual(c.dual,{id:'1',day:'2026-02-03',inn:100500,out:20250,inMinor:100500*inSign,outMinor:-20250*inSign});
    assert.equal(res.added,0);assert.equal(res.paired,0);
  }
  assert.equal(JSON.stringify(data),before);
});
test('a positive amount in the out column is offered when the dual row has no positive in amount',()=>{
  const p=M.prepare(source([r(1,1,'-5.26','2.15')]));
  assert.equal(p.sideExample.side,-1);assert.equal(p.sideExample.amount,2150);assert.ok(p.sideExample.dual);
  const onlyNeg=M.prepare(source([r(2,1,'-5.26','-2.15')]));
  assert.equal(onlyNeg.sideExample,null);
  assert.deepEqual(M.convert(onlyNeg).checked.entries.map(e=>e.legs[0].minor),[-5260,-2150]);
});
test('a dual transfer hint blocks reciprocal pairing and inferred duplicates without blocking unrelated completion',()=>{
  const p=M.prepare(source([
    r(1,1,'10','4','2026-08-17',2,'سجل ملتبس'),
    r(2,2,null,'10','2026-08-17',1,'سجل ملتبس'),
    r(3,2,'11',null,'2026-08-17',1,'سجل ملتبس'),
    r(4,2,'20',null,'2026-08-19',1,'طرف ناقص')
  ]));
  assert.equal(p.transferExample.id,'4');
  const out=M.convert(p,{transfers:'complete'});
  assert.equal(out.uncertain,2);assert.equal(out.paired,0);assert.equal(out.added,1);
  assert.deepEqual(out.checked.entries.map(e=>e.legs.map(l=>[l.account,l.minor])),[
    [['old-a-1',10000]],[['old-a-1',-4000]],[['old-a-2',-10000]],[['old-a-2',11000]],[['old-a-1',-20000],['old-a-2',20000]]
  ]);
});
test('±1 markers do not become amounts once the stored balances corroborate the signed model',()=>{
  const raw=source([r(1,1,'1','12.345'),r(2,2,'-1','6.789'),r(3,1,'1','0')]);
  const pending=M.prepare(raw);assert.ok(pending.formatChoice);assert.equal(pending.verifiedFlags,false);
  raw.cachedBalances=[['1','4','12.3450000000001','3','2','real'],['2','4','-6.789','2','1','real']];
  const flagged=M.prepare(raw);
  assert.equal(flagged.flagged,true);assert.equal(flagged.verifiedFlags,true);assert.equal(flagged.formatChoice,null);
  assert.equal(flagged.stats.dual,0);assert.equal(flagged.stats.zero,1);assert.equal(flagged.stats.precise,2);
  for(const inSign of [1,-1]){
    const out=M.convert(flagged,{inSign,transfers:'complete'});
    assert.deepEqual(out.checked.entries.map(e=>e.legs[0].minor),[12345,-6789]);
    assert.deepEqual(out.evidence,{matched:2,total:2});
  }
});
test('an orphan stays in a review account; an unknown nonblank reference is not guessed',()=>{
  const absent=r(2,1,'-1','4.125');absent[1]=null;
  const draft=M.prepare(source([r(1,1,'1','8.238'),absent]),{layout:'flags'});
  assert.equal(draft.stats.unassigned,1);
  const out=M.convert(draft);
  assert.deepEqual(out.checked.entries[1].legs,[{account:'old-unassigned',code:'YER',minor:-4125}]);
  assert.equal(out.comparisons.find(c=>c.key==='old-unassigned|YER').review,true);
  assert.equal(L.balances(out.checked,'YER').get('old-a-1').minor,8238);
  assert.throws(()=>M.prepare(source([r(3,999,'1','8.238')])),/غير موجود في جدول الحسابات/);
});
