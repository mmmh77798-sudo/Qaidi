'use strict';
/* Exact APK phone export -> HTTPS owner browser -> protected backup -> scope and independent restore. */
const {deskNav,reveal,localSetting}=require('./navigation.cjs');
const assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),https=require('node:https');
const {pathToFileURL}=require('node:url'),{execFileSync}=require('node:child_process'),{once}=require('node:events');
const {chromium}=require('playwright');
const {createDesk}=require('../shared/server.cjs'),{SQLiteStore}=require('../shared/store.cjs');
const R=require('../shared/recovery.cjs'),V=require('../app/vault.js');
const F=require('./premium-fixtures.cjs');
const root=path.resolve(__dirname,'..'),dialog=p=>p.locator('#dialog'),field=(p,n)=>dialog(p).locator(`[name="${n}"]`);
const button=(p,a)=>p.locator(`[data-action=${a}]:visible`).first(),click=(p,a)=>button(p,a).click();
const title=(p,t)=>dialog(p).getByRole('heading',{name:t,exact:true}).waitFor();
const nav=deskNav;
const submit=p=>dialog(p).locator('button[type=submit]').click();
async function signIn(p,login,password){
  await p.locator('#login-form [name=login]').fill(login);await p.locator('#login-form [name=password]').fill(password);
  await p.locator('#login-form button[type=submit]').click();await p.locator('#page h1').waitFor();
}
function createPhoneContainer(file,packed){
  // Same SQLite application id, user version and BLOB chunking as Android BackupDbFile.
  execFileSync('python3',['-c',`import sqlite3, sys
v=sys.stdin.buffer.read(); db=sqlite3.connect(sys.argv[1]); db.executescript('PRAGMA application_id=1363237188; PRAGMA user_version=1; CREATE TABLE qayd_backup(part INTEGER PRIMARY KEY,payload BLOB NOT NULL);')
db.executemany('INSERT INTO qayd_backup VALUES(?, ?)',((i//65536,v[i:i+65536]) for i in range(0,len(v),65536)));db.commit();db.close()`,file],{input:packed});
}
(async()=>{
  const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'qayd-premium-browser-')),store=new SQLiteStore(path.join(tmp,'shared.sqlite'));
  const errors=[],posted=[],outside=[];let server,app,browser;
  try{
    const {s,staff,phone}=await F.sharedState();store.init(s);
    const cert=path.join(tmp,'cert.pem'),pem=path.join(tmp,'key.pem');
    execFileSync('openssl',['req','-x509','-newkey','rsa:2048','-nodes','-days','1','-subj','/CN=127.0.0.1','-addext','subjectAltName=IP:127.0.0.1','-keyout',pem,'-out',cert],{stdio:'ignore'});
    server=https.createServer({key:fs.readFileSync(pem),cert:fs.readFileSync(cert)});server.listen(0,'127.0.0.1');await once(server,'listening');
    const origin=`https://127.0.0.1:${server.address().port}`;
    app=createDesk({store,origin,onError:e=>errors.push(e.message)});
    server.on('request',(req,res)=>{if(req.method==='POST')posted.push(new URL(req.url,origin).pathname);app.listeners('request')[0](req,res);});
    server.once('close',()=>app.emit('close'));
    browser=await chromium.launch();
    const watch=async ctx=>{
      const p=await ctx.newPage();p.setDefaultTimeout(15_000);p.on('pageerror',e=>errors.push(e.message));
      p.on('console',m=>{if(m.type()==='error'&&!/status of (400|401|403|409|428)/.test(m.text()))errors.push(m.text());});return p;
    };
    const mobile={viewport:{width:393,height:852},isMobile:true,hasTouch:true};
    const fileCtx=await browser.newContext({...mobile,offline:true});
    const filePage=await watch(fileCtx),apk=process.env.QAYD_TEST_APK;
    let offlineApp=path.join(root,'app','index.html');
    if(apk){execFileSync('unzip',['-qq',path.resolve(apk),'assets/app/*','-d',tmp]);offlineApp=path.join(tmp,'assets','app','index.html');}
    filePage.on('request',r=>{if(!r.url().startsWith('file:'))outside.push(r.url());});
    const raw=JSON.stringify(phone);
    await filePage.addInitScript(local=>{
      const result={writes:0,saved:[],opened:[]};window.qa=result;
      window.QaydAndroid={readLedger:()=>local,writeLedger:()=>{result.writes++;return true;},openSharedDesk:a=>result.opened.push(a),teamClear:()=>{},backupDb:(...args)=>result.saved.push(args)};
    },raw);
    await filePage.goto(pathToFileURL(offlineApp).href);await localSetting(filePage,'storage');
    await (await reveal(filePage.locator('[data-action=category-transfer-file]'))).click();await title(filePage,'تجهيز ملف نقل مشفّر');
    await field(filePage,'categoryCopyId').selectOption('clients');await dialog(filePage).locator('#category-copy-stats').getByText('2',{exact:true}).waitFor();
    await field(filePage,'phrase').fill(F.transferPhrase);await field(filePage,'again').fill('Synthetic different confirmation phrase');await submit(filePage);
    await dialog(filePage).getByText(/طابق العبارتين/).waitFor();assert.equal(await filePage.evaluate(()=>qa.saved.length),0);
    await field(filePage,'again').fill(F.transferPhrase);await submit(filePage);await dialog(filePage).waitFor({state:'hidden'});
    const recorded=await filePage.evaluate(()=>qa);assert.deepEqual(recorded.opened,[]);assert.equal(recorded.writes,0);assert.equal(recorded.saved.length,1);
    const [name,text,mode,ticket]=recorded.saved[0];assert.match(name,/^qayd-transfer-.*\.db$/);assert.equal(mode,'local');assert.equal(ticket,'');
    const clear=(await V.unlock(JSON.parse(text),F.transferPhrase)).value;
    assert.equal(clear.category.id,'clients');assert.equal(clear.includePhotos,false);assert.equal(clear.accounts.length,2);
    assert.doesNotMatch(JSON.stringify(clear),/OUTSIDE-|SHARED-MEMO|مورد الساحة|data:image|GLOBAL-PROFILE/);
    assert.deepEqual(outside,[]);assert.deepEqual(posted,[]);assert.deepEqual(store.load().s,s);
    const file=path.join(tmp,name);createPhoneContainer(file,text);await fileCtx.close();

    const [ownerCtx,staffCtx]=await Promise.all([browser.newContext({...mobile,ignoreHTTPSErrors:true,acceptDownloads:true}),browser.newContext({...mobile,ignoreHTTPSErrors:true})]);
    const owner=await watch(ownerCtx),employee=await watch(staffCtx);
    await owner.goto(origin+'/#maintenance');await signIn(owner,'owner',F.ownerPass);
    const maintenance=owner.locator('#maintenance-panel');await maintenance.waitFor();
    assert.match(await maintenance.innerText(),/إجراءات المالك فقط/);
    assert.equal(await button(owner,'import').isDisabled(),true);assert.equal(await button(owner,'transfer-pick').isDisabled(),true);
    await employee.goto(origin+'/#maintenance');await signIn(employee,staff.login,F.staffPass);
    await nav(employee,'more');assert.equal(await employee.locator('#maintenance-panel,[data-page=book],[data-action=transfer-pick]').count(),0);
    const before=store.load();
    await click(owner,'recovery-export');await field(owner,'current').fill(F.ownerPass);
    await field(owner,'phrase').fill(F.recoveryPhrase);await field(owner,'again').fill(F.recoveryPhrase);
    const [download]=await Promise.all([owner.waitForEvent('download'),submit(owner)]);
    assert.match(download.suggestedFilename(),/^qayd-recovery-.*\.qayd-recovery$/);
    const fileRecovery=path.join(tmp,download.suggestedFilename());await download.saveAs(fileRecovery);
    const ready=store.load(),decrypted=await R.open(fs.readFileSync(fileRecovery,'utf8'),F.recoveryPhrase);
    assert.deepEqual(decrypted.state,ready.s);assert.deepEqual(ready.s.ledger,before.s.ledger);assert.deepEqual(ready.s.users,before.s.users);
    await click(owner,'transfer-pick');await title(owner,'اختيار تصنيف من دفتر الهاتف');
    await field(owner,'source').setInputFiles(file);await field(owner,'password').fill('Incorrect test password 90099');
    const transferPosts=()=>posted.filter(p=>p.startsWith('/api/book/transfer-'));
    await submit(owner);await dialog(owner).locator('#dialog-error').waitFor();assert.match(await dialog(owner).locator('#dialog-error').innerText(),/غير صحيحة/);
    assert.deepEqual(transferPosts(),[]);await field(owner,'password').fill(F.transferPhrase);await submit(owner);
    await title(owner,'إرسال التصنيف للمراجعة');assert.deepEqual(transferPosts(),[]);
    await submit(owner);assert.deepEqual(transferPosts(),[]);
    await field(owner,'previewConsent').check();await field(owner,'name').fill('عملاء الاختبار المنقولون');
    await submit(owner);await title(owner,'تأكيد إضافة تصنيف خاص');assert.deepEqual(transferPosts(),['/api/book/transfer-review']);
    assert.equal(store.load().seq,ready.seq);
    for(const [code,value] of [['YER','87.875'],['SAR','70.375'],['USD','-4.005']])assert.match(await dialog(owner).locator(`[data-code=${code}]`).innerText(),new RegExp(value.replace('.','\\.')));
    for(const width of [320,393,720,1180]){
      await owner.setViewportSize({width,height:852});
      assert.ok(await dialog(owner).evaluate(el=>el.scrollWidth<=el.clientWidth+1),`preview fits ${width}px`);
    }
    await field(owner,'confirm').check();await submit(owner);assert.equal(store.load().seq,ready.seq,'backup confirmation is required');
    await field(owner,'backupConfirmed').check();await submit(owner);await dialog(owner).waitFor({state:'hidden'});
    const cat=store.load().s.ledger.categories.at(-1);assert.equal(cat.name,'عملاء الاختبار المنقولون');
    assert.deepEqual(transferPosts(),['/api/book/transfer-review','/api/book/transfer-commit']);
    await maintenance.getByText('1 عملية نقل',{exact:true}).waitFor();assert.equal(await button(owner,'transfer-pick').isDisabled(),true);
    await nav(employee,'accounts');await employee.locator('[data-account=shared-only]').waitFor();assert.equal(await employee.locator('[data-account=a]').count(),0);
    await nav(owner,'users');await owner.locator('[data-user="staff.auth"] [data-action=edit-user]').click();
    await dialog(owner).locator(`[data-category="${cat.id}"] [data-permission=view]`).check();
    await submit(owner);await dialog(owner).waitFor({state:'hidden'});await click(employee,'refresh');
    const account=employee.locator('[data-account=a]');await account.getByText('70.75',{exact:true}).waitFor();
    assert.equal(await account.locator('[data-action=new-movement],[data-action=edit-account]').count(),0);
    assert.deepEqual(errors,[]);
    console.log('Phone APK asset export and mobile HTTPS owner review: encrypted DB scope, local-only open, consent before upload, exact preview, protected recovery download, private addition, and explicit employee grant.');
  }finally{await browser?.close();if(server)await new Promise(r=>server.close(r));store.close();fs.rmSync(tmp,{recursive:true,force:true});}
})().catch(e=>{console.error(e);process.exitCode=1;});
