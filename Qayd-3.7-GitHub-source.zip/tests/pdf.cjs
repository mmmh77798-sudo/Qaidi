/* Generated report bytes, reader controls, device-shaped touch gestures and offline file assets. */
const {reveal,localNav}=require('./navigation.cjs');
const assert=require('node:assert/strict');
const fs=require('node:fs/promises');
const os=require('node:os');
const path=require('node:path');
const {pathToFileURL}=require('node:url');
const {chromium}=require('playwright');
const L=require('../app/ledger.js');
const url=process.argv[2]||'http://localhost:3000/';
const asFile=pathToFileURL(path.join(__dirname,'../app/index.html')).href;
const from='2025-02-01',to='2025-03-31';
function fixture(native=false) {
  const d=L.empty();
  d.currencies=[{code:'LOC',name:'محلي',symbol:'م'},...d.currencies.filter(c=>c.code!=='YER'),{code:'EUR',name:'يورو',symbol:'€'}];
  d.settings.defaultCode='LOC';d.settings.print.allCodes=native;
  d.settings.print.credit='مدين تجربة';d.settings.print.footer='ملاحظة اختبار الطباعة';
  d.settings.business='مُؤَسّسة اختبار';d.settings.profile.nameEn='Qayd Test';
  d.settings.home.time=true;
  d.accounts=[{id:'client',name:'مُحمّد التجريبي (AC-9)',category:'suppliers'},{id:'other',name:'صاحب حساب مختلف',category:'customers'}];
  if(!d.categories.find(c=>c.id==='customers'))d.accounts[1].category='';
  const leg=(account,minor,code='LOC')=>({account,code,minor});
  const entry=(id,day,memo,...legs)=>d.entries.push({id,day,created:d.entries.length,time:'14:20',memo,legs});
  entry('opening','2025-01-10','OPEN-EXCLUDED',leg('client',350125));
  for(let i=0;i<60;i++)entry('d'+i,'2025-02-10',i===49?'سجل طويل '.repeat(58)+' END-LONG-49':`فاتورة QAYD-${i} عن 2025-02-10`,leg('client',i===59?123456:1000));
  entry('out','2025-03-01','سداد NET-TEST',leg('client',-2050125));
  entry('pair','2025-03-02','TRANSFER-TEST',leg('client',-50333),leg('other',50333));
  entry('future','2025-04-10','FUTURE-EXCLUDED',leg('client',9100000));
  entry('outside','2025-02-10','OTHER-CLIENT-ONLY',leg('other',990001));
  entry('sar','2025-02-10','SAR-ROW-CLIENT',leg('client',150123,'SAR'));
  entry('sar-out','2025-03-01','SAR-DEBIT-CLIENT',leg('client',-20124,'SAR'));
  entry('usd','2025-03-02','USD-ROW-CLIENT',leg('client',-2050,'USD'));
  entry('euro','2025-03-01','EUR-OTHER-CLIENT',leg('other',1000,'EUR'));
  return L.validate(d);
}
async function pdfData(page,base64) {
  return page.evaluate(async encoded=>{
    const src=URL.createObjectURL(new Blob([QaydPdfWorkerSource],{type:'text/javascript'})),port=new Worker(src);
    const w=QaydPdfRuntime.PDFWorker.fromPort({port});
    const bytes=Uint8Array.from(atob(encoded),c=>c.charCodeAt(0));
    const t=QaydPdfRuntime.getDocument({data:bytes,worker:w,useSystemFonts:false,useWorkerFetch:false,isEvalSupported:false});
    try{
      const pdf=await t.promise,meta=await pdf.getMetadata(),pages=[];
      for(let i=1;i<=pdf.numPages;i++){
        const p=await pdf.getPage(i);
        const text=(await p.getTextContent()).items.map(v=>v.str).filter(Boolean).join(' ').normalize('NFKC');
        const {width,height}=p.getViewport({scale:1});
        pages.push({text,width,height});
      }
      return {code:meta.info.Subject,pages};
    }finally{await t.destroy();w.destroy();port.terminate();URL.revokeObjectURL(src);}
  },base64);
}
async function main(){
  const browser=await chromium.launch({headless:true,args:['--no-sandbox']});
  const out=await fs.mkdtemp(path.join(os.tmpdir(),'qayd-pdf-qa-'));
  const failures=[];
  const fixtureData=fixture();
  try{
    const p=await browser.newPage({viewport:{width:393,height:852},hasTouch:true,isMobile:true,acceptDownloads:true});
    p.setDefaultTimeout(10000);
    const cdp=await p.context().newCDPSession(p);
    const request=[];
    p.on('request',r=>request.push(r.url()));p.on('pageerror',e=>failures.push(e.message));
    p.on('console',m=>{if(m.type()==='error')failures.push(m.text());});
    await p.addInitScript(data=>{localStorage.setItem('qayd.ledger.v1',data);window.print=()=>{window.prints=(window.prints||0)+1;};},JSON.stringify(fixtureData));
    const nav=v=>localNav(p,v);
    const click=(action,target='')=>p.locator(`[data-action=${action}]${target?`[data-target=${target}]`:''}:visible`).first().click();
    const openPdf=async target=>{await click('export-options',target);await click('view-pdf',target);};
    const pane=p.locator('#pdf-dialog');
    const tool=id=>p.locator('#pdf-'+id);
    const viewport=tool('viewport');
    const rendered=()=>pane.locator('.pdf-sheet[data-rendered=true] canvas').first().waitFor({state:'visible'});
    const codeIs=code=>p.waitForFunction(code=>document.querySelector('#pdf-currency')?.value===code,code);
    const download=async name=>{
      const wait=p.waitForEvent('download');await tool('save').click();const f=await wait;
      assert.match(f.suggestedFilename(),name);
      const dest=path.join(out,f.suggestedFilename());await f.saveAs(dest);
      const bytes=await fs.readFile(dest);assert.match(bytes.subarray(0,9).toString(),/^%PDF-/);
      return pdfData(p,bytes.toString('base64'));
    };
    const set=m=>cdp.send('Input.dispatchTouchEvent',m);
    const box=()=>viewport.boundingBox();
    async function swipe(dx,dy=0){
      const b=await box(),x=Math.floor(b.x+b.width/2-dx/2),y=Math.floor(b.y+b.height*.6-dy/2);
      await set({type:'touchStart',touchPoints:[{x,y,id:1}]});
      for(let i=1;i<=6;i++)await set({type:'touchMove',touchPoints:[{x:Math.round(x+dx*i/6),y:Math.round(y+dy*i/6),id:1}]});
      await set({type:'touchEnd',touchPoints:[]});
    }
    async function pinch(){
      const b=await box(),x=Math.round(b.x+b.width/2),y=Math.round(b.y+b.height/2);
      const points=d=>[{x:x-d,y,id:1},{x:x+d,y,id:2}];
      await set({type:'touchStart',touchPoints:points(35)});
      for(const d of [45,60,85,115])await set({type:'touchMove',touchPoints:points(d)});
      await set({type:'touchEnd',touchPoints:[]});
    }
    await p.goto(url);
    assert.equal(request.some(u=>u.includes('/pdf/')),false,'large libraries load on demand');
    await nav('accounts');await p.locator('[data-action=open-account][data-id=client]:visible').first().click();
    const date=(scope,which)=>p.locator(`[data-scope=${scope}][data-filter=${which}]`);
    await date('statement','from').fill(from);await date('statement','to').fill(to);
    let final=p.locator('#view-results .report-final');
    assert.match(await final.innerText(),/العملة: محلي \(LOC\)/);
    assert.match(await final.locator('.final-opening dd').innerText(),/350\.125/);
    assert.equal(await final.locator('.final-net dd').innerText(),'-1,918.002');
    assert.equal(await final.locator('.final-ending dd').innerText(),'-1,567.877');
    await openPdf('statement');await rendered();
    assert.match(await tool('title').innerText(),/AC-9/);
    assert.deepEqual(await tool('currency').locator('option').evaluateAll(ops=>ops.map(o=>o.value)),['LOC','SAR','USD']);
    assert.equal(await tool('prev').isDisabled(),true);
    assert.equal(await p.evaluate(()=>window.prints||0),0,'viewing does not launch print');
    const hasInk=await pane.locator('canvas').first().evaluate(c=>{const data=c.getContext('2d').getImageData(0,0,c.width,c.height).data;let n=0;for(let i=0;i<data.length;i+=4)if(data[i]<145&&data[i+1]<145&&data[i+2]<175)n++;return n>400;});
    assert.ok(hasInk);
    const fitted=await pane.locator('.pdf-sheet').first().evaluate(el=>el.clientWidth);
    await tool('plus').click();assert.equal(await tool('fit').innerText(),'125%');
    assert.ok(await pane.locator('.pdf-sheet').first().evaluate(el=>el.clientWidth)>fitted);
    await tool('minus').click();assert.equal(await tool('fit').innerText(),'100%');
    await pinch();await p.waitForFunction(()=>parseInt(document.querySelector('#pdf-fit').innerText,10)>140);
    assert.equal(await tool('currency').inputValue(),'LOC','pinch only zooms');
    await swipe(140,1);assert.equal(await tool('currency').inputValue(),'LOC','zoomed horizontal pan does not skip currency');
    await tool('fit').click();assert.equal(await tool('fit').innerText(),'100%');
    await tool('top').click();await swipe(12,-170);
    await p.waitForFunction(()=>document.querySelector('#pdf-viewport').scrollTop>35);
    assert.equal(await tool('currency').inputValue(),'LOC','vertical scroll only scrolls pages');
    const pdf=await download(/^qayd-statement-LOC-.*\.pdf$/);
    assert.ok(pdf.pages.length>=3);assert.equal(pdf.code,'LOC');
    const first=pdf.pages[0].text,last=pdf.pages.at(-1).text,all=pdf.pages.map(p=>p.text).join('\n');
    assert.match(first,/AC-9|9-AC/);assert.match(first,/2025-02-01/);assert.match(first,/2025-03-31/);
    assert.match(all,/END-LONG-49/);
    assert.doesNotMatch(all,/OTHER-CLIENT-ONLY|FUTURE-EXCLUDED|OPEN-EXCLUDED|SAR-ROW/);
    for(const expected of ['182.456','2,100.458','-1,918.002','350.125','-1,567.877'])assert.ok(last.includes(expected),`final page includes ${expected}`);
    assert.match(last,/ملخص نهاية التقرير/);assert.match(last,/محلي/);assert.match(last,/إجمالي لي/);
    for(const s of pdf.pages){assert.ok(Math.abs(s.width-595.28)<.02);assert.ok(Math.abs(s.height-841.89)<.02);assert.match(s.text,/LOC/);}
    await tool('summary').click();
    await p.waitForFunction(n=>document.querySelector(`.pdf-sheet[data-page="${n}"][data-rendered=true] canvas`)&&document.querySelector('#pdf-page-counter').textContent.startsWith(`صفحة ${n} `),pdf.pages.length);
    await p.screenshot({path:path.join(out,'statement-summary.png')});
    await swipe(170,4);await codeIs('SAR');await rendered();
    const sar=await download(/^qayd-statement-SAR-.*\.pdf$/);
    const st=sar.pages[0].text;assert.match(st,/SAR-ROW-CLIENT/);assert.match(st,/-20\.124/);assert.match(st,/129\.999/);assert.doesNotMatch(st,/QAYD-0|EUR-OTHER-CLIENT/);
    await swipe(170);await codeIs('USD');await rendered();assert.equal(await tool('next').isDisabled(),true);
    await swipe(170);assert.equal(await tool('currency').inputValue(),'USD');
    await swipe(-165);await codeIs('SAR');await rendered();
    await tool('prev').click();await codeIs('LOC');
    await tool('next').click();await tool('next').click();await codeIs('USD');await rendered();
    const usd=await download(/^qayd-statement-USD-.*\.pdf$/);
    assert.match(usd.pages[0].text,/-2\.05/);assert.match(usd.pages[0].text,/USD-ROW-CLIENT/);
    await tool('print').click();await p.waitForFunction(()=>window.prints===1);
    assert.equal(await p.locator('#print-area .print-section').count(),1);
    assert.match(await p.locator('#print-area .report-final').textContent(),/USD/);
    await p.keyboard.press('Escape');assert.equal(await pane.isVisible(),false);
    assert.equal(await pane.locator('canvas').count(),0);
    assert.equal(await date('statement','from').inputValue(),from);
    assert.match(await p.locator('#page h1').innerText(),/AC-9/);
    assert.equal(await p.locator('[data-change=currency]').inputValue(),'LOC');
    await date('statement','query').fill('NET-TEST');
    assert.equal(await final.locator('.final-net dd').innerText(),'-2,050.125');
    assert.equal(await final.locator('.final-ending dd').innerText(),'-1,567.877');
    await openPdf('statement');await rendered();
    const searched=await download(/^qayd-statement-LOC-.*\.pdf$/);
    assert.match(searched.pages[0].text,/NET-TEST/);assert.doesNotMatch(searched.pages[0].text,/TRANSFER-TEST/);
    await tool('next').click();await codeIs('SAR');await rendered();
    const empty=await download(/^qayd-statement-SAR-.*\.pdf$/);
    assert.match(empty.pages[0].text,/لا سجلات/);assert.match(empty.pages[0].text,/129\.999/);assert.match(empty.pages[0].text,/ملخص نهاية التقرير/);
    await tool('close').click();
    await nav('reports');
    final=p.locator('#view-results .report-final');
    for(const tab of ['accounts','details','months','categories']){
      await p.locator('[data-change=report-kind]').selectOption(tab);
      if(tab==='details')await reveal(date('report','from'));
      await date('report','from').fill(from);await date('report','to').fill(to);
      assert.equal(await final.locator('.final-net dd').innerText(),'-877.668');
      await openPdf('report');await rendered();
      const rep=await download(new RegExp(`^qayd-report-${tab}-LOC-.*\\.pdf$`));
      assert.match(rep.pages.at(-1).text,/ملخص نهاية التقرير/);assert.match(rep.pages.at(-1).text,/-877\.668/);assert.equal(rep.code,'LOC');
      assert.equal(await tool('currency-nav').isVisible(),false);
      await tool('close').click();
    }
    await p.locator('[data-change=report-kind]').selectOption('details');
    await reveal(date('report','kind'));
    await date('report','kind').selectOption('transfer');
    assert.equal(await final.locator('.final-net dd').innerText(),'0');
    await date('report','account').selectOption('client');
    assert.equal(await final.locator('.final-net dd').innerText(),'-50.333');
    assert.match(await p.locator('#view-results tbody').innerText(),/-50\.333/);
    await click('export-options','report');const wait=p.waitForEvent('download');await click('csv','report');
    const csv=await fs.readFile(await (await wait).path(),'utf8');
    assert.match(csv,/"الصافي",-50\.333/);assert.match(csv,/"ملخص نهاية التقرير","محلي \(LOC\)"/);
    assert.doesNotMatch(csv,/FUTURE-EXCLUDED|SAR-ROW-CLIENT/);
    await date('report','from').fill('2025-09-01');await click('export-options','report');
    assert.equal(await pane.isVisible(),false);assert.match(await p.locator('#toast').textContent(),/نطاق التواريخ/);
    assert.equal(await p.evaluate(()=>localStorage.getItem('qayd.ledger.v1')),JSON.stringify(fixtureData));
    assert.equal(request.filter(u=>!u.startsWith(new URL(url).origin+'/')&&!u.startsWith('blob:')).length,0);

    const f=await browser.newPage({viewport:{width:360,height:780},hasTouch:true,isMobile:true});
    f.on('pageerror',e=>failures.push(e.message));f.on('console',m=>{if(m.type()==='error')failures.push(m.text());});
    await f.context().setOffline(true);
    await f.addInitScript(json=>{
      window.exportsPdf=[];window.writes=0;
      window.QaydAndroid={readLedger:()=>json,writeLedger:()=>{window.writes++;return true;},
        exportPdf:(name,encoded,mode)=>{window.exportsPdf.push({name,encoded,mode});window.qaydNativeResult('اكتمل الاختبار المحلي',false);},
        printPage:title=>{window.nativePrinted=title;}};
    },JSON.stringify(fixture(true)));
    await f.goto(asFile);
    await f.locator('#mobilebar [data-view=accounts]').click();await f.locator('[data-action=open-account][data-id=client]:visible').first().click();
    await f.locator('[data-action=export-options][data-target=statement]').click();
    await f.locator('#dialog [data-action=view-pdf][data-target=statement]').click();await f.locator('#pdf-dialog canvas').first().waitFor();
    await f.locator('#pdf-currency').selectOption('SAR');await f.locator('#pdf-dialog canvas').first().waitFor();
    await f.locator('#pdf-save').click();await f.locator('#pdf-share').click();
    const bridge=await f.evaluate(()=>window.exportsPdf);
    assert.deepEqual(bridge.map(x=>x.mode),['local','share']);assert.equal(bridge[0].name,bridge[1].name);assert.equal(bridge[0].encoded,bridge[1].encoded);
    assert.match(bridge[0].name,/SAR/);assert.equal((await pdfData(f,bridge[0].encoded)).code,'SAR');
    await f.locator('#pdf-print').click();await f.waitForFunction(()=>window.nativePrinted?.includes('AC-9'));
    const grouped=await f.locator('#print-area .report-final-unit').allTextContents();assert.equal(grouped.length,3);
    assert.ok(grouped.some(x=>x.includes('LOC'))&&grouped.some(x=>x.includes('SAR'))&&grouped.some(x=>x.includes('USD')));
    assert.equal(await f.evaluate(()=>window.qaydBack()),true);assert.equal(await f.locator('#pdf-dialog').isVisible(),false);
    assert.equal(await f.evaluate(()=>window.writes),0);assert.deepEqual(failures,[]);
    console.log('PDF tests passed: mobile swipe/pan/pinch, zoom, summary jump, signed values, filters, reports, PDF bytes and offline Android-shaped bridge. Synthetic outputs:',out);
  }finally{await browser.close();}
}
main().catch(e=>{console.error(e);process.exitCode=1;});
