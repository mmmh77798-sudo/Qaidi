const {test}=require('node:test');
const assert=require('node:assert/strict');
const L=require('../app/ledger.js');
const B=require('../app/category-backup.js');
const C=require('../app/collections-model.js');
const {fixture,currentFrom,outside,make,target,photo}=require('./category-fixtures.cjs');
const made=1737000100000;
const copy=d=>B.create(d,target,{createdAt:made});
const find=(d,id)=>d.entries.find(e=>e.id===id);
function rejectsUnchanged(d,f,expected){const before=JSON.stringify(d);assert.throws(f,expected);assert.equal(JSON.stringify(d),before);}

test('category files are typed, minimal and portable: only scoped accounts, legs, dates, attachments and dependencies',()=>{
  const d=fixture(),out=copy(d);
  assert.equal(out.format,'qayd-category-backup');assert.equal(out.version,1);assert.equal(out.createdAt,made);
  assert.deepEqual(out.accounts.map(a=>a.id),['a','b']);assert.equal(out.category.id,target);
  assert.deepEqual(out.currencies.map(c=>c.code),['YER','SAR','OMR']);
  for(const key of ['settings','years','categories','activity','lastBackup'])assert.equal(Object.hasOwn(out,key),false);
  assert.doesNotMatch(JSON.stringify(out),/GLOBAL-PROFILE|OUTSIDE-|SHARED-MEMO|770001223|مورد الساحة|مورد النخيل|حساب بلا فئة/);
  assert.equal(find(out,'inside').legs.length,2);assert.equal(find(out,'opening').photo,photo);
  assert.equal(find(out,'out-move').isolatedTransfer,true);assert.deepEqual(find(out,'out-move').legs,[{account:'a',code:'YER',minor:-37250}]);
  assert.equal(find(out,'out-move').due,undefined);assert.equal(find(out,'out-move').photo,'');assert.equal(find(out,'out-move').memo,'');
  assert.equal(find(out,'in-move').due,'2025-06-18');assert.deepEqual(find(out,'in-move').legs,[{account:'a',code:'SAR',minor:90500}]);
  assert.deepEqual(find(out,'receipt-a').receipt,find(d,'receipt-a').receipt);assert.equal(out.receiptSerial,1);
  assert.deepEqual(out.closures,d.closures);assert.deepEqual(out.accounts[0].limits,d.accounts[0].limits);assert.deepEqual(out.accounts[1].followups,d.accounts[1].followups);
  const slim=B.create(d,target,{includePhotos:false,createdAt:made});assert.ok(slim.entries.every(x=>x.photo===''));assert.equal(slim.includePhotos,false);
  assert.equal(find(d,'opening').photo,photo);assert.deepEqual(B.validate(L.stateClone(out)),out);
  // This is not a full-ledger backup even to older Qayd validators.
  assert.throws(()=>L.validate(out));
});

test('replace restores only the identified category, removes its newer entries, preserves every other posting and does not lower receipt serials',()=>{
  const source=fixture(),d=currentFrom(source),snapshot=copy(source),serialized=JSON.stringify(d);
  const p=B.plan(d,snapshot),n=p.next;
  assert.equal(p.category.id,target);assert.equal(p.category.name,'عملاء');assert.equal(p.target.name,'عملاء هذا الجهاز');
  assert.deepEqual(p.accountChanges,{removed:1,updated:0,added:0});assert.deepEqual(p.entryChanges,{removed:1,updated:0,added:0});
  assert.equal(p.outsideAccounts,3);assert.equal(p.kept,2);assert.equal(p.standalone,0);assert.equal(p.changed,true);
  assert.deepEqual(p.currencyTotals.map(c=>[c.code,c.before,c.after]),[['YER',148250,87875],['SAR',70375,70375]]);
  assert.equal(find(n,'extra-sale'),undefined);assert.equal(n.accounts.some(a=>a.id==='extra'),false);assert.deepEqual(outside(n),outside(d));
  assert.deepEqual(n.activity,d.activity);assert.equal(n.receiptSerial,3);assert.deepEqual(n.entries.filter(x=>['out-move','in-move','receipt-x','receipt-y'].includes(x.id)),d.entries.filter(x=>['out-move','in-move','receipt-x','receipt-y'].includes(x.id)));
  for(const {code} of d.currencies){
    const old=L.balances(d,code),fresh=L.balances(n,code);
    for(const a of outside(d).accounts)assert.deepEqual(fresh.get(a.id),old.get(a.id));
  }
  assert.equal(p.removedImages,0);
  assert.equal(JSON.stringify(d),serialized);assert.equal(B.plan(n,snapshot).changed,false);assert.deepEqual(B.plan(n,snapshot).next,n);
  const e=C.saveReceipt(n,{account:'a',code:'SAR',day:'2025-06-25',amount:'1.025',receipt:{method:'bank'}});assert.equal(e.receipt.number,4);
});

test('fresh target restores signed isolated transfer legs without inventing another account, and never replaces existing currency definitions',()=>{
  const source=fixture(),fresh=L.empty();fresh.currencies[0].name='تعريف محلي آخر';
  const n=B.plan(L.validate(fresh),copy(source));
  assert.equal(n.kept,0);assert.equal(n.standalone,2);assert.equal(n.outsideAccounts,0);
  assert.deepEqual(n.addedCurrencies.map(c=>c.code),['OMR']);assert.deepEqual(n.differingCurrencies,['YER']);
  assert.equal(n.next.currencies[0].name,'تعريف محلي آخر');assert.deepEqual(n.next.accounts.map(a=>a.id),['a','b']);
  assert.equal(find(n.next,'in-move').isolatedTransfer,true);assert.equal(find(n.next,'out-move').isolatedTransfer,true);
  assert.equal(find(n.next,'inside').legs.length,2);assert.equal(n.next.entries.length,5);
  for(const a of n.next.accounts)for(const code of ['YER','SAR','OMR']){
    assert.deepEqual(L.balances(n.next,code).get(a.id),L.balances(source,code).get(a.id));
  }
  assert.deepEqual(C.snapshot(n.next,'SAR','2025-07-01').index.get('a').items,C.snapshot(source,'SAR','2025-07-01').index.get('a').items.map(x=>({...x,memo:''})));
  assert.ok(L.isLocked(n.next,'opening'));assert.equal(B.plan(n.next,copy(n.next)).changed,false);
  const e=L.saveEntry(n.next,{id:'out-move',account:'a',code:'YER',kind:'debit',day:'2025-04-02',time:'09:30',amount:'37.250',memo:'بيان محلي'});
  assert.equal(L.validate(n.next).entries.find(e=>e.id==='out-move').isolatedTransfer,true);assert.equal(e.legs.length,1);
});

test('the preview counts images actually removed, not the shared images preserved on matching bridges',()=>{
  const d=fixture();find(d,'inside').photo=photo;
  const snapshot=copy(d);
  find(snapshot,'opening').photo='';
  const p=B.plan(d,snapshot);
  assert.equal(p.removedImages,1);
  assert.equal(find(p.next,'opening').photo,'');
  assert.equal(find(p.next,'inside').photo,photo);
  assert.equal(find(p.next,'out-move').photo,photo);
  assert.deepEqual(outside(p.next),outside(d));
});

test('shared transfer conflicts block atomically, but a matching transfer keeps the current shared memo and both legs',()=>{
  const d=fixture(),x=copy(d);
  const retained=L.stateClone(d);find(retained,'out-move').memo='ملاحظة مشتركة أحدث لا تُغيّر';
  const p=B.plan(retained,x);assert.equal(p.kept,2);assert.equal(find(p.next,'out-move').memo,find(retained,'out-move').memo);
  const later=L.stateClone(d);make(later,'later-cross',{kind:'transfer',from:'a',to:'x',amount:'7.525',day:'2025-06-15'});
  const before=JSON.stringify(later);
  assert.throws(()=>B.plan(later,x),e=>e.bridges?.count===1&&e.bridges.examples[0].code==='YER');assert.equal(JSON.stringify(later),before);
  const edited=L.stateClone(d);find(edited,'out-move').legs[0].minor-=1;find(edited,'out-move').legs[1].minor+=1;
  rejectsUnchanged(edited,()=>B.plan(L.validate(edited),x),/تحويلات مرتبطة/);
  const timemove=L.stateClone(d);find(timemove,'in-move').time='11:31';
  rejectsUnchanged(timemove,()=>B.plan(timemove,x),/تحويلات مرتبطة/);
  const lock=L.stateClone(d);L.closeBalance(lock,'a','YER','2025-04-03');
  assert.throws(()=>B.plan(lock,x),e=>e.bridges?.count===1&&e.bridges.examples[0].reason.includes('أرشفة'));
  const outsideLock=L.stateClone(d);L.closeBalance(outsideLock,'x','YER','2025-04-03');
  const secured=B.plan(outsideLock,x);assert.equal(secured.kept,2);assert.deepEqual(outside(secured.next),outside(outsideLock));
});

test('accounts, IDs, receipt numbers and ambiguous category labels cannot overwrite records outside the chosen category',()=>{
  const source=fixture(),snapshot=copy(source);
  const d=L.empty();d.accounts=[{id:'a',name:'حساب مُصنّف في مكان آخر',category:'suppliers'}];
  rejectsUnchanged(d,()=>B.plan(L.validate(d),snapshot),/تصنيف آخر أو بلا تصنيف/);
  d.accounts=[{id:'unrelated',name:'مؤسّسة الفجر',category:''}];
  rejectsUnchanged(d,()=>B.plan(L.validate(d),snapshot),/تصنيف آخر أو بلا تصنيف/);
  d.accounts=[{id:'unrelated',name:'حساب مستقل',category:'suppliers'}];make(d,'opening',{kind:'credit',account:'unrelated',amount:'100'});
  rejectsUnchanged(d,()=>B.plan(L.validate(d),snapshot),/معرّف حركة خارج التصنيف/);
  find(d,'opening').id='another';C.saveReceipt(d,{account:'unrelated',code:'YER',day:'2025-06-12',amount:'1',receipt:{method:'bank'}});
  rejectsUnchanged(d,()=>B.plan(L.validate(d),snapshot),/رقم سند القبض 000001 مستخدم خارج التصنيف/);
  const clash=L.empty();clash.categories.find(x=>x.id===target).name='تسمية معدّلة';clash.categories.push({id:'different',name:'عملاء',color:'sky'});
  rejectsUnchanged(clash,()=>B.plan(L.validate(clash),snapshot),/اسم التصنيف في النسخة مستخدم/);
  const graph=L.empty();graph.categories=graph.categories.filter(x=>x.id!==target);graph.categories.push({id:'named-match',name:'عُملاء',color:'sky'});
  const matched=B.plan(L.validate(graph),snapshot);
  assert.equal(matched.category.id,'named-match');assert.ok(matched.next.accounts.every(x=>x.category==='named-match'));
  assert.equal(matched.next.categories.filter(x=>L.searchKey(x.name)==='عملاء').length,1);
});

test('the annual cutoff is scoped: honored without closing another category or duplicating an existing year close',()=>{
  const d=fixture();L.closeYear(d,2025);const source=L.validate(d),snapshot=copy(source);
  assert.equal(snapshot.annualThrough,'2025-12-31');assert.deepEqual(snapshot.closures,source.closures);assert.equal(snapshot.years,undefined);
  const unchanged=B.plan(source,snapshot);
  assert.equal(unchanged.localArchive,false);assert.equal(unchanged.changed,false);assert.deepEqual(unchanged.next,source);
  const fresh=L.empty();fresh.accounts.push({id:'alone',name:'خارج التصنيف',category:'suppliers'});
  make(fresh,'working',{account:'alone',kind:'credit',amount:'7',day:'2025-03-03'});
  const before=L.validate(fresh),p=B.plan(before,snapshot);
  assert.equal(p.localArchive,true);assert.equal(L.yearCut(p.next),'');assert.equal(L.isLocked(p.next,'working'),false);
  assert.deepEqual(outside(p.next),outside(before));assert.ok(p.next.entries.filter(e=>e.id!=='working').every(e=>L.isLocked(p.next,e.id)));
  assert.equal(L.statement(p.next,'a','YER').ending,L.statement(source,'a','YER').ending);
  const withoutAnnual=L.stateClone(source);L.openYear(withoutAnnual);
  const serialized=JSON.stringify(withoutAnnual);
  assert.throws(()=>B.plan(withoutAnnual,snapshot),e=>e.bridges?.count===2&&e.bridges.examples.every(r=>r.reason.includes('أرشفة')));
  assert.equal(JSON.stringify(withoutAnnual),serialized);
});

test('an empty category snapshot is valid and cannot add irrelevant currencies; corrupt or demo copies fail safely',()=>{
  const d=fixture(),empty=B.create(d,'personal',{createdAt:made});
  assert.deepEqual(empty.currencies,[]);assert.deepEqual(empty.accounts,[]);
  const dst=L.stateClone(d);dst.accounts.push({id:'p',name:'شخصي أحدث',category:'personal'});make(dst,'p-pay',{account:'p',kind:'credit',amount:'10'});
  const checked=L.validate(dst),p=B.plan(checked,empty);
  assert.deepEqual(outside(p.next,'personal'),outside(checked,'personal'));assert.equal(p.next.accounts.some(a=>a.id==='p'),false);
  const good=copy(d),invalid=(fn,regex)=>{const x=L.stateClone(good);fn(x);rejectsUnchanged(d,()=>B.plan(d,x),regex);};
  invalid(x=>{x.version=7;},/غير مدعومة/);
  invalid(x=>{x.accounts[1].category='';},/خارج نطاق التصنيف/);
  invalid(x=>{x.entries[0].legs[0].account='x';},/حساب الحركة/);
  invalid(x=>{x.entries[1].isolatedTransfer=true;},/طرف التحويل المستقل/);
  invalid(x=>{find(x,'receipt-a').isolatedTransfer=true;},/طرف التحويل المستقل/);
  invalid(x=>{x.currencies.push({code:'EUR',name:'يورو',symbol:'€'});},/خارج نطاق التصنيف/);
  invalid(x=>{x.annualThrough='2025-11-03';},/الأرشيف السنوي/);
  invalid(x=>{x.includePhotos=false;},/لا تطابق خياراتها/);
  invalid(x=>{x.receiptSerial=2;},/تسلسل سندات/);
  invalid(x=>{x.demo=true;},/نسخة تجريبية/);
  rejectsUnchanged(d,()=>B.plan(d,L.empty()),/صيغة نسخة التصنيف/);
});
