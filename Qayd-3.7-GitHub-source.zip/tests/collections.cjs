const {localNav,localCollection}=require('./navigation.cjs');
const {chromium}=require('playwright');
const assert=require('node:assert/strict');
const fs=require('node:fs/promises');
const path=require('node:path');
const os=require('node:os');
const {pathToFileURL}=require('node:url');
const L=require('../app/ledger.js');
const C=require('../app/collections-model.js');
const V=require('../app/vault.js');
const {readContainer}=require('./db-fixtures.cjs');
const today='2026-11-18', day=n=>L.offset(n,today);
const url=pathToFileURL(path.resolve(__dirname,'../app/index.html')).href;
function fixture(){
  const d=L.empty();d.currencies[0].name='محلي';
  d.settings.business='مؤسسة تجريبية';
  d.accounts=[['A','=شركة الياسمين','clients'],['B','ورشة الأفق','clients'],['C','مورد غير مدين','suppliers'],['D','عميل اليوم','personal'],['E','لا يدخل قبل تاريخ القيد','clients']]
    .map(([id,name,category])=>({id,name,category,color:'mint',phone:''}));
  const post=(id,account,minor,offset,due,code='YER')=>d.entries.push({id,day:day(offset),time:'12:00',created:1700000000000+d.entries.length,
    ...(due===undefined?{}:{due:day(due)}),memo:'تفاصيل غير مضمّنة في التقرير',legs:[{account,minor,code}]});
  post('old','A',100125,-120,-60);post('part','A',200500,-40,-30);post('undated','A',80250,-16);post('week','A',25125,-2,7);
  post('paid','A',-150250,-20);post('sar','A',500125,-3,0,'SAR');post('b1','B',90500,-35,-31);post('b2','B',15000,-15,8);
  post('credit','C',-99000,-6);post('now','D',30000,-1,0);post('postdated','E',18000,1,1);
  L.closeBalance(d,'A','YER',day(-100));return L.validate(d);
}
(async()=>{
  const browser=await chromium.launch();
  const out=await fs.mkdtemp(path.join(os.tmpdir(),'qayd-collections-qa-'));
  try{
    const p=await browser.newPage({viewport:{width:393,height:852},hasTouch:true,isMobile:true,timezoneId:'Asia/Aden'});
    p.setDefaultTimeout(9500);const errors=[];p.on('pageerror',e=>errors.push(e.message));
    await p.context().setOffline(true);
    await p.addInitScript(raw=>{
      window.raw=raw;window.books=[];window.docs=[];window.sent=[];window.prints=[];window.csvFiles=[];window.refuseWrite=false;
      window.QaydAndroid={readLedger:()=>window.raw,writeLedger:next=>{if(window.refuseWrite)return false;window.raw=next;return true;},
        compose:(...args)=>window.sent.push(args),exportPdf:(...args)=>window.docs.push(args),exportWorkbook:(...args)=>window.books.push(args),
        saveFile:(...args)=>window.csvFiles.push(args),printPage:title=>window.prints.push(title)};
    },JSON.stringify(fixture()));
    await p.clock.install({time:new Date(today+'T08:00:00Z')});await p.goto(url);
    const dlg=p.locator('#dialog'),results=p.locator('#view-results');
    const click=(act,root=p,extra='')=>root.locator(`[data-action=${act}]${extra}:visible`).first().click();
    const nav=v=>localNav(p,v);
    const tab=k=>click('collection-tab',p,`[data-key=${k}]`);
    const field=k=>dlg.locator(`[name=${k}]`);
    const submit=()=>dlg.locator('button[type=submit]').click();
    const close=()=>click('close-dialog',dlg);
    const state=()=>p.evaluate(()=>JSON.parse(window.raw));
    const currency=p.locator('#page [data-change=currency]');
    const filter=k=>p.locator(`[data-scope=collections][data-filter=${k}]`);
    const metric=k=>p.locator(`.collect-metric[data-key="${k}"] .collect-amount`).innerText();
    const plan=id=>click('collection-account',results,`[data-id=${id}]`);
    const exportFile=async (action,arr,filename,expectedMode='local')=>{
      await click(action,dlg);
      await p.waitForFunction(({arr,filename})=>window[arr].some(x=>x[0]===filename),{arr,filename});
      const [name,encoded,mode]=await p.evaluate(({arr,filename})=>window[arr].find(x=>x[0]===filename),{arr,filename});
      assert.equal(mode,expectedMode);await fs.writeFile(path.join(out,name),Buffer.from(encoded,'base64'));
    };
    await nav('collections');
    assert.equal(await p.locator('h1').innerText(),'التحصيل');
    assert.equal(await metric(''),'391.25');assert.equal(await metric('overdue'),'240.875');
    assert.equal(await metric('today'),'30');assert.equal(await metric('week'),'25.125');
    assert.equal(await metric('later'),'15');assert.equal(await metric('unscheduled'),'80.25');
    assert.deepEqual(await results.locator('.collect-row').evaluateAll(rows=>rows.map(r=>r.dataset.collectionAccount)),['B','A','D']);
    assert.equal(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),true);
    await filter('query').fill('الياسمين');assert.equal(await metric(''),'255.75');assert.equal(await results.locator('.collect-row').count(),1);
    await filter('query').fill('');await click('collection-filter',p,'[data-key=unscheduled]');assert.equal(await results.locator('.collect-row').count(),1);
    await filter('status').selectOption('');await filter('category').selectOption('personal');assert.equal(await metric(''),'30');
    await filter('category').selectOption('');await filter('asOf').fill(day(-16));assert.equal(await metric(''),'321.125');
    await filter('asOf').fill(today);await currency.selectOption('SAR');assert.equal(await metric(''),'500.125');assert.equal(await metric('overdue'),'0');
    await currency.selectOption('YER');await plan('A');assert.equal(await dlg.locator('.collect-plan-metrics .collect-amount').allTextContents().then(x=>x.join('/')),'255.75/150.375/80.25');
    assert.equal(await dlg.locator('[data-action=collection-due][data-id=old]').count(),0);
    await click('collection-due',dlg,'[data-id=undated]');
    await field('due').fill(day(-17));assert.equal(await field('due').evaluate(el=>el.validity.rangeUnderflow),true);
    await field('due').fill(day(-1));
    const original=(await state()).entries.find(e=>e.id==='undated');
    await p.evaluate(()=>window.refuseWrite=true);await submit();assert.match(await dlg.locator('.form-error').innerText(),/لم تُحفظ/);
    assert.equal((await state()).activity,undefined);assert.equal((await state()).entries.find(e=>e.id==='undated').due,undefined);
    await p.evaluate(()=>window.refuseWrite=false);await submit();
    const dated=(await state()).entries.find(e=>e.id==='undated');assert.deepEqual(dated,{...original,due:day(-1)});
    assert.equal((await state()).activity.at(-1).type,'due');
    await click('collection-followup',dlg);await field('kind').selectOption('promise');await field('day').fill(today);await field('note').fill('ملاحظة متابعة خاصة');await submit();
    assert.equal((await state()).accounts[0].followups.YER.kind,'promise');assert.match(await dlg.locator('.collect-follow-summary').innerText(),/وعد بالسداد/);
    await click('collection-receipt',dlg,':not([data-id])');assert.equal(await field('accountName').inputValue(),'=شركة الياسمين');assert.equal(await field('code').isDisabled(),true);
    await field('amount').fill('400');await submit();assert.match(await dlg.locator('.form-error').innerText(),/أكبر من الذمة/);
    await field('amount').fill('50.125');await submit();await dlg.waitFor({state:'hidden'});
    assert.equal(await p.locator('#movement-notice').isVisible(),true);await click('movement-notice-close');
    assert.deepEqual((await state()).entries.at(-1).legs,[{account:'A',code:'YER',minor:-50125}]);
    assert.equal(await metric(''),'341.125');assert.equal(await metric('overdue'),'271');assert.equal(await metric('unscheduled'),'0');
    await filter('status').selectOption('followup');assert.equal(await results.locator('.collect-row').count(),1);
    assert.match(await results.locator('.collect-row').innerText(),/الياسمين/);
    await filter('status').selectOption('');
    await click('export-options',p,'[data-target=collection]');await exportFile('xlsx','books',`qayd-report-collection-YER-${today}.xlsx`);
    await click('export-options',p,'[data-target=collection]');await click('csv',dlg);
    const [csvName,mime,csv]=await p.evaluate(()=>csvFiles[0]);
    assert.equal(csvName,`qayd-report-collection-YER-${today}.csv`);assert.equal(mime,'text/csv');
    assert.match(csv,/"'=شركة الياسمين",205\.625,180\.5/);assert.match(csv,/"إجمالي الذمم المطابقة",341\.125/);
    await tab('aging');
    assert.equal(await p.locator('[data-band=d30] .collect-amount').innerText(),'180.5');assert.equal(await p.locator('[data-band=d60] .collect-amount').innerText(),'90.5');
    assert.equal(await results.locator('[data-aging-account]').count(),2);
    await click('export-options',p,'[data-target=collection-aging]');await exportFile('xlsx-share','books',`qayd-report-aging-YER-${today}.xlsx`,'share');
    async function pdf(target,type){
      await click('export-options',p,`[data-target=${target}]`);await click('view-pdf',dlg,`[data-target=${target}]`);const pane=p.locator('#pdf-dialog');
      await pane.locator('.pdf-sheet[data-rendered=true] canvas').first().waitFor({state:'visible',timeout:18000});
      assert.equal(await pane.locator('#pdf-currency').isDisabled(),true);
      await pane.locator('[data-pdf-action=save]').click();
      await p.waitForFunction(name=>docs.some(x=>x[0]===name),`qayd-report-${type}-YER-${today}.pdf`);
      const [name,b64,mode]=await p.evaluate(()=>docs.at(-1));assert.equal(mode,'local');
      const file=Buffer.from(b64,'base64');assert.equal(file.subarray(0,4).toString(),'%PDF');await fs.writeFile(path.join(out,name),file);
      await pane.locator('[data-pdf-action=close]').click();
    }
    await pdf('collection-aging','aging');await tab('queue');await pdf('collection','collection');
    await click('export-options',p,'[data-target=collection]');await click('print',dlg);
    await p.waitForFunction(()=>prints.length===1);
    assert.match(await p.locator('#print-area .final-ending dd').innerText(),/341\.125/);
    assert.doesNotMatch(await p.locator('#print-area').textContent(),/ملاحظة متابعة خاصة|تفاصيل غير مضمّنة/);
    // Historical queues are not an action for posting a receipt against today's funds.
    await filter('asOf').fill(day(-1));await plan('A');assert.equal(await dlg.locator('[data-action=collection-receipt]').count(),0);await close();
    // Verify archived due dates as planning metadata, not an edit of the financial posting.
    await nav('moves');await click('entry-info',p,'[data-id=old]');
    assert.equal(await dlg.locator('[data-action=edit-entry]').count(),0);
    await click('collection-due',dlg);await field('due').fill(day(-59));await submit();assert.equal((await state()).entries.find(e=>e.id==='old').due,day(-59));await close();
    // New due field is optional. File portability includes the actual local history, without guessing historical events.
    await click('new-entry');await field('accountName').fill('عميل اليوم');await field('amount').fill('5');await dlg.locator('#entry-extra > summary').click();await field('due').fill(day(2));await submit();
    assert.equal((await state()).entries.at(-1).due,day(2));await click('movement-notice-close');
    await localCollection(p,'activity');
    assert.equal(await p.locator('.audit-feed li').count(),5);
    assert.doesNotMatch(await p.locator('.audit-feed').innerText(),/ملاحظة متابعة خاصة|تفاصيل غير مضمّنة/);
    await filter('auditType').selectOption('due');assert.equal(await p.locator('.audit-feed li').count(),2);
    await filter('auditQuery').fill('لم يرد');assert.equal(await p.locator('.audit-feed li').count(),0);
    await filter('auditQuery').fill('الياسمين');assert.equal(await p.locator('.audit-feed li').count(),2);
    const db=path.join(out,'qayd-collections-synthetic.db'),file=await p.evaluate(async()=>Array.from(await QaydDb.write(window.raw)));
    await fs.writeFile(db,Uint8Array.from(file));
    const stored=L.validate(readContainer(db)),active=L.validate(await state());assert.deepEqual(stored,active);
    assert.equal(C.summary(C.snapshot(stored,'YER',today).rows).total,346125);
    await nav('settings');await p.locator('.settings-tile[data-key=security]').click();await click('password-change');
    const pass='local-tests-only-5381';await field('pass').fill(pass);await field('again').fill(pass);await submit();
    await p.locator('[data-action=lock-now]').waitFor();assert.ok(V.is(await state()));
    assert.doesNotMatch(JSON.stringify(await state()),/الياسمين|وعد|ملاحظة/);
    assert.deepEqual((await V.unlock(await state(),pass)).value.activity,active.activity);
    await click('lock-now');assert.equal(await p.locator('#app').isVisible(),false);assert.equal(await p.locator('#page').textContent(),'');
    assert.equal(await p.evaluate(()=>window.sent.length),0);assert.deepEqual(errors,[]);
    console.log('Collections: exact cutoff/bands, priority, follow-up, due edits (including archived), receipt, rollback, activity, offline PDF/XLSX/print, SQLite and encrypted state passed. Synthetic outputs:',out);
  }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
