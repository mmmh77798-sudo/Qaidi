const {test}=require('node:test');
const assert=require('node:assert/strict');
const L=require('../app/ledger.js');
const F=require('../app/account-features.js');
const strip=s=>s.replace(/[\u2066-\u2069]/g,'');
const n=new Intl.NumberFormat('en-US',{maximumFractionDigits:3});
const example={business:'مؤسسة الاختبار',nameEn:'Test Business',minor:-5000000,balance:28350000,currency:'محلي',format:m=>n.format(m/L.SCALE)};

test('movement draft has sender, posting and current balance in recipient perspective',()=>{
  assert.equal(strip(F.movementMessage(example)),'إشعار من مؤسسة الاختبار:\nلك 5,000 محلي واصل\nالإجمالي - عليك 28,350 محلي');
  assert.equal(strip(F.movementMessage({...example,business:'',minor:5125,balance:-7001,currency:'سعودي'})),
    'إشعار من Test Business:\nعليك 5.125 سعودي\nالإجمالي - لك 7.001 سعودي');
  assert.match(strip(F.movementMessage({...example,business:' ',nameEn:'',balance:0})),/^إشعار من قيد:\n.+\nالإجمالي - متوازن 0 محلي$/);
});

test('draft opt-ins preserve preferences and transfer text without exposing a counterparty by default',()=>{
  const defaults=strip(F.movementMessage({...example,transfer:true}));
  assert.match(defaults,/تحويل: لك 5,000 محلي/);assert.doesNotMatch(defaults,/واصل/);
  const customized=strip(F.movementMessage({...example,business:'متجر\n\u202eاختبار',transfer:true,credit:'مستحق عليك',debit:'مستحق لك',intro:'السلام عليكم',ending:'شكرًا',stamp:'2026-11-18 09:45',party:'إلى حساب تجريبي'}));
  assert.deepEqual(customized.split('\n'),['السلام عليكم','إشعار من متجر اختبار:','تحويل: مستحق لك 5,000 محلي','الإجمالي - مستحق عليك 28,350 محلي','2026-11-18 09:45','إلى حساب تجريبي','شكرًا']);
});

test('notice opt-out and prior channel/date preferences survive validation; selected phone numbers stay strict',()=>{
  const fresh=L.validate(L.empty());assert.equal(fresh.settings.notify.quickAdded,true);assert.equal(fresh.settings.notify.date,false);
  const previous=L.empty();previous.settings.notify={channel:'wa',date:true,localAdd:true};
  const valid=L.validate(previous);
  assert.equal(valid.settings.notify.quickAdded,true);assert.equal(valid.settings.notify.channel,'wa');
  assert.equal(valid.settings.notify.date,true);assert.equal(valid.settings.notify.localAdd,true);
  previous.settings.notify.quickAdded=false;assert.equal(L.validate(previous).settings.notify.quickAdded,false);
  assert.equal(L.phoneNumber('\u200e٠٠٩٦٧\u00a0٧٧١\u2011555 000'),'+967771555000');
  assert.throws(()=>L.phoneNumber('123'),/رقمًا صحيحًا/);
  assert.throws(()=>L.phoneNumber('+967771555000 #45'),/رقمًا صحيحًا/);
});
