const {reveal,localNav,localSetting,localCollection}=require('./navigation.cjs');
const {chromium}=require('playwright');
const assert=require('node:assert/strict');
const fs=require('node:fs/promises');
const path=require('node:path');
const os=require('node:os');
const {pathToFileURL}=require('node:url');
const L=require('../app/ledger.js');
const B=require('../app/category-backup.js');
const V=require('../app/vault.js');
const {readContainer,legacyDb}=require('./db-fixtures.cjs');
const {fixture,currentFrom,outside,make,target,photo}=require('./category-fixtures.cjs');
const url=pathToFileURL(path.resolve(__dirname,'../app/index.html')).href;
const canonical=s=>L.digits(s).replace(/\u066b/g,'.').replace(/\u066c/g,',');
const testTime=new Date('2026-11-18T12:11:34Z');
const asBuffer=x=>Buffer.from(JSON.stringify(x));
const mock=raw=>{
  Object.assign(window,{raw,writeFail:false,writes:0,categoryPicks:0,fullPicks:0,exportsMade:[],imports:[],sending:[],readable:null});
  window.QaydAndroid={readLedger:()=>window.raw,writeLedger:next=>{if(writeFail)return false;window.raw=next;writes++;return true;},
    backupDb:(name,value,mode,id)=>window.exportsMade.push({name,value,mode,id}),pickCategoryBackup:()=>window.categoryPicks++,pickBackup:()=>window.fullPicks++,
    readPendingBackup:id=>{if(id!==readable.id)return;imports.push(id);void window.qaydBackupReady(id,readable.filename,readable.size,readable.kind,readable.categoryOnly);},
    backupPart:(id,i)=>id!==readable.id?null:readable.kind==='db'?btoa(String.fromCharCode(...readable.value.slice(i,i+1023))):readable.value.slice(i,i+137),
    discardBackup:()=>{},compose:(...args)=>sending.push(args)};
  window.testOffer=input=>{window.readable=input;window.qaydBackupOffered(input.id,true);};
};

(async()=>{
  const source=fixture(),current=currentFrom(source),browser=await chromium.launch(),out=await fs.mkdtemp(path.join(os.tmpdir(),'qayd-category-qa-'));
  const errors=[];let serial=0;
  try{
    const newPage=async(raw,{device=false,width=393}={})=>{
      const p=await browser.newPage({viewport:{width,height:852},hasTouch:true,isMobile:true,timezoneId:'Asia/Aden',acceptDownloads:true});
      await p.context().setOffline(true);p.setDefaultTimeout(10000);p.on('pageerror',e=>errors.push(e.message));
      await p.clock.setFixedTime(testTime);
      if(device)await p.addInitScript(mock,JSON.stringify(raw));
      else await p.addInitScript(s=>localStorage.setItem('qayd.ledger.v1',s),JSON.stringify(raw));
      await p.goto(url);return p;
    };
    const click=(p,action,{inDialog=false,extra=''}={})=>p.locator(`${inDialog?'#dialog ':''}[data-action="${action}"]${extra}:visible`).first().click();
    const field=(p,n)=>p.locator(`#dialog [name="${n}"]`);
    const title=(p,n,timeout=10000)=>p.locator('#dialog').getByRole('heading',{name:n,exact:true}).waitFor({state:'visible',timeout});
    const submit=p=>p.locator('#dialog button[type=submit]');
    const close=p=>click(p,'close-dialog',{inDialog:true});
    const state=p=>p.evaluate(()=>JSON.parse(window.raw||localStorage.getItem('qayd.ledger.v1')));
    const snapshot=async(p,n)=>{if(process.env.QAYD_CATEGORY_SCREENSHOTS)await p.screenshot({path:path.join(out,n+'.png'),animations:'disabled'});};
    const nav=localNav;
    const storage=async p=>{await localSetting(p,'storage');await reveal(p.locator('.category-copy-card').first());};
    const categoryReview=p=>title(p,'استرجاع تصنيف فقط');
    const noFullReview=async p=>assert.equal(await p.locator('#dialog').getByRole('heading',{name:'استرجاع واستبدال البيانات',exact:true}).count(),0);
    const confirm=async p=>{await field(p,'confirmCategory').check();await submit(p).click();};
    const openNative=async (p,filename,value,{categoryOnly=true,kind='db'}={})=>{
      const id='synthetic-offer-'+(++serial),payload=kind==='db'?[...value]:value;
      await p.evaluate(x=>window.testOffer(x),{id,filename,value:payload,size:payload.length,kind,categoryOnly});
      await p.waitForFunction(id=>window.imports.includes(id),id);
    };

    const web=await newPage(source);
    await storage(web);assert.equal(await web.locator('.category-copy-card').isVisible(),true);await snapshot(web,'storage');
    await click(web,'category-backup');await title(web,'حفظ نسخة تصنيف');
    const picker=field(web,'categoryCopyId');assert.equal(await picker.inputValue(),'');
    assert.equal(await picker.evaluate(x=>x.validity.valueMissing),true);
    await picker.selectOption('suppliers');assert.match(await web.locator('#category-copy-stats').innerText(),/أطراف التحويل الخاصة بهذا التصنيف: 2/);
    await picker.selectOption(target);assert.match(await web.locator('#category-copy-stats').innerText(),/5\s+حركة/);await snapshot(web,'select-category');
    const [download]=await Promise.all([web.waitForEvent('download'),submit(web).click()]);
    const filename=download.suggestedFilename();assert.match(filename,/^qayd-category-2026-11-18-\d{6}\.db$/);
    const file=path.join(out,filename);await download.saveAs(file);
    const payload=readContainer(file),bytes=await fs.readFile(file);
    assert.deepEqual(payload,B.create(source,target,{createdAt:payload.createdAt}));assert.equal(payload.entries[0].photo,photo);
    assert.doesNotMatch(JSON.stringify(payload),/GLOBAL-PROFILE|OUTSIDE-|SHARED-MEMO|مورد الساحة/);
    assert.deepEqual(await state(web),source);
    // Management has no duplicate backup actions; all copies start from storage.
    await nav(web,'categories');assert.equal(await web.locator('[data-action=category-backup],[data-action=category-restore]').count(),0);
    // Even if a category file is chosen from the general backup path, it cannot reach full replacement.
    await web.locator('#backup-file').setInputFiles(file);await categoryReview(web);await noFullReview(web);
    assert.match(await web.locator('#dialog').innerText(),/مطابق للنسخة/);assert.equal(await submit(web).count(),0);await close(web);
    const noPhotos=B.create(source,target,{includePhotos:false});
    await web.locator('#category-backup-file').setInputFiles({name:'images-excluded.json',mimeType:'application/json',buffer:asBuffer(noPhotos)});
    await categoryReview(web);
    assert.match(await web.locator('.category-copy-notes').innerText(),/صور حركات ستُزال لأنها غير موجودة في النسخة: 1/);
    await close(web);
    assert.equal((await state(web)).entries.find(e=>e.id==='opening').photo,photo);
    // Legacy imports stay in their own guided path, never exposed through the restricted picker.
    const oldFile=path.join(out,'legacy-test-only.db');legacyDb(oldFile);
    await web.locator('#category-backup-file').setInputFiles(oldFile);
    await web.locator('#dialog .form-error').waitFor();assert.match(await web.locator('#dialog .form-error').innerText(),/مساره المخصص/);await close(web);
    assert.deepEqual(await state(web),source);

    const device=await newPage(current,{device:true});await storage(device);await click(device,'category-restore');
    assert.equal(await device.evaluate(()=>categoryPicks),1);assert.equal(await device.evaluate(()=>fullPicks),0);
    await openNative(device,'share-opaque.db',bytes);await categoryReview(device);await noFullReview(device);
    assert.match(await device.locator('#dialog-title + p').innerText(),/عملاء هذا الجهاز/);
    assert.match(await device.locator('#dialog .notice').first().innerText(),/يُستبدل تصنيف .* فقط/);
    assert.match(canonical(await device.locator('.category-copy-impact').innerText()),/1 حساب و1 حركة/);
    assert.deepEqual((await device.locator('.category-copy-table tbody tr').first().locator('td').allTextContents()).map(canonical),['YER','148.25','87.875']);
    for(const width of [280,320,393,550,740,950,1200]){
      await device.setViewportSize({width,height:852});
      assert.equal(await device.locator('#dialog').evaluate(d=>d.scrollWidth<=d.clientWidth+2),true,`dialog fit at ${width}px`);
    }
    await device.setViewportSize({width:393,height:852});await snapshot(device,'replacement-review');
    await submit(device).click();assert.equal(await device.evaluate(()=>writes),0);assert.equal(await field(device,'confirmCategory').evaluate(e=>e.validity.valueMissing),true);
    await close(device);assert.deepEqual(await state(device),current);
    await click(device,'category-restore');await openNative(device,filename,bytes);await categoryReview(device);
    await click(device,'category-backup-before',{inDialog:true});await device.waitForFunction(()=>window.exportsMade.length===1);
    const staged=await device.evaluate(()=>window.exportsMade[0]),saveSnapshot=JSON.parse(staged.value);
    assert.match(staged.name,/^qayd-category-before-/);assert.equal(staged.mode,'local');assert.match(staged.id,/^restore-save-/);
    assert.deepEqual(saveSnapshot.accounts.map(a=>a.id),['a','b','extra']);assert.ok(saveSnapshot.entries.some(e=>e.id==='extra-sale'));
    assert.doesNotMatch(staged.value,/OUTSIDE-RECENT-STAYS|DESTINATION-ONLY/);
    assert.equal(await submit(device).isDisabled(),true);
    await device.evaluate(()=>window.qaydRestoreCopyResult('stale','saved','ignored'));assert.equal(await submit(device).isDisabled(),true);
    await device.evaluate(id=>window.qaydRestoreCopyResult(id,'cancelled','أُلغي حفظ التصنيف الحالي.'),staged.id);
    assert.match(await device.locator('#restore-copy-status').innerText(),/أُلغي/);assert.equal(await submit(device).isDisabled(),false);assert.deepEqual(await state(device),current);
    await click(device,'category-backup-before',{inDialog:true});await device.waitForFunction(()=>window.exportsMade.length===2);
    await device.evaluate(()=>window.qaydRestoreCopyResult(window.exportsMade[1].id,'saved','حُفظ التصنيف الحالي.'));
    assert.equal(await device.locator('#restore-copy-status').getAttribute('data-state'),'saved');
    await device.evaluate(()=>window.writeFail=true);await confirm(device);
    assert.match(await device.locator('#dialog .form-error').innerText(),/لم تُحفظ/);assert.deepEqual(await state(device),current);assert.equal(await device.evaluate(()=>writes),0);
    await device.evaluate(()=>window.writeFail=false);await submit(device).click();await device.locator('#dialog').waitFor({state:'hidden'});
    const restored=await state(device);assert.deepEqual(outside(restored),outside(current));assert.equal(restored.accounts.length,5);
    assert.equal(restored.entries.find(e=>e.id==='extra-sale'),undefined);assert.equal(restored.receiptSerial,3);
    assert.equal(restored.activity.length,current.activity.length+1);assert.equal(restored.activity.at(-1).type,'category-restore');
    assert.equal(await device.evaluate(()=>writes),1);assert.equal(await device.locator('#movement-notice').isVisible(),false);assert.equal(await device.evaluate(()=>sending.length),0);
    await device.locator('#backup-file').setInputFiles(file);await categoryReview(device);assert.equal(await submit(device).count(),0);await close(device);
    assert.deepEqual(await state(device),restored);

    // Full Qayd copies, when chosen from the category path, can extract one older category only.
    const fullWithPhoto=L.stateClone(source);
    fullWithPhoto.settings.backupPhotos=false;
    fullWithPhoto.entries.find(e=>e.id==='supplies').photo=photo;
    await click(device,'category-restore');await openNative(device,'full-qayd-old.json',JSON.stringify(fullWithPhoto),{kind:'json'});
    await title(device,'اختيار تصنيف من النسخة');await noFullReview(device);await field(device,'sourceCategory').selectOption('suppliers');
    await submit(device).click();await categoryReview(device);assert.match(await device.locator('#dialog .restore-file').innerText(),/مستخرج من نسخة قيد كاملة/);
    await confirm(device);await device.locator('#dialog').waitFor({state:'hidden'});
    const supplierState=await state(device);assert.deepEqual(outside(supplierState,'suppliers'),outside(restored,'suppliers'));
    assert.equal(supplierState.entries.some(e=>e.id==='outside-recent'),false);assert.equal(supplierState.receiptSerial,3);
    assert.equal(supplierState.entries.find(e=>e.id==='supplies').photo,photo);assert.equal(supplierState.settings.backupPhotos,current.settings.backupPhotos);
    await localCollection(device,'activity');
    await device.locator('[data-filter=auditType]').selectOption('category');assert.equal(await device.locator('[data-event=category-restore]').count(),2);
    assert.doesNotMatch(await device.locator('.audit-feed').innerText(),/OUTSIDE-|CAT-REF|DESTINATION-ONLY/);
    // The normal full-restore path still exists and requires its existing explicit confirmation.
    await storage(device);await click(device,'restore');assert.equal(await device.evaluate(()=>fullPicks),1);
    await openNative(device,'full-qayd.json',JSON.stringify(source),{categoryOnly:false,kind:'json'});
    await title(device,'استرجاع واستبدال البيانات');await close(device);assert.deepEqual(await state(device),supplierState);

    // A write to browser storage since the review is never overwritten by a stale plan.
    const stale=await newPage(current);
    await stale.locator('#category-backup-file').setInputFiles(file);await categoryReview(stale);
    const concurrent=L.stateClone(current);make(concurrent,'outside-concurrent',{kind:'credit',account:'u',amount:'6.001',day:'2025-06-12'});
    const newer=L.validate(concurrent);
    await stale.evaluate(raw=>localStorage.setItem('qayd.ledger.v1',raw),JSON.stringify(newer));
    await confirm(stale);await stale.locator('#dialog .form-error').waitFor();
    assert.match(await stale.locator('#dialog .form-error').innerText(),/نافذة أخرى/);
    assert.deepEqual(await state(stale),newer);

    const changed=L.stateClone(current);make(changed,'cross-new',{kind:'transfer',from:'a',to:'x',amount:'12.001',day:'2025-06-12'});
    const blocked=await newPage(L.validate(changed));await blocked.locator('#category-backup-file').setInputFiles(file);
    await title(blocked,'لم يُسترجع التصنيف');assert.match(await blocked.locator('.category-conflicts').innerText(),/2025-06-12/);
    assert.equal(await submit(blocked).count(),0);assert.deepEqual(await state(blocked),L.validate(changed));await snapshot(blocked,'transfer-conflict');
    const fresh=await newPage(L.empty());await fresh.locator('#category-backup-file').setInputFiles(file);await categoryReview(fresh);
    assert.match(await fresh.locator('#dialog').innerText(),/طرف تحويل سيُسترجع/);await confirm(fresh);
    await fresh.locator('#dialog').waitFor({state:'hidden'});const newLedger=await state(fresh);
    assert.deepEqual(newLedger.accounts.map(a=>a.id),['a','b']);assert.equal(newLedger.entries.filter(e=>e.isolatedTransfer).length,2);
    await nav(fresh,'moves');await click(fresh,'entry-info',{extra:'[data-id=out-move]'});await title(fresh,'طرف تحويل مسترجع');
    assert.match(await fresh.locator('#dialog').innerText(),/لا يوجد قيد مقابل/);
    await close(fresh);await nav(fresh,'reports');await fresh.locator('[data-change=report-kind]').selectOption('details');
    const report=await fresh.evaluate(()=>exportData('report'));
    assert.deepEqual(report.rows.filter(r=>r[3].v==='طرف تحويل').map(r=>r[4].v),[-37250]);
    assert.equal(report.summary.net,87875);

    // An encrypted category copy uses the source password but does not change the destination password.
    const sourcePass='category-source-123',destPass='category-destination-123';
    const privateCopy=await V.lock(payload,await V.newKey(sourcePass));
    const protectedCurrent=await V.lock(current,await V.newKey(destPass));
    const secure=await newPage(protectedCurrent,{device:true});assert.equal(await secure.locator('#lock-screen').isVisible(),true);
    await secure.locator('#unlock-form [name=password]').fill(destPass);await secure.locator('#unlock-form [type=submit]').click();await secure.locator('#app').waitFor();
    await storage(secure);await click(secure,'category-backup');await field(secure,'categoryCopyId').selectOption(target);
    await field(secure,'categoryPhotos').uncheck();await submit(secure).click();await secure.waitForFunction(()=>window.exportsMade.length===1);
    const sealed=JSON.parse(await secure.evaluate(()=>window.exportsMade[0].value));assert.ok(V.is(sealed));
    const unpacked=(await V.unlock(sealed,destPass)).value;assert.equal(unpacked.format,B.format);assert.ok(unpacked.entries.every(e=>!e.photo));
    assert.equal(unpacked.accounts.length,3);assert.equal(unpacked.category.name,'عملاء هذا الجهاز');
    await secure.locator('#category-backup-file').setInputFiles({name:'encrypted-copy.json',mimeType:'application/json',buffer:asBuffer(privateCopy)});
    await title(secure,'نسخة احتياطية مشفّرة');await field(secure,'password').fill('wrong-password');await submit(secure).click();
    await secure.locator('#dialog .form-error').waitFor();assert.match(await secure.locator('#dialog .form-error').innerText(),/غير صحيحة/);
    assert.deepEqual(await state(secure),protectedCurrent);
    await field(secure,'password').fill(sourcePass);await submit(secure).click();await categoryReview(secure);await noFullReview(secure);
    await close(secure);assert.deepEqual(await state(secure),protectedCurrent);
    const encryptedDb=Buffer.from(await web.evaluate(async v=>Array.from(await QaydDb.write(v)),JSON.stringify(privateCopy)));
    await click(secure,'category-restore');await openNative(secure,'encrypted-copy.db',encryptedDb);
    try{await title(secure,'نسخة احتياطية مشفّرة',25000);}catch(e){console.error('Encrypted DB review diagnostic:',await secure.locator('#dialog').innerText(),errors);throw e;}
    await field(secure,'password').fill(sourcePass);await submit(secure).click();await categoryReview(secure);await noFullReview(secure);
    await confirm(secure);await secure.locator('#dialog').waitFor({state:'hidden'});const encryptedAfter=await state(secure);
    assert.ok(V.is(encryptedAfter));await assert.rejects(V.unlock(encryptedAfter,sourcePass));
    const clear=(await V.unlock(encryptedAfter,destPass)).value;
    assert.deepEqual(outside(clear),outside(current));assert.equal(clear.accounts.some(a=>a.id==='extra'),false);
    assert.equal(clear.receiptSerial,3);assert.deepEqual(errors,[]);
    console.log('Category backups: private scoped DB, optional photos, native picker scope, review/cancel/pre-copy/retry, exact replacement without altering other categories, extraction with attachments, stale reviews, transfer conflicts, exact signed reports and encrypted DB/JSON portability passed. Synthetic output:',out);
  }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
