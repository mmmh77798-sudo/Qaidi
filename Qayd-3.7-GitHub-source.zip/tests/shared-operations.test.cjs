'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const L=require('../app/ledger.js'),P=require('../shared/policy.cjs');
const today=L.localDay(),day=n=>L.offset(n,today),q=o=>new URLSearchParams(o);
const owner={id:'o',name:'مالك التجربة',owner:true};
const actor={id:'s',name:'موظف التحصيل',grants:[{category:'clients',allow:['view','reports','followup','exportCsv']},{category:'personal',allow:['view']}]};
const base=()=>{
  const d=L.empty();d.accounts.push({id:'a',name:'متجر تجريبي',category:'clients'},{id:'b',name:'HIDDEN-1 مورد تجريبي',category:'suppliers'},{id:'c',name:'VIEW-ONLY حساب تجريبي',category:'personal'});
  const credit=(id,amount,start,due,account='a',code='YER')=>{const r=L.saveEntry(d,{kind:'credit',account,code,amount,day:day(start),time:'10:25',due:due===null?'':day(due)});r.id=id;return r;};
  credit('a91','100.125',-130,-91);credit('a60','50.125',-65,-60);credit('a90','0.075',-65,-61);
  L.saveEntry(d,{kind:'transfer',from:'b',to:'a',code:'YER',amount:'12.500',day:day(-20),due:day(-12),memo:'MEMO-HIDDEN'}).id='bridge';
  credit('a0','7.500',-3,0);credit('a7','8.250',-3,7);credit('a8','9',-3,8);credit('aN','23',-3,null);
  credit('b1','100',-20,-19,'b');credit('c1','388',-20,-19,'c');credit('sar','1.887',-20,-19,'a','SAR');
  L.saveEntry(d,{kind:'debit',account:'a',code:'YER',amount:'10.125',day:day(-1),receipt:{method:'bank',target:'a60'}});
  L.saveEntry(d,{kind:'debit',account:'a',code:'YER',amount:'20',day:day(-1)});
  L.setFollowup(d,'a','YER',{kind:'promise',day:day(-1),note:'تم الاتفاق على موعد تجريبي',at:Date.now()});
  return P.fresh(d);
};

test('dated shared aging reconciles all open amounts, payment allocation and overdue boundaries exactly',()=>{
  const s=base(),raw=JSON.stringify(s),r=P.collection(s,actor,q({code:'YER'}));
  assert.equal(r.total,1);assert.equal(r.asOf,today);
  const row=r.rows[0];assert.equal(row.id,'a');assert.equal(row.firstDue,day(-91));assert.equal(row.oldestDays,91);
  assert.deepEqual([row.d30,row.d60,row.d90,row.d91],[12500,40000,75,80125]);
  assert.deepEqual([row.total,row.overdue,row.today,row.week,row.later,row.unscheduled],[180450,132700,7500,8250,9000,23000]);
  assert.equal(r.sums.total,row.total);assert.equal(r.sums.lateAccounts,1);
  assert.equal(row.total,L.balances(s.ledger,'YER').get('a').minor);
  assert.equal(P.collection(s,actor,q({code:'SAR'})).sums.total,1887);
  const details=P.collection(s,actor,q({account:'a'}),'detail');
  const bridge=details.items.find(x=>x.id==='bridge');assert.equal(bridge.open,12500);assert.equal(bridge.transfer,true);assert.equal(bridge.memo,'');
  assert.equal(P.collection(s,owner,q({account:'a'}),'detail').items.find(x=>x.id==='bridge').memo,'MEMO-HIDDEN');
  assert.doesNotMatch(JSON.stringify([r,details]),/HIDDEN-1|VIEW-ONLY|MEMO-HIDDEN/);
  const past=P.collection(s,actor,q({asOf:day(-16),account:'a'}),'detail');
  assert.equal(past.row.total,162825);assert.equal(past.row.followup,null);assert.equal(past.row.post,false);assert.equal(past.row.manage,false);
  assert.equal(P.collection(s,actor,q({state:'followup'})).total,1);
  assert.equal(P.collection(s,actor,q({state:'week',q:'مورد'})).total,0);
  assert.equal(JSON.stringify(s),raw);
});

test('follow-up and report scopes are independent, versioned and cannot reveal hidden detail',()=>{
  const s=base(),raw=JSON.stringify(s);
  const p=actor.grants.slice(0,1).map(g=>({...g,allow:g.allow.filter(x=>!['followup','exportCsv'].includes(x))}));
  const viewOnly={...actor,grants:p};
  const denied=(fn,status)=>assert.throws(fn,e=>e instanceof P.Problem&&e.status===status);
  denied(()=>P.grants([{category:'clients',allow:['view','followup']}],s.ledger),400);
  denied(()=>P.collection(s,actor,q({account:'b'}),'detail'),404);
  denied(()=>P.collection(s,actor,q({account:'c'}),'detail'),403);
  denied(()=>P.collection(s,viewOnly,q({}),'csv'),403);
  denied(()=>P.collection(s,actor,q({asOf:day(-1),state:'followup'})),400);
  denied(()=>P.collection(s,actor,q({asOf:day(1)})),400);
  const body={version:s.bookVersion,code:'YER',kind:'review',note:'متابعة اختبارية',day:day(1)};
  denied(()=>P.changeBook(s,viewOnly,'collection-followup','a',body),403);
  denied(()=>P.changeBook(s,actor,'collection-followup','b',body),404);
  denied(()=>P.changeBook(s,actor,'collection-followup','a',{...body,version:'expired'}),409);
  assert.equal(JSON.stringify(s),raw);
  const next=P.changeBook(s,actor,'collection-followup','a',body);
  assert.notEqual(next.version,body.version);
  assert.equal(s.ledger.accounts[0].followups.YER.kind,'review');
  assert.equal(P.collection(s,actor,q({state:'followup'})).total,0);
  assert.deepEqual(s.ledger.entries,JSON.parse(raw).ledger.entries);
  P.changeBook(s,actor,'collection-followup','a',{...body,version:next.version,kind:'',day:'',note:''});
  assert.equal(s.ledger.accounts[0].followups,undefined);
});

test('owner audit filters and pages events and keeps exact before/after movement values',()=>{
  const s=base();const a={...actor,grants:[{category:'clients',allow:['view','editMovement','deleteMovement']}]};
  const update=P.changeBook(s,a,'movement-edit','a0',{version:s.bookVersion,day:day(-3),time:'11:40',amount:'8.125',due:today,memo:'تعديل مراجع'});
  P.changeBook(s,a,'movement-delete','a0',{version:update.version});
  const out=P.auditPage(s,owner,q({type:'movement-edit',q:'موظف التحصيل',from:today,to:today}));
  assert.equal(out.total,1);assert.equal(out.rows[0].versions.before.legs[0].minor,7500);
  assert.equal(out.rows[0].versions.after.legs[0].minor,8125);assert.equal(out.rows[0].versions.after.time,'11:40');
  assert.equal(P.auditPage(s,owner,q({type:'movement-delete'})).rows[0].versions.after,null);
  for(let i=0;i<28;i++)P.log(s,owner,'user-update','حساب تجريبي');
  assert.equal(P.auditPage(s,owner,q({})).rows.length,25);
  assert.equal(P.auditPage(s,owner,q({offset:'25'})).rows.length,5);
  assert.throws(()=>P.auditPage(s,a,q({})),e=>e.status===403);
});
