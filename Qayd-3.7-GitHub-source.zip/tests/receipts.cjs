const {localNav,localCollection}=require('./navigation.cjs');
const {chromium}=require('playwright');
const assert=require('node:assert/strict');
const fs=require('node:fs/promises');
const path=require('node:path');
const os=require('node:os');
const {pathToFileURL}=require('node:url');
const L=require('../app/ledger.js');
const C=require('../app/collections-model.js');
const V=require('../app/vault.js');
const {readContainer}=require('./db-fixtures.cjs');

const today='2026-11-18',day=n=>L.offset(n,today);
const time=new Date(today+'T08:00:00Z');
const url=pathToFileURL(path.resolve(__dirname,'../app/index.html')).href;
const ref='TEST-QR/927184', memo='مذكرة داخلية غير مطبوعة', account='=متجر الفجر', owner='مؤسسة الاختبار';
const currency=code=>`[data-change=currency] option[value=${code}]`;
const clean=s=>s.replace(/[\u2066-\u2069]/g,'');
function fixture(){
  const d=L.empty();d.settings.business=owner;d.currencies[0].name='محلي';d.settings.profile.address='العنوان التجريبي';
  d.accounts=[['A',account,'+967771554001'],['B','مكتبة النخيل','']].map(([id,name,phone])=>({id,name,phone,category:'clients',color:'mint'}));
  function post(id,minor,n,memo,{account='A',code='YER',due}={}){
    d.entries.push({id,day:day(n),time:'10:30',created:1700000000000+d.entries.length,memo,legs:[{account,code,minor}],...(due!==undefined?{due:day(due)}:{})});
  }
  post('old',125125,-110,'دفعة بضاعة قديمة',{due:-75});post('young',200500,-12,'أجهزة مكتبية',{due:-8});
  post('old-payment',-25125,-18,'حركة سداد سابقة');post('sar-lot',350125,-5,'عملة أخرى',{code:'SAR',due:-1});
  post('another',80250,-4,'قيد لعميل آخر',{account:'B'});
  L.closeBalance(d,'A','YER',day(-50));return L.validate(d);
}
(async()=>{
  const out=await fs.mkdtemp(path.join(os.tmpdir(),'qayd-receipts-qa-')),browser=await chromium.launch();
  try{
    const p=await browser.newPage({viewport:{width:393,height:852},hasTouch:true,isMobile:true,timezoneId:'Asia/Aden'});
    p.setDefaultTimeout(8500);const errors=[];p.on('pageerror',e=>errors.push(e.message));
    await p.context().setOffline(true);
    await p.addInitScript(raw=>{
      Object.assign(window,{raw,failWrite:false,docs:[],books:[],files:[],prints:[],sends:[],writes:0});
      window.QaydAndroid={readLedger:()=>window.raw,writeLedger:next=>{if(window.failWrite)return false;window.raw=next;window.writes++;return true;},
        exportPdf:(...args)=>docs.push(args),exportWorkbook:(...args)=>books.push(args),saveFile:(...args)=>files.push(args),
        printPage:title=>prints.push(title),compose:(...args)=>sends.push(args)};
    },JSON.stringify(fixture()));
    await p.clock.install({time});await p.clock.pauseAt(new Date(+time+60000));await p.goto(url);
    const dlg=p.locator('#dialog'),notice=p.locator('#movement-notice'),pane=p.locator('#pdf-dialog');
    const click=(action,root=p,attr='')=>root.locator(`[data-action="${action}"]${attr}:visible`).first().click();
    const nav=view=>localNav(p,view);
    const tab=key=>key==='queue'?nav('collections'):localCollection(p,key);
    const plan=id=>click('collection-account',p,`[data-id=${id}]`);
    const setCode=async code=>{await p.locator(currency(code)).waitFor({state:'attached'});await p.locator('#page [data-change=currency]').selectOption(code);};
    const field=key=>dlg.locator(`[name=${key}]`);
    const filter=key=>p.locator(`[data-scope=collections][data-filter=${key}]`);
    const dayField=field('day'),target=field('receiptTarget'),sum=()=>p.locator('.voucher-ledger-total>bdi').innerText();
    const rows=()=>p.locator('.voucher-row').evaluateAll(els=>els.map(el=>el.dataset.voucher));
    const show=n=>click('voucher-show',p.locator(`[data-voucher="${L.receiptNumber(n)}"]`));
    const close=()=>click('close-dialog',dlg),submit=()=>dlg.locator('button[type=submit]').click();
    const state=()=>p.evaluate(()=>JSON.parse(window.raw));
    const err=()=>dlg.locator('.form-error').innerText();
    const pdfBtn=k=>pane.locator(`[data-pdf-action=${k}]`).click();
    const rendered=()=>pane.locator('.pdf-sheet[data-rendered=true] canvas').first().waitFor({state:'visible',timeout:19000});
    const snapshot=async name=>{if(process.env.QAYD_RECEIPT_SCREENSHOTS)await p.screenshot({path:path.join(out,name+'.png'),animations:'disabled'});};
    const savePdf=async (filename,index,expectedMode)=>{
      const [name,base64,mode]=await p.evaluate(i=>window.docs[i],index);
      assert.equal(name,filename);assert.equal(mode,expectedMode);
      const pdf=Buffer.from(base64,'base64');assert.equal(pdf.subarray(0,4).toString(),'%PDF');
      if(mode==='local')await fs.writeFile(path.join(out,name),pdf);
      return pdf;
    };
    const insert=async({method,amount,when,reference=''}={})=>{
      if(when)await dayField.fill(when);
      await field('receiptMethod').selectOption(method);await field('receiptRef').fill(reference);await field('amount').fill(amount);await submit();
      await dlg.waitFor({state:'hidden'});await click('movement-notice-close',notice);
    };

    await tab('receipts');assert.match(await p.locator('#view-results').innerText(),/لا سندات قبض مطابقة/);
    await tab('queue');await plan('A');assert.equal(await dlg.locator('.collect-lot [data-action=collection-receipt]').count(),2);
    await click('collection-receipt',dlg,'[data-id=young]');
    assert.match(await dlg.locator('[data-destination=phone]').innerText(),/وجهة الحفظ: دفتر الهاتف/);
    assert.match(await dlg.locator('[type=submit]').innerText(),/حفظ في دفتر الهاتف/);
    assert.equal(await field('accountName').inputValue(),account);assert.equal(await field('accountName').evaluate(el=>el.readOnly),true);
    assert.equal(await field('code').isDisabled(),true);assert.equal(await field('code').inputValue(),'YER');
    assert.equal(await target.inputValue(),'young');assert.match(await target.locator('[value=young]').textContent(),/أجهزة مكتبية/);
    assert.match(await dlg.locator('#voucher-room').innerText(),/200\.5 محلي/);
    await dayField.fill(day(+1));assert.equal(await dayField.evaluate(el=>el.validity.rangeOverflow),true);
    await dayField.fill(day(-13));assert.match(await target.locator('[value=young]').textContent(),/بلا متبقٍ/);
    await field('amount').fill('1');await submit();assert.match(await err(),/لا يتبقى مبلغ لهذا القيد/);
    await dayField.fill(today);await field('amount').fill('201');await submit();assert.match(await err(),/أكبر من المتبقي/);
    assert.equal((await state()).receiptSerial,undefined);assert.equal(await notice.isVisible(),false);
    await dlg.locator('#voucher-extra > summary').click();await field('time').fill('11:11');await field('receiptMethod').selectOption('bank');await field('amount').fill('60.125');
    await field('receiptRef').fill(ref);await field('memo').fill(memo);
    const initial=await state();await p.evaluate(()=>window.failWrite=true);await submit();assert.match(await err(),/لم تُحفظ/);
    assert.deepEqual(await state(),initial);assert.equal(await notice.isVisible(),false);assert.equal(await p.evaluate(()=>writes),0);
    await p.evaluate(()=>window.failWrite=false);await submit();await dlg.waitFor({state:'hidden'});
    assert.match(await notice.innerText(),/000001.*دفتر الهاتف/s);assert.deepEqual(await notice.getByRole('button').allTextContents(),['إغلاق','إرسال']);
    await p.clock.runFor(2999);assert.equal(await notice.isVisible(),true);await p.clock.runFor(1);assert.equal(await notice.isVisible(),false);
    assert.equal(await p.evaluate(()=>sends.length+docs.length),0);await p.clock.resume();
    const r=(await state()).entries.at(-1);assert.deepEqual(r.receipt,{number:1,method:'bank',reference:ref,target:'young'});
    assert.deepEqual(r.legs,[{account:'A',code:'YER',minor:-60125}]);
    const a=async()=>C.snapshot(await state(),'YER',today).index.get('A');
    assert.deepEqual((await a()).items.map(x=>[x.id,x.open]),[['old',100000],['young',140375]]);
    await click('open-account',p,'[data-id=A]');await click('collection-receipt');assert.equal(await target.inputValue(),'');
    await insert({method:'wallet',amount:'20.250',when:day(-1)});assert.equal((await a()).total,220125);
    await nav('collections');await setCode('SAR');await plan('A');await click('collection-receipt',dlg,':not([data-id])');
    await insert({method:'check',amount:'10.125'});assert.equal((await state()).receiptSerial,3);
    await tab('receipts');assert.deepEqual(await rows(),['000003']);assert.equal(await sum(),'10.125');
    await setCode('YER');assert.deepEqual(await rows(),['000001','000002']);assert.equal(await sum(),'80.375');
    assert.doesNotMatch(await p.locator('.voucher-register').innerText(),new RegExp(ref));
    await filter('receiptFrom').fill(today);await filter('receiptTo').fill(day(-1));assert.match(await p.locator('#view-results').innerText(),/صحّح نطاق/);
    await filter('receiptFrom').fill(day(-1));assert.deepEqual(await rows(),['000002']);assert.equal(await sum(),'20.25');
    await filter('paymentMethod').selectOption('cash');assert.deepEqual(await rows(),[]);
    await filter('paymentMethod').selectOption('wallet');assert.deepEqual(await rows(),['000002']);
    await click('reset-filter');await filter('receiptQuery').fill('#٠٠٠٠٠١');assert.deepEqual(await rows(),['000001']);
    await filter('receiptQuery').fill('النخيل');assert.deepEqual(await rows(),[]);
    await filter('receiptQuery').fill('الفجر');assert.deepEqual(await rows(),['000001','000002']);await filter('receiptQuery').fill('');

    for(const width of [280,320,393,550,740,900,1200]){
      await p.setViewportSize({width,height:852});
      assert.equal(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),true,`register horizontal fit ${width}`);
      if(width===1200)await snapshot('register-wide');
    }
    await p.setViewportSize({width:393,height:852});await snapshot('register-mobile');
    await filter('receiptFrom').fill(today);await filter('receiptTo').fill(today);await filter('paymentMethod').selectOption('bank');
    assert.equal(await sum(),'60.125');assert.deepEqual(await rows(),['000001']);
    await click('export-options',p,'[data-target=receipt-register]');await click('csv',dlg);
    const [csvName,mime,csv]=await p.evaluate(()=>window.files[0]);assert.equal(csvName,`qayd-report-receipts-YER-${today}.csv`);assert.equal(mime,'text/csv');
    assert.match(csv,/"#000001","2026-11-18","'=متجر الفجر","تحويل بنكي",60\.125/);
    assert.match(csv,/إجمالي السندات المطابقة",60\.125/);
    assert.doesNotMatch(csv,/000002|TEST-QR|771554001|مذكرة داخلية/);await fs.writeFile(path.join(out,csvName),csv);
    await click('export-options',p,'[data-target=receipt-register]');await click('xlsx',dlg);
    await p.waitForFunction(()=>books.length===1);
    const [book,b64,mode]=await p.evaluate(()=>books[0]);assert.equal(mode,'local');assert.equal(book,`qayd-report-receipts-YER-${today}.xlsx`);
    const bookBytes=Buffer.from(b64,'base64');assert.equal(bookBytes.subarray(0,2).toString(),'PK');await fs.writeFile(path.join(out,book),bookBytes);
    await click('export-options',p,'[data-target=receipt-register]');await click('view-pdf',dlg,'[data-target=receipt-register]');await rendered();await pdfBtn('save');
    await savePdf(`qayd-report-receipts-YER-${today}.pdf`,0,'local');await pdfBtn('close');

    await show(1);assert.match(await dlg.locator('.voucher-banner').innerText(),/#000001[\s\S]*60\.125 محلي/);
    assert.match(await dlg.locator('.voucher-facts').innerText(),/TEST-QR\/927184/);await snapshot('receipt-mobile');
    assert.equal(await p.evaluate(()=>docs.length),1);assert.equal(await p.evaluate(()=>sends.length),0);
    await click('view-pdf',dlg);await rendered();assert.equal(await pane.locator('#pdf-currency').inputValue(),'YER');
    assert.equal(await pane.locator('#pdf-currency').isDisabled(),true);assert.equal(await pane.locator('.pdf-sheet').count(),1);
    const filename=`qayd-report-receipt-000001-YER-${today}.pdf`;
    await pdfBtn('save');const bytes=await savePdf(filename,1,'local');await pdfBtn('share');assert.deepEqual(await savePdf(filename,2,'share'),bytes);
    await snapshot('receipt-pdf');await pdfBtn('close');assert.equal(await dlg.isVisible(),true);
    await click('view-pdf',dlg);await rendered();await pdfBtn('print');await p.waitForFunction(()=>prints.length===1);
    assert.match(await p.locator('#print-area').textContent(),/توقيع المستلم/);assert.match(await p.locator('#print-area .final-ending').textContent(),/60\.125/);
    assert.doesNotMatch(await p.locator('#print-area').textContent(),/مذكرة داخلية|771554001|بضاعة قديمة/);await pdfBtn('close');
    await show(1);await click('draft-recipients',dlg);
    assert.equal(clean(await dlg.locator('#draft-message').inputValue()),`إشعار من ${owner}:\nلك 60.125 محلي واصل\nالإجمالي - عليك 220.125 محلي`);
    assert.equal(await p.evaluate(()=>sends.length),0);await close();

    await show(1);await click('edit-entry',dlg);await snapshot('receipt-edit');
    assert.equal(await target.inputValue(),'young');assert.match(await dlg.locator('#voucher-room').innerText(),/200\.5 محلي/);
    await field('amount').fill('80.125');await field('receiptRef').fill('PRIVATE-REV-20');await submit();
    assert.match(await dlg.locator('.voucher-banner').innerText(),/#000001[\s\S]*80\.125/);assert.equal(await notice.isVisible(),false);
    assert.equal((await state()).receiptSerial,3);assert.equal((await a()).total,200125);
    await click('entry-info',dlg,'[data-id=young]');assert.match(await dlg.locator('.voucher-link-notice').innerText(),/عرض السندات المخصّصة/);
    const before=await state();await click('delete-entry',dlg);await submit();assert.match(await err(),/ألغِ التخصيص/);assert.deepEqual(await state(),before);await close();
    await nav('moves');await click('entry-info',p,'[data-id=young]');await click('voucher-linked',dlg);
    assert.equal(await p.locator('.voucher-filter-tag').isVisible(),true);assert.deepEqual(await rows(),['000001']);
    await click('voucher-clear-linked');assert.deepEqual(await rows(),['000001','000002']);
    // Delete the second receipt, keep the number reserved, then verify a new receipt in another currency.
    await show(2);await click('delete-entry',dlg);assert.match(await dlg.locator('.notice').innerText(),/لن يُعاد استخدام الرقم/);
    await submit();assert.equal((await state()).receiptSerial,3);assert.deepEqual(await rows(),['000001']);assert.equal((await a()).total,220375);
    await tab('queue');await setCode('SAR');await plan('A');await click('collection-receipt',dlg,':not([data-id])');
    await insert({method:'other',amount:'5'});assert.equal((await state()).receiptSerial,4);
    assert.equal((await state()).entries.at(-1).receipt.number,4);

    await setCode('YER');await click('open-account',p,'[data-id=A]');await click('account-options',p,'[data-id=A]');
    await click('close-balance',dlg);await dayField.fill(today);await submit();
    assert.equal(L.isLocked(await state(),r.id),true);
    await tab('receipts');await show(1);
    assert.match(await dlg.locator('.notice').innerText(),/السند مؤرشف/);assert.equal(await dlg.locator('[data-action=edit-entry],[data-action=delete-entry]').count(),0);
    const beforeUnlink=await state();const reportBefore=(await a()).items.map(x=>[x.id,x.open]);
    await click('voucher-unassign',dlg);await submit();
    assert.match(await dlg.locator('.voucher-facts').innerText(),/توزيع على الأقدم/);
    const afterUnlink=await state();assert.deepEqual(afterUnlink.closures,beforeUnlink.closures);
    assert.deepEqual(afterUnlink.entries.find(e=>e.id===r.id).legs,r.legs.map(l=>({...l,minor:-80125})));
    assert.equal(afterUnlink.entries.find(e=>e.id===r.id).receipt.target,undefined);
    assert.equal((await a()).total,220375);assert.notDeepEqual((await a()).items.map(x=>[x.id,x.open]),reportBefore);
    await close();await tab('activity');const audit=await p.locator('.audit-feed').innerText();
    assert.match(audit,/#000001/);assert.match(audit,/أُلغي التخصيص/);assert.doesNotMatch(audit,/PRIVATE-REV-20|TEST-QR|مذكرة داخلية/);

    const plain=await state(),db=path.join(out,'qayd-receipts-synthetic.db');
    await fs.writeFile(db,Uint8Array.from(await p.evaluate(async()=>Array.from(await QaydDb.write(window.raw)))));
    assert.deepEqual(L.validate(readContainer(db)),L.validate(plain));
    await p.locator('#backup-file').setInputFiles(db);await dlg.getByRole('heading',{name:'استرجاع واستبدال البيانات'}).waitFor();await submit();
    assert.deepEqual(await state(),plain);await tab('receipts');assert.deepEqual(await rows(),['000001']);
    await nav('settings');await p.locator('.settings-tile[data-key=security]').click();await click('password-change');
    const pass='synthetic only #9257';await field('pass').fill(pass);await field('again').fill(pass);await submit();
    await p.locator('[data-action=lock-now]').waitFor();const sealed=await state();assert.ok(V.is(sealed));
    assert.doesNotMatch(JSON.stringify(sealed),/PRIVATE-REV-20|متجر الفجر/);assert.deepEqual((await V.unlock(sealed,pass)).value.entries,plain.entries);
    assert.equal((await V.unlock(sealed,pass)).value.receiptSerial,4);
    await click('lock-now');assert.equal(await p.locator('#page').textContent(),'');assert.equal(await p.evaluate(()=>sends.length),0);
    assert.deepEqual(errors,[]);

    // Browser without a native bridge: the receipt is still downloadable offline.
    const web=await browser.newPage({viewport:{width:390,height:820},isMobile:true,acceptDownloads:true,timezoneId:'Asia/Aden'});
    await web.context().setOffline(true);await web.addInitScript(raw=>localStorage.setItem('qayd.ledger.v1',raw),JSON.stringify(plain));await web.goto(url);
    await localCollection(web,'receipts');
    await click('voucher-show',web);await click('view-pdf',web.locator('#dialog'));
    await web.locator('#pdf-dialog canvas').first().waitFor({state:'visible',timeout:19000});
    const downloaded=await Promise.all([web.waitForEvent('download'),web.locator('#pdf-save').click()]).then(x=>x[0]);
    assert.equal(downloaded.suggestedFilename(),filename);const browserPdf=await fs.readFile(await downloaded.path());assert.equal(browserPdf.subarray(0,4).toString(),'%PDF');
    console.log('Receipts: targeted allocation, exact numbering and rollback, date/method/currency filters, offline PDF save/share/print and download, archive/unlink/delete, audit and DB/encrypted restore passed. Synthetic outputs:',out);
  }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
