package app.qayd.ledger;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;
import java.util.Arrays;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.AEADBadTagException;

/** Desktop relay for the compiled Android transport, with synthetic HTTPS accounts only. */
public final class SharedDeskBridgeHarness {
    private static final String VERSION="3906a1f2-a099-4aef-8fee-18dc8cf54dd4";
    private static void check(boolean value){if(!value)throw new AssertionError("shared desk route contract");}
    private static void denied(String route,String body,boolean passive)throws Exception{
        try{DeskRoute.parse(route,body,passive);}catch(Exception e){return;}
        throw new AssertionError("unexpected route or request schema");
    }
    private static void contract()throws Exception{
        for(String path:new String[]{"info","status","me","desk?code=YER","movements?code=SAR&account=acct_1&offset=40","report?category=","collection?state=overdue","collection/detail?account=old-acc-17","users","audit?type=password-change","report.csv?code=YER","collection.csv?code=USD"}){
            DeskRoute r=DeskRoute.parse(path,"",true);check(r.path.equals("/api/"+path)&&r.passive&&!r.post&&!r.issue);
        }
        DeskRoute edit=DeskRoute.parse("book/change",new JSONObject().put("action","category-edit").put("id","clients").put("fields",new JSONObject().put("version",VERSION).put("name","عملاء الاختبار")).toString(),false);
        check(edit.post&&!edit.issue&&!edit.csv&&edit.body.contains("clients"));
        check(DeskRoute.parse("password","{\"current\":\"old\",\"password\":\"new\"}",false).issue);
        check(DeskRoute.parse("login","{\"login\":\"qa.staff\",\"password\":\"synthetic\"}",false).issue);
        check(DeskRoute.parse("report.csv","",false).csv);
        denied("https://unconfigured.example.test/api/info","",false);
        denied("book/backup","",false);denied("book/import","{}",false);
        denied("book/transfer-review","{}",false);denied("book/transfer-commit","{}",false);denied("recovery/export","{}",false);
        denied("desk?unknown=1","",false);denied("desk?code=YER&code=SAR","",false);
        denied("login","{\"login\":\"qa.staff\",\"password\":\"test\"}",true);
        denied("book/change","{\"action\":\"account-delete\",\"id\":\"a\",\"fields\":{}}",false);
        check(SharedDeskClient.ticket("desk-17")&&!SharedDeskClient.ticket("wrong-ticket"));
        check(DeviceRole.initial("",false,false).isEmpty());
        check(DeviceRole.MANAGER.equals(DeviceRole.initial("",true,false))&&DeviceRole.MANAGER.equals(DeviceRole.initial("",false,true)));
        check(DeviceRole.STAFF.equals(DeviceRole.initial(DeviceRole.STAFF,true,true)));
        String host="https://test-ledger.example.test",other="https://other-ledger.example.test";
        check(host.equals(DeviceRole.staffOrigin(DeviceRole.STAFF,"https://TEST-ledger.example.test:443/")));
        check(!DeviceRole.sameBinding(DeviceRole.MANAGER,host,host)&&!DeviceRole.sameBinding(DeviceRole.STAFF,host,other));
        KeyGenerator g=KeyGenerator.getInstance("AES");g.init(256);SecretKey key=g.generateKey();
        StaffLogin account=new StaffLogin("qa.staff","Synthetic-only-staff-123",VERSION);
        byte[] a=account.seal(key,host),b=account.seal(key,host);
        check(!Arrays.equals(a,b)&&!new String(a,StandardCharsets.ISO_8859_1).contains(account.password));
        StaffLogin restored=StaffLogin.open(key,host,a);
        check(restored.user.equals(account.user)&&restored.login.equals(account.login)&&restored.password.equals(account.password));
        try{StaffLogin.open(key,other,a);throw new AssertionError("accepted a different origin");}catch(AEADBadTagException good){}
        a[a.length-1]^=1;try{StaffLogin.open(key,host,a);throw new AssertionError("accepted a changed envelope");}catch(AEADBadTagException good){}
        System.out.println("Shared desk contract: fixed API, native device role, sealed staff login with origin binding, validated versions and no offline import/backup.");
    }
    private static void reply(String lane,String id,int status,String value){
        try{System.out.println(new JSONObject().put("lane",lane).put("ticket",id).put("status",status).put("value",new JSONObject(value)));}
        catch(Exception e){throw new IllegalStateException("invalid native response",e);}
    }
    private static final class TestKeeper implements StaffLogin.Keeper {
        final String origin;final SecretKey key;byte[] sealed;int writes;
        TestKeeper(String origin)throws Exception{this.origin=origin;KeyGenerator gen=KeyGenerator.getInstance("AES");gen.init(256);key=gen.generateKey();}
        public boolean available(){return true;}
        public synchronized boolean has(){return sealed!=null;}
        public synchronized StaffLogin read(){try{return StaffLogin.open(key,origin,sealed);}catch(Exception failed){return null;}}
        public synchronized boolean write(StaffLogin value){try{sealed=value.seal(key,origin);writes++;return true;}catch(Exception failed){return false;}}
        public synchronized boolean forget(){sealed=null;return true;}
    }
    public static void main(String[] args)throws Exception{
        System.setOut(new PrintStream(System.out,true,"UTF-8"));
        if(args.length==0){contract();return;}
        if(args.length!=1||!args[0].equals("relay"))throw new IllegalArgumentException("relay");
        Map<String,SharedDeskClient> clients=new HashMap<>();Map<String,TestKeeper> vaults=new HashMap<>();
        try(BufferedReader in=new BufferedReader(new InputStreamReader(System.in,StandardCharsets.UTF_8))){
            String line;
            while((line=in.readLine())!=null){
                JSONObject q=new JSONObject(line);String lane=q.getString("lane"),ticket=q.getString("ticket");
                if(q.optBoolean("clear")){
                    SharedDeskClient old=clients.get(lane);if(old!=null)old.clear();reply(lane,ticket,204,"{}");continue;
                }
                if(q.optBoolean("recreate")){
                    SharedDeskClient old=clients.remove(lane);if(old!=null)old.close();reply(lane,ticket,204,"{}");continue;
                }
                if(q.optBoolean("vaultState")||q.optBoolean("forget")){
                    TestKeeper v=vaults.get(lane);if(v!=null&&q.optBoolean("forget"))v.forget();
                    reply(lane,ticket,200,new JSONObject().put("stored",v!=null&&v.has()).put("writes",v==null?0:v.writes).toString());continue;
                }
                SharedDeskClient client=clients.get(lane);
                if(client==null){
                    String origin=q.getString("origin");TestKeeper v=null;
                    if(q.optBoolean("employee")){v=vaults.get(lane);if(v==null||!v.origin.equals(origin)){v=new TestKeeper(origin);vaults.put(lane,v);}}
                    client=new SharedDeskClient(origin,v);clients.put(lane,client);
                }
                client.request(ticket,q.getString("route"),q.optString("body",""),q.optBoolean("passive"),q.optBoolean("remember"),(id,status,value)->reply(lane,id,status,value));
            }
        }finally{clients.values().forEach(SharedDeskClient::close);}
    }
}
