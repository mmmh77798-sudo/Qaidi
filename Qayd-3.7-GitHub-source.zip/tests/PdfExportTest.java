package app.qayd.ledger;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.nio.file.Files;
import java.nio.file.Paths;

/** JVM contract checks; optionally include PDF bytes created by the browser test. */
public final class PdfExportTest {
    static void require(boolean condition) { if(!condition)throw new AssertionError(); }
    public static void main(String[] args)throws Exception {
        String name="qayd-statement-LOC-2025-03-01.pdf";
        byte[] bytes="%PDF-1.3\n...\n%%EOF\r\n".getBytes(StandardCharsets.US_ASCII);
        String encoded=Base64.getEncoder().encodeToString(bytes);
        require(PdfExport.request(name,encoded,"local"));
        require(PdfExport.pdfHeaderAndTrailer(bytes));
        require(PdfExport.request(name,encoded,"share"));
        require(PdfExport.request("qayd-report-receipt-000001-YER-2026-11-18.pdf",encoded,"local"));
        require(PdfExport.request("qayd-report-receipts-SAR-2026-11-18.pdf",encoded,"share"));
        require(!PdfExport.request(name,encoded,"drive"));
        require(!PdfExport.request("qayd-report-../a.pdf",encoded,"share"));
        require(!PdfExport.request("qayd-backup-LOC-2025-03-01.pdf",encoded,"share"));
        require(!PdfExport.request(name,"", "local"));
        require(!PdfExport.request(name,encoded+"a", "local"));
        require(!PdfExport.pdfHeaderAndTrailer("SQLite format 3\n%%EOF".getBytes(StandardCharsets.US_ASCII)));
        require(!PdfExport.pdfHeaderAndTrailer("%PDF-1.7\ntruncated\n".getBytes(StandardCharsets.US_ASCII)));
        require(!PdfExport.pdfHeaderAndTrailer(new byte[PdfExport.MAX_BYTES+1]));
        for(String path:args){
            byte[] pdf=Files.readAllBytes(Paths.get(path));
            require(PdfExport.pdfHeaderAndTrailer(pdf));
            require(PdfExport.request(Paths.get(path).getFileName().toString(),Base64.getEncoder().encodeToString(pdf),"share"));
        }
        System.out.println("PDF export envelope, type/length/mode and filename tests passed.");
    }
}
