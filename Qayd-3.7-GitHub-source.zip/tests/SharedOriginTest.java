package app.qayd.ledger;

public final class SharedOriginTest {
    public static void main(String[] args) {
        for(String value:new String[]{"https://ledger.example.test","https://ledger.example.test:8443/","https://[2001:db8::1]"}) {
            if(!value.equals(SharedOrigin.verify(value)))throw new AssertionError(value);
        }
        for(String value:new String[]{null,"","http://ledger.example.test","javascript:alert(1)","intent://ledger.example.test","file:///tmp/qayd","https://owner@ledger.example.test","https://ledger.example.test/login","https://ledger.example.test/?password=x","https://ledger.example.test/#data","https://ledger.example.test:0","https://ledger.example.test:99999","https://ledger.example.test/%2f","https://ledger.example.test\\path","https://ledger.example.test\n"}) {
            if(SharedOrigin.verify(value)!=null)throw new AssertionError(String.valueOf(value));
        }
        System.out.println("Shared team address: HTTPS origin only, no credentials, path or tokens.");
    }
}
