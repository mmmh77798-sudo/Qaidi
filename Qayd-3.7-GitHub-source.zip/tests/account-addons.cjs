/* Synthetic Android-shaped account actions; no outgoing messages or physical print jobs. */
const {chromium}=require('playwright');
const assert=require('node:assert/strict');
const fs=require('node:fs/promises');
const os=require('node:os');
const path=require('node:path');
const {pathToFileURL}=require('node:url');
const {execFileSync}=require('node:child_process');
const {readContainer}=require('./db-fixtures.cjs');
const L=require('../app/ledger.js');
const Q=require('../app/xlsx.js');
const S=require('../app/report-totals.js');
const atFile=pathToFileURL(path.join(__dirname,'../app/index.html')).href;
const short=s=>s.replace(/[\u2066-\u2069]/g,'');
function create(){
  const d=L.empty();d.currencies[0]={code:'LOC',name:'محلي',symbol:'م'};d.settings.defaultCode='LOC';
  d.accounts=[{id:'client',name:'عميل اختبار الرسائل',phone:'+12025550101'},{id:'other',name:'حساب اختبار مستقل'}];
  const post=(id,day,memo,...legs)=>d.entries.push({id,day,memo,time:'11:00',created:d.entries.length,legs});
  const leg=(account,minor,code='LOC')=>({account,code,minor});
  post('opening','2025-01-09','رصيد قبل الفترة',leg('client',1000125));
  post('signed','2025-02-01','=SUM(1,2) & حركة اختبار',leg('client',-2100250));
  post('small','2025-02-02','إضافة بسيطة',leg('client',10125));
  post('transfer','2025-02-03','تحويل داخلي',leg('client',-5501),leg('other',5501));
  post('future','2028-04-22','ليس ضمن التاريخ',leg('client',-1001));
  post('sar','2025-02-04','حركة مستقلة',leg('client',45125,'SAR'));
  return L.validate(d);
}
const pythonCheck=`
import sys, zipfile, xml.etree.ElementTree as ET
n={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
with zipfile.ZipFile(sys.argv[1]) as z:
 assert z.testzip() is None
 assert set(z.namelist()) == {'[Content_Types].xml','_rels/.rels','xl/workbook.xml','xl/_rels/workbook.xml.rels','xl/styles.xml','xl/worksheets/sheet1.xml'}
 sheet=ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
 assert sheet.find('.//m:sheetView',n).get('rightToLeft')=='1'
 assert sheet.find('.//m:pane',n) is not None
 assert not sheet.findall('.//m:f',n)
 assert any(t.text=='=SUM(1,2) & حركة اختبار' for t in sheet.findall('.//m:t',n))
 assert any(t.text=='ملخص نهاية التقرير' for t in sheet.findall('.//m:t',n))
 nums=[t.text for t in sheet.findall('.//m:v',n)]
 assert '-2100.250' in nums and '-1095.501' in nums and '1000.125' in nums,nums
 assert '-5.501' not in nums and '10.125' not in nums
`;
(async()=>{
 const browser=await chromium.launch({headless:true,args:['--no-sandbox']});
 const out=await fs.mkdtemp(path.join(os.tmpdir(),'qayd-addons-qa-'));
 try{
  const p=await browser.newPage({viewport:{width:393,height:852},hasTouch:true,isMobile:true});p.setDefaultTimeout(9000);
  const errors=[];p.on('pageerror',e=>errors.push(e.message));p.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
  await p.context().setOffline(true);
  const initial=create();
  await p.addInitScript(raw=>{
    window.sent=[];window.exportsBooks=[];window.heat=[];window.systemReceipts=[];window.prints=[];window.raw=raw;window.writeCount=0;
    window.QaydAndroid={readLedger:()=>window.raw,writeLedger:next=>{window.raw=next;window.writeCount++;return true;},
      compose:(medium,number,text,business)=>window.sent.push({medium,number,text,business}),
      exportWorkbook:(name,encoded,mode)=>window.exportsBooks.push({name,encoded,mode}),
      printThermal:(width,height,pixels)=>window.heat.push({width,height,pixels}),
      printReceipt:(title,width)=>window.systemReceipts.push({title,width}),printPage:title=>window.prints.push(title),
      copyText:txt=>{window.copied=txt;}};
  },JSON.stringify(initial));
  await p.goto(atFile);
  const nav=v=>p.locator(`#mobilebar [data-view="${v}"]`).click();
  const modal=p.locator('#dialog'),theirs=p.locator('#view-results'),msg=p.locator('#draft-message');
  const click=(action,scope=p,extra='')=>scope.locator(`[data-action="${action}"]${extra}:visible`).first().click();
  const close=()=>click('close-dialog',modal);
  const menu=()=>click('account-options',p);
  const submit=()=>modal.locator('button[type=submit]').click();
  const field=id=>modal.locator(`[name="${id}"]`);
  const goto=async id=>{await nav('accounts');await p.locator(`[data-action=open-account][data-id="${id}"]:visible`).first().click();};
  const quick=async ch=>{await menu();await click('balance-message',modal,`[data-channel=${ch}][data-key=balance]`);};
  const state=()=>p.evaluate(()=>JSON.parse(window.raw));
  await goto('client');
  const to=p.locator('[data-scope=statement][data-filter=to]');await to.fill('2025-02-28');
  await p.locator('[data-scope=statement][data-filter=query]').fill('لن يطابق البحث');
  await quick('sms');let draft=short(await msg.inputValue());
  assert.equal(draft,'رصيدك حتى 2025-02-28: -1,095.501 محلي (لك).');
  assert.ok(draft.length<70);
  assert.doesNotMatch(draft,/SUM|تحويل|أرشيف|عميل اختبار/);
  assert.equal(await p.evaluate(()=>window.sent.length),0);
  await click('copy-draft',modal);assert.equal(short(await p.evaluate(()=>window.copied)),draft);
  await click('compose-message',modal,'[data-channel=sms]');
  let sent=await p.evaluate(()=>window.sent);assert.equal(sent[0].medium,'sms');assert.equal(sent[0].number,'+12025550101');assert.equal(short(sent[0].text),draft);
  await close();await quick('wa');assert.equal(short(await msg.inputValue()),draft);
  await click('compose-message',modal,'[data-channel=wa]');await close();
  await menu();await click('balance-message',modal,'[data-channel=both]');
  assert.equal(await modal.locator('[data-action=compose-message]').count(),2);
  await msg.fill('رصيد مختصر مراجع');assert.ok((await modal.locator('#draft-chars').innerText()).includes(String([...('رصيد مختصر مراجع')].length)));
  await click('compose-message',modal,'[data-channel=sms]');await click('compose-message',modal,'[data-channel=wa]');
  sent=await p.evaluate(()=>window.sent);assert.deepEqual(sent.map(x=>x.medium),['sms','wa','sms','wa']);
  assert.equal(sent[2].text,'رصيد مختصر مراجع');assert.equal(sent[3].text,sent[2].text);
  await close();await menu();await click('balance-message',modal,'[data-key=confirmation]');
  assert.match(short(await msg.inputValue()),/تأكيد رصيدك.*-1,095\.501 محلي.*موافق/);
  assert.equal(await p.evaluate(()=>window.sent.length),4);
  await close();await goto('other');await quick('wa');
  assert.equal(await modal.locator('[data-action=compose-message]').isDisabled(),true);
  await click('message-phone',modal);await field('phone').fill('123');await submit();
  assert.match(await modal.locator('.form-error').innerText(),/رقمًا صحيحًا/);
  await field('phone').fill('+12025550102');await submit();
  assert.equal(await modal.locator('#draft-phone').inputValue(),'+12025550102');
  assert.match(short(await msg.inputValue()),/5\.501 محلي/);
  assert.equal(await p.evaluate(()=>window.sent.length),4);await close();await goto('client');
  // A single signed row matches the advanced search, while the closing balance remains real.
  await click('statement-search');await field('from').fill('2025-02-01');await field('to').fill('2025-02-28');
  await field('kind').selectOption('debit');await field('min').fill('2,100.250');await field('max').fill('2,100.249');await submit();
  assert.match(await modal.locator('.form-error').innerText(),/المبلغ الأدنى/);
  await field('max').fill('٢١٠٠٫٢٥٠');await submit();
  assert.equal(await theirs.locator('tbody tr').count(),1);
  assert.match(await theirs.locator('.final-net dd').innerText(),/-2,100\.25/);
  assert.match(await theirs.locator('.final-ending dd').innerText(),/-1,095\.501/);
  assert.match(await p.locator('.statement-filter-strip').innerText(),/عليّ/);
  const exportmenu=()=>click('export-options',p,'[data-target=statement]');
  await exportmenu();await click('xlsx',modal);await p.waitForFunction(()=>window.exportsBooks.length===1);
  await exportmenu();await click('xlsx-share',modal);await p.waitForFunction(()=>window.exportsBooks.length===2);
  const [save,share]=await p.evaluate(()=>window.exportsBooks);assert.equal(save.mode,'local');assert.equal(share.mode,'share');
  assert.equal(save.encoded,share.encoded);assert.match(save.name,/^qayd-statement-LOC-.*\.xlsx$/);
  const file=path.join(out,save.name);await fs.writeFile(file,Buffer.from(save.encoded,'base64'));execFileSync('python3',['-c',pythonCheck,file]);
  // Both receipt formats use the filter and the same currency, without touching the ledger.
  await exportmenu();await click('thermal-print',modal);await field('paper').selectOption('80-512');await field('format').selectOption('rows');await submit();
  await p.waitForFunction(()=>window.heat.length===1);
  const heat=await p.evaluate(()=>window.heat[0]),raw=Buffer.from(heat.pixels,'base64');
  assert.equal(heat.width,512);assert.equal(raw.length,(heat.width/8)*heat.height);assert.ok(heat.height>350&&heat.height<7040);
  assert.ok(raw.filter(x=>x!==0).length>1400);await fs.writeFile(path.join(out,'thermal-512.bin'),raw);
  await exportmenu();await click('thermal-print',modal);await field('paper').selectOption('58');await click('thermal-system',modal);await p.waitForFunction(()=>window.systemReceipts.length===1);
  assert.equal(await p.evaluate(()=>window.systemReceipts[0].width),58);
  assert.match(await p.locator('#print-area').textContent(),/ملخص نهاية التقرير/);
  assert.match(await p.locator('#print-area').textContent(),/-1,095\.501/);
  assert.equal(await p.locator('#print-area[data-receipt="58"] .thermal-record').count(),0);
  await exportmenu();await click('print',modal,'[data-target=statement]');await p.waitForFunction(()=>window.prints.length===1);
  assert.equal(await p.locator('#print-area').getAttribute('data-receipt'),null);

  // Exact threshold, pre-save warning, crossing notification, and no blocking.
  await menu();await click('account-limit',modal);await field('direction').selectOption('debit');await field('limit').fill('1,100');await submit();
  const card=p.locator('.account-limit-card');assert.equal(await card.getAttribute('data-limit-state'),'below');
  assert.deepEqual((await state()).accounts[0].limits,{LOC:{minor:1100000,direction:'debit'}});
  const enterDebit=async amount=>{
    await click('new-entry',p,'[data-account=client]');
    await modal.locator('label:has([name=kind][value=debit])').click();await field('amount').fill(amount);
    assert.match(await modal.locator('#entry-limit-preview').innerText(),/سيبلغ السقف|سيتجاوز السقف/);
    await submit();await modal.waitFor({state:'hidden'});
  };
  await enterDebit('3.498');assert.equal(await card.getAttribute('data-limit-state'),'reached');
  await enterDebit('1.001');assert.equal(await card.getAttribute('data-limit-state'),'exceeded');
  assert.match(await p.locator('#toast').innerText(),/تجاوز السقف/);
  assert.equal((await state()).entries.at(-1).legs[0].minor,-1001);
  await p.locator('[data-change=currency]').selectOption('SAR');assert.equal(await card.count(),0);
  await menu();await click('account-limit',modal);await field('limit').fill('45.125');await submit();
  assert.equal(await card.getAttribute('data-limit-state'),'reached');
  await quick('sms');assert.match(short(await msg.inputValue()),/45\.125 ريال سعودي/);assert.doesNotMatch(short(await msg.inputValue()),/محلي/);await close();
  await menu();await click('account-reminder',modal);await field('reminder').fill(L.offset(2));await submit();
  let d=await state();assert.equal(d.accounts[0].reminder,L.offset(2));assert.equal(d.accounts[0].limits.SAR.minor,45125);
  const db=path.join(out,'qayd-synthetic-limits.db');
  await fs.writeFile(db,Buffer.from(await p.evaluate(async()=>Array.from(await QaydDb.write(window.raw)))));
  assert.deepEqual(readContainer(db).accounts[0].limits,d.accounts[0].limits);
  await menu();await click('account-limit',modal);await field('limit').fill('');await submit();
  assert.equal(await card.count(),0);assert.equal((await state()).accounts[0].limits.LOC.minor,1100000);
  assert.equal(await p.evaluate(()=>window.sent.length),4);assert.deepEqual(errors,[]);

  // Check the OOXML store fallback in addition to browser compression.
  const example={type:'statement',title:'اختبار',currency:{name:'محلي',code:'LOC'},cols:['التاريخ','التفاصيل','النوع','المبلغ','الرصيد'],notes:['العملة: محلي'],rows:[],summary:{credit:0,debit:0,net:0,note:''}};
  const Compression=globalThis.CompressionStream;globalThis.CompressionStream=undefined;
  try{const bytes=await Q.build(example,L.decimal,S.fields(example.summary));assert.equal(new DataView(bytes.buffer).getUint32(0,true),0x04034b50);await fs.writeFile(path.join(out,'store-fallback.xlsx'),bytes);}
  finally{globalThis.CompressionStream=Compression;}
  console.log('Account additions passed: visible short SMS/WhatsApp, shared draft and approval text, advanced filters, typed workbook, receipt bitmap, system print, ceilings and DB persistence. Synthetic outputs:',out);
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
