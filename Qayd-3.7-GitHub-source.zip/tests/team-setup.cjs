'use strict';
const assert=require('node:assert/strict');
const {chromium}=require('playwright');
const path=require('node:path');
const {pathToFileURL}=require('node:url');
const {fixture}=require('./category-fixtures.cjs');
const u=pathToFileURL(path.resolve(__dirname,'../app/index.html')).href;
(async()=>{
  const browser=await chromium.launch();
  try{
    const p=await browser.newPage({viewport:{width:393,height:852},isMobile:true,hasTouch:true});
    const errors=[];p.on('pageerror',e=>errors.push(e.message));await p.context().setOffline(true);
    await p.addInitScript(raw=>{
      window.opened=[];window.saved=[];window.teamCalls=[];window.copied=[];
      window.open=(...args)=>opened.push(args);
      window.QaydAndroid={readLedger:()=>raw,writeLedger:(...args)=>{saved.push(args);return true;},teamRequest:(...args)=>teamCalls.push(args),teamClear:()=>{},copyText:s=>copied.push(s)};
    },JSON.stringify(fixture()));
    const enter=async()=>{await p.locator('[data-action=go][data-view=settings]:visible').first().click();await p.locator('[data-action=settings-open][data-key=shared]').click();};
    await p.goto(u);await enter();
    const form=p.locator('#team-origin-form'),address=form.locator('[name=origin]'),submit=form.locator('[type=submit]');
    await address.fill('http://unsafe.example.test');await submit.click();
    assert.deepEqual(await p.evaluate(()=>opened),[]);assert.match(await p.locator('#toast').innerText(),/HTTPS/);
    assert.equal(await p.evaluate(()=>localStorage.getItem('qayd.shared.origin.v1')),null);
    await address.fill('https://desk.example.test:443/');await submit.click();await p.locator('#team-login-form').waitFor();
    assert.match(await p.locator('.team-server').innerText(),/https:\/\/desk.example.test/);
    assert.equal(await p.evaluate(()=>localStorage.getItem('qayd.shared.origin.v1')),'https://desk.example.test');
    assert.deepEqual(await p.evaluate(()=>teamCalls),[]);
    await p.reload();await enter();await p.locator('#team-login-form').waitFor();
    await p.locator('[data-action=team-copy-link]').click();assert.deepEqual(await p.evaluate(()=>copied),['https://desk.example.test/']);
    await p.locator('[data-action=team-config]').click();assert.equal(await address.inputValue(),'https://desk.example.test');
    await p.locator('[data-action=team-forget]').click();await p.locator('#dialog button[type=submit]').click();await form.waitFor();assert.equal(await address.inputValue(),'');
    assert.equal(await p.evaluate(()=>localStorage.getItem('qayd.shared.origin.v1')),null);
    assert.deepEqual(await p.evaluate(()=>[saved,opened,teamCalls]),[[],[],[]]);assert.equal(p.url(),u);
    assert.deepEqual(errors,[]);
    console.log('In-app team setup: rejects HTTP, reuses HTTPS address after restart, does not contact the server on save, copy link only, explicit forget, no local writes or external browser.');
  }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
