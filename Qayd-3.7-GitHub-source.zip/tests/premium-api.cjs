'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {spawnSync}=require('node:child_process'),{once}=require('node:events');
const {createDesk}=require('../shared/server.cjs'),{SQLiteStore}=require('../shared/store.cjs');
const M=require('../shared/transfer.cjs'),R=require('../shared/recovery.cjs');
const L=require('../app/ledger.js'),CB=require('../app/category-backup.js');
const F=require('./premium-fixtures.cjs');
async function serve(store,{demo=false}={}){
  const errors=[],app=require('node:http').createServer();
  app.listen(0,'127.0.0.1');await once(app,'listening');
  const host=`127.0.0.1:${app.address().port}`,url='http://'+host;
  const desk=createDesk({store,origin:'https://'+host,trustProxy:true,demo,onError:e=>errors.push(e.message)});
  app.on('request',desk.listeners('request')[0]);app.once('close',()=>desk.emit('close'));
  const request=async (route,body,cookie,extra={})=>{
    const post=body!==undefined;
    const res=await fetch(url+'/api/'+route,{method:post?'POST':'GET',headers:{'X-Forwarded-Proto':'https',...(post?{'X-Qayd-Client':'desk-v1','Content-Type':'application/json',Origin:demo?url:'https://'+host}:{}),...(cookie?{Cookie:cookie}:{}),...extra},body:post?JSON.stringify(body):undefined,signal:AbortSignal.timeout(10_000)});
    const text=await res.text();return {status:res.status,headers:res.headers,cookie:res.headers.getSetCookie()[0]?.split(';')[0],value:text.startsWith('{')?JSON.parse(text):null,text};
  };
  return {request,errors,close:()=>new Promise(r=>app.close(r))};
}
const press=(req,cookie)=> (route,body,extra)=>req(route,body,cookie,extra);
const assertCode=(result,code,status)=>{assert.equal(result.status,status,result.text);assert.equal(result.value.code,code,result.text);};
const clone=structuredClone;
const nodeRestore=path.resolve(__dirname,'../shared/restore.cjs');
function cli(args,input=F.recoveryPhrase,env=process.env){return spawnSync(process.execPath,[nodeRestore,...args],{input,encoding:'utf8',env,timeout:20_000});}
function verified(result){assert.equal(result.status,0,result.stderr);assert.match(result.stdout,/الملف سليم.*3 مستخدم/);assert.doesNotMatch(result.stdout,/synthetic-|staff\.auth|الاختبار|ALREADY-SHARED/);}

test('owner-scoped review, exact signed append, conflicts and stale snapshots leave prior users, records and grants intact',async()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'qayd-premium-api-')),store=new SQLiteStore(path.join(dir,'main.sqlite'));
  let app;
  try{
    const {s,owner,staff,paused,factor,phone}=await F.sharedState({mfa:true}),codes=factor.codes;
    store.init(s);app=await serve(store);const req=app.request;
    const ownAuth=await req('login',{login:'owner',password:F.ownerPass,otp:codes[0]});assert.equal(ownAuth.status,200,ownAuth.text);
    const otherAuth=await req('login',{login:'owner',password:F.ownerPass,otp:codes[1]});assert.equal(otherAuth.status,200,otherAuth.text);
    const employee=await req('login',{login:staff.login,password:F.staffPass});assert.equal(employee.status,200,employee.text);
    const own=press(req,ownAuth.cookie),other=press(req,otherAuth.cookie),emp=press(req,employee.cookie),before=store.load();
    const preview={name:'عملاء من الهاتف · خاص',copy:CB.create(phone,'clients',{includePhotos:false}),version:s.bookVersion,previewConsent:true};
    const phoneRaw=JSON.stringify(phone);
    assert.deepEqual((await req('info')).value.capabilities,{categoryTransfer:1,recoveryArchive:1});
    assertCode(await req('book/transfer-review',preview),'login',401);
    assertCode(await own('book/transfer-review',preview,{Origin:'https://other.invalid'}),'forbidden',403);
    for(const k of ['book/transfer-review','book/transfer-commit','recovery/export','book/backup'])assertCode(await emp(k,k==='book/backup'?undefined:{}),'forbidden',403);
    assert.equal((await emp('desk')).value.maintenance,undefined);
    assert.equal((await own('desk')).value.importable,false);
    assert.equal((await own('book/import',{version:s.bookVersion,confirm:true,ledger:phone})).status,409);
    assertCode(await own('book/transfer-review',preview),'backup-first',409);
    assertCode(await own('recovery/export',{current:'incorrect-test-password',phrase:F.recoveryPhrase}),'owner-password',400);
    assertCode(await own('recovery/export',{current:F.ownerPass,phrase:F.ownerPass}),'backup-phrase',400);
    assertCode(await own('recovery/export',{current:F.ownerPass,phrase:F.recoveryPhrase}),'mfa-required',428);
    assertCode(await own('recovery/export',{current:F.ownerPass,phrase:F.recoveryPhrase,otp:codes[0]}),'mfa-invalid',401);
    assert.equal(store.load().seq,before.seq,'rejected requests made no writes');
    const archive=async otp=>{
      const result=await own('recovery/export',{current:F.ownerPass,phrase:F.recoveryPhrase,otp});
      assert.equal(result.status,200,result.text);assert.match(result.headers.get('content-disposition'),/^attachment; .*\.qayd-recovery/);
      assert.equal(result.headers.get('cache-control'),'no-store');assert.equal(result.headers.getSetCookie().length,0);
      assert.deepEqual(Object.keys(result.value).sort(),['createdAt','data','format','iv','salt','tag','version']);
      assert.doesNotMatch(result.text,/ALREADY-SHARED|SHARED-RECEIPT|password|grants|ledger/);
      assert.ok(!result.text.includes(F.recoveryPhrase)&&!result.text.includes(ownAuth.cookie));
      return result;
    };
    const first=await archive(codes[2]);assert.ok(first.value.data);
    const backed=store.load();assert.equal(backed.s.recoveryPrepared.revision,backed.seq);assert.deepEqual(backed.s.ledger,before.s.ledger);
    assert.deepEqual(backed.s.users.slice(1),before.s.users.slice(1));assert.equal(backed.s.users[0].mfa.recovery.length,before.s.users[0].mfa.recovery.length-1);
    assert.equal((await own('desk')).value.maintenance.backupReady,true);
    assertCode(await own('book/transfer-review',{...preview,previewConsent:false}),'transfer-consent',400);
    assertCode(await own('book/transfer-review',{...preview,name:'عُمَلَاء'}),'transfer-conflict',409);
    assertCode(await own('book/transfer-review',{...preview,copy:CB.create(phone,'clients',{includePhotos:true})}),'transfer-copy',422);
    const bad=clone(preview.copy);bad.entries.find(e=>e.receipt).receipt.number=bad.receiptSerial=1;
    assertCode(await own('book/transfer-review',{...preview,copy:bad}),'transfer-receipt',409);
    const review=async body=>{const result=await own('book/transfer-review',body);assert.equal(result.status,200,result.text);return result.value;};
    const confirm=(r,opts={})=>({ticket:r.ticket,version:r.version,confirm:true,backupConfirmed:true,...opts});
    const r=await review(preview);assert.equal(store.load().seq,backed.seq,'preview is not a durable write');
    assertCode(await other('book/transfer-commit',confirm(r)),'review-expired',409);
    assertCode(await own('book/transfer-commit',confirm(r,{backupConfirmed:false})),'backup-confirm',400);
    assertCode(await own('book/transfer-commit',confirm(r,{confirm:false})),'transfer-consent',400);
    // Identity changes invalidate a preview and the recovery marker even when bookVersion did not change.
    const changed=await own('users/update',{id:staff.id,version:staff.version,name:'كاتب الاختبار',enabled:true,grants:F.oldGrants});assert.equal(changed.status,200,changed.text);
    assert.equal(store.load().s.bookVersion,preview.version);
    assertCode(await own('book/transfer-commit',confirm(r)),'stale',409);
    assertCode(await own('book/transfer-review',preview),'backup-first',409);
    await archive(codes[3]);const beforeRace=await review(preview);
    // A second device adds a real synthetic movement between review and confirmation.
    const written=await emp('book/change',{action:'movement-add',fields:{version:s.bookVersion,kind:'credit',account:'shared-only',amount:'0.005',day:'2026-05-06',time:'08:00',code:'YER',memo:'RACE-ENTRY-PRESERVED'}});
    assert.equal(written.status,200,written.text);preview.version=written.value.version;
    assertCode(await own('book/transfer-commit',confirm(beforeRace)),'stale',409);
    assert.equal((await own('desk')).value.maintenance.backupReady,false);
    await archive(codes[4]);const old=store.load();const final=await review(preview);
    const {summary}=final;assert.equal(summary.accounts,2);assert.equal(summary.movements,6);assert.equal(summary.standalone,2);assert.equal(summary.archived,5);assert.equal(summary.receipts,1);assert.equal(summary.staffAccess,0);
    assert.deepEqual(summary.totals,[{code:'OMR',credit:0,debit:0,net:0},{code:'SAR',credit:70375,debit:0,net:70375},{code:'USD',credit:0,debit:4005,net:-4005},{code:'YER',credit:87875,debit:0,net:87875}]);
    const saved=await own('book/transfer-commit',confirm(final));assert.equal(saved.status,201,saved.text);
    assert.equal(saved.value.category,summary.id);assert.notEqual(saved.value.version,final.version);
    const next=store.load(),d=next.s.ledger,oldBook=old.s.ledger,added=d.entries.slice(oldBook.entries.length);
    assert.equal(next.seq,old.seq+1);assert.deepEqual(next.s.users,old.s.users);assert.deepEqual(next.s.audit.slice(1),old.s.audit);
    assert.equal(next.s.audit[0].kind,'category-transfer');assert.equal(next.s.transfers.length,1);
    assert.deepEqual(d.categories.slice(0,oldBook.categories.length),oldBook.categories);
    assert.deepEqual(d.accounts.slice(0,oldBook.accounts.length),oldBook.accounts);
    assert.deepEqual(d.entries.slice(0,oldBook.entries.length),oldBook.entries);
    assert.deepEqual(d.closures.slice(0,oldBook.closures.length),oldBook.closures);
    assert.deepEqual(d.settings,oldBook.settings);assert.deepEqual(d.years,oldBook.years);assert.equal(d.lastBackup,oldBook.lastBackup);
    assert.deepEqual(d.currencies.slice(0,oldBook.currencies.length),oldBook.currencies);assert.deepEqual(d.currencies.at(-1),{code:'OMR',name:'OMR',symbol:'OMR'});
    const dest=d.accounts.filter(a=>a.category===summary.id);assert.equal(dest.length,2);
    for(const c of d.currencies)for(const a of dest)assert.equal(L.balances(d,c.code).get(a.id).minor,L.balances(phone,c.code).get(a.id).minor);
    assert.equal(d.receiptSerial,41);
    const rr=added.find(e=>e.receipt),side=added.find(e=>e.id===rr.receipt.target);
    assert.equal(rr.receipt.number,41);assert.ok(side.isolatedTransfer&&side.id.startsWith('side-')&&side.memo===''&&side.photo==='');
    assert.equal(side.legs[0].minor,90500);assert.equal(side.due,'2025-06-18');assert.equal(L.isLocked(d,side.id),true);
    assert.equal(L.isLocked(d,'opening'),true);assert.equal(L.isLocked(d,'phone-debit-after-cut'),false);assert.equal(L.isLocked(d,'shared-opening'),true);
    assert.doesNotMatch(JSON.stringify({dest,added}),/OUTSIDE-|مورد الساحة|SHARED-MEMO|data:image/);
    assert.deepEqual(d,L.validate(d));assert.equal(JSON.stringify(phone),phoneRaw);
    assert.equal((await own('desk')).value.maintenance.backupReady,false);
    assertCode(await own('book/transfer-commit',confirm(final)),'review-expired',409);
    assert.equal(store.load().seq,next.seq);
    const staffDesk=await emp('desk?code=YER');assert.equal(staffDesk.value.totals.net,58880);assert.deepEqual(staffDesk.value.accounts.map(x=>x.id),['shared-only']);
    assert.doesNotMatch(staffDesk.text,/الهاتف|مؤسسة الفجر|متجر الندى|ريال عماني/);
    assert.equal((await emp('movements?category='+summary.id)).status,404);
    assert.equal((await emp('report.csv?category='+summary.id)).status,404);
    assertCode(await emp('book/change',{action:'movement-add',fields:{account:'a',kind:'credit',amount:'1',day:'2026-05-06',code:'SAR',version:next.s.bookVersion}}),'not-found',404);
    const fullAfter=await archive(codes[5]),decoded=await R.open(fullAfter.text,F.recoveryPhrase);
    assert.deepEqual(decoded.state,store.load().s);assert.notEqual(first.value.salt,fullAfter.value.salt);assert.notEqual(first.value.iv,fullAfter.value.iv);
    const actual=path.join(dir,'actual-browser-export.qayd-recovery'),restored=path.join(dir,'isolated-actual');
    fs.writeFileSync(actual,fullAfter.text,{mode:0o600});verified(cli(['restore',actual,restored]));
    const afterRestore=new SQLiteStore(path.join(restored,'qayd-shared.sqlite'));
    try{
      const restoredState=afterRestore.load().s,{recoveryPrepared,...expect}=decoded.state;
      assert.notEqual(restoredState.bookVersion,expect.bookVersion);
      assert.deepEqual({...restoredState,bookVersion:expect.bookVersion},expect);
    }finally{afterRestore.close();}
    assert.equal(decoded.state.users.find(x=>x.id===paused.id).enabled,false);
    assertCode(await own('book/transfer-review',{...preview,version:next.s.bookVersion,name:'نسخة ثانية بنفس السجلات',copy:{...preview.copy,createdAt:Date.now()}}),'transfer-duplicate',409);
    const current=store.load().s.users.find(u=>u.id===staff.id),allowed=[...current.grants,{category:summary.id,allow:['view']}];
    const grant=await own('users/update',{id:current.id,version:current.version,enabled:true,name:current.name,grants:allowed});assert.equal(grant.status,200,grant.text);
    assert.equal((await emp('desk?code=SAR')).value.accounts.find(x=>x.id==='a').minor,70375);
    assert.equal((await emp('movements?code=SAR&category='+summary.id)).value.total,2);assert.equal((await emp('report.csv?category='+summary.id)).status,403);
    assert.deepEqual(app.errors,[]);
  }finally{await app?.close();store.close();fs.rmSync(dir,{recursive:true,force:true});}
});

test('append preflight never merges account names or records and never inserts into a closed server year',async()=>{
  const raw=F.phoneCopy(),{s}=await F.sharedState(),original=JSON.stringify(s);
  const closed=clone(s);closed.ledger.years=[2025];
  assert.throws(()=>M.plan(closed,raw,'فئة جديدة'),{code:'transfer-closed-year'});
  const duplicateAccount=clone(raw);duplicateAccount.accounts[0].name='عميل التجربَة المشترك';
  assert.throws(()=>M.plan(s,duplicateAccount,'فئة جديدة'),{code:'transfer-account'});
  const duplicateMovement=clone(raw);duplicateMovement.entries.find(e=>e.id==='inside').id='shared-receipt';
  for(const c of duplicateMovement.closures)c.ids=c.ids.map(i=>i==='inside'?'shared-receipt':i);
  assert.throws(()=>M.plan(s,duplicateMovement,'فئة جديدة'),{code:'transfer-entry'});
  const unsafename='جهة\u202etxt';assert.throws(()=>M.plan(s,raw,unsafename),{status:400});
  assert.equal(JSON.stringify(s),original);
  // Two independent phone scopes may carry opposite sides without reconnecting private data.
  const phone=F.phoneBook();phone.entries=phone.entries.filter(e=>!e.receipt);delete phone.receiptSerial;
  const a=M.plan(s,CB.create(phone,'clients',{includePhotos:false}),'طرف أ');
  const aId=a.next.entries.find(e=>e.isolatedTransfer&&e.legs[0].account==='a'&&e.legs[0].code==='YER').id;
  const b=M.plan({...s,ledger:a.next},CB.create(phone,'suppliers',{includePhotos:false}),'طرف ب');
  const bId=b.next.entries.find(e=>e.isolatedTransfer&&e.legs[0].account==='x'&&e.legs[0].code==='YER').id;
  assert.notEqual(aId,bId);assert.equal(b.next.entries.find(e=>e.id===aId).legs[0].minor,-37250);assert.equal(b.next.entries.find(e=>e.id===bId).legs[0].minor,37250);
});

test('protected full snapshot verifies and restores to a new isolated SQLite directory, with old rights and MFA',async()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'qayd-premium-recovery-')),source=path.join(dir,'shared.sqlite');
  const store=new SQLiteStore(source),snapshot=path.join(dir,'old-stable.sqlite'),archive=path.join(dir,'recovery.qayd-recovery'),out=path.join(dir,'stage');
  let running,recovered;
  try{
    const {s,staff,paused,factor}=await F.sharedState({mfa:true});store.init(s);
    // Legacy-style SQLite snapshot; no maintenance fields are needed for recovery.
    await store.snapshot(snapshot);const original=fs.readFileSync(snapshot);
    const sealed=cli(['seal-snapshot',snapshot,archive]);verified(sealed);
    assert.equal(fs.statSync(archive).mode&0o777,0o600);
    assert.deepEqual(fs.readFileSync(snapshot),original);
    const text=fs.readFileSync(archive,'utf8');assert.equal(cli(['seal-snapshot',snapshot,archive]).status,1);assert.equal(fs.readFileSync(archive,'utf8'),text);
    const packed=JSON.parse(text),opened=await R.open(text,F.recoveryPhrase);assert.deepEqual(opened.state,s);
    await assert.rejects(R.open(JSON.stringify({...packed,createdAt:packed.createdAt+1}),F.recoveryPhrase),/غير صحيحة أو الملف غير سليم/);
    await assert.rejects(R.open(JSON.stringify({...packed,data:(packed.data[0]==='A'?'B':'A')+packed.data.slice(1)}),F.recoveryPhrase),/غير صحيحة أو الملف غير سليم/);
    await assert.rejects(R.open(JSON.stringify({...packed,version:999}),F.recoveryPhrase));
    assert.throws(()=>R.state({...s,users:[...s.users,s.users[0]]}));
    assert.throws(()=>R.state({...s,users:s.users.map(u=>u.id===staff.id?{...u,grants:[{category:'unknown',allow:['view']}]}:u)}));
    assert.equal(cli(['restore',archive,out],'Synthetic incorrect recovery phrase').status,1);assert.equal(fs.existsSync(out),false);
    assert.equal(cli(['restore',archive,out],F.recoveryPhrase,{...process.env,RAILWAY_SERVICE_ID:'synthetic'}).status,1);assert.equal(fs.existsSync(out),false);
    verified(cli(['verify',archive]));verified(cli(['restore',archive,out]));
    const dest=path.join(out,'qayd-shared.sqlite'),bytes=fs.readFileSync(dest);
    assert.equal(fs.statSync(out).mode&0o777,0o700);assert.equal(fs.statSync(dest).mode&0o777,0o600);
    assert.equal(cli(['restore',archive,out]).status,1);assert.deepEqual(fs.readFileSync(dest),bytes);
    fs.symlinkSync(out,path.join(dir,'alias'));assert.equal(cli(['restore',archive,path.join(dir,'alias')]).status,1);
    recovered=new SQLiteStore(dest);const ready=recovered.load();assert.notEqual(ready.s.bookVersion,s.bookVersion);
    assert.deepEqual({...ready.s,bookVersion:s.bookVersion},s);assert.equal(M.backupIsRecent(ready),false);
    running=await serve(recovered);
    assertCode(await running.request('login',{login:'owner',password:F.ownerPass}),'mfa-required',428);
    const owner=await running.request('login',{login:'owner',password:F.ownerPass,otp:factor.codes[0]});assert.equal(owner.status,200,owner.text);
    assertCode(await running.request('login',{login:'owner',password:F.ownerPass,otp:factor.codes[0]}),'mfa-invalid',401);
    const emp=await running.request('login',{login:staff.login,password:F.staffPass});assert.equal(emp.status,200,emp.text);
    assertCode(await running.request('login',{login:paused.login,password:F.staffPass}),'credentials',401);
    const request=press(running.request,emp.cookie),data=(await request('desk')).value;
    assert.equal(data.totals.net,58875);assert.deepEqual(data.me.grants,F.oldGrants);assert.equal(data.categories.length,1);
    assertCode(await request('recovery/export',{}),'forbidden',403);assert.deepEqual(running.errors,[]);
    assert.deepEqual(store.load().s,s,'recovery never touched the source database');
  }finally{await running?.close();recovered?.close();store.close();fs.rmSync(dir,{recursive:true,force:true});}
});
