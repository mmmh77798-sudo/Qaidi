package app.qayd.ledger;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashSet;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Plain JVM framing/intent payload constraints. No Android device or printer required. */
public final class AccountAddonsTest {
    static void require(boolean x){if(!x)throw new AssertionError();}
    static int b(byte[] a,int i){return a[i]&255;}
    public static void main(String[] args)throws Exception {
        int w=384,h=165,scan=48;
        byte[] image=new byte[w/8*h];
        Arrays.fill(image,(byte)0x22);image[0]=(byte)0x80;image[image.length-1]=1;
        String encoded=Base64.getEncoder().encodeToString(image);
        require(ThermalRaster.request(w,h,encoded));
        require(ThermalRaster.bytes(512,h)==64*h&&ThermalRaster.bytes(576,h)==72*h);
        require(!ThermalRaster.request(400,h,encoded));
        require(!ThermalRaster.request(w,ThermalRaster.MAX_HEIGHT+1,encoded));
        require(!ThermalRaster.request(w,h,encoded+"AAAA"));
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();ThermalRaster.write(bytes,w,h,image);
        byte[] frame=bytes.toByteArray();
        require(b(frame,0)==27&&b(frame,1)==64);
        int pos=2,offset=0;
        for(int rows:new int[]{80,80,5}){
            require(b(frame,pos)==29&&b(frame,pos+1)==118&&b(frame,pos+2)==48&&b(frame,pos+3)==0);
            require(b(frame,pos+4)==scan&&b(frame,pos+5)==0&&b(frame,pos+6)==rows&&b(frame,pos+7)==0);
            int length=rows*scan;
            require(Arrays.equals(Arrays.copyOfRange(image,offset,offset+length),Arrays.copyOfRange(frame,pos+8,pos+8+length)));
            offset+=length;pos+=length+8;
        }
        require(pos+3==frame.length&&b(frame,pos)==27&&b(frame,pos+1)==100&&b(frame,pos+2)==3);
        try{ThermalRaster.write(bytes,w,h,new byte[4]);throw new AssertionError();}catch(IOException ok){}
        require(!WorkbookExport.request("qayd-statement-../a.xlsx",encoded,"share"));
        require(!WorkbookExport.request("qayd-statement-test.xls",encoded,"share"));
        require(!WorkbookExport.request("qayd-report-test.xlsx",encoded,"drive"));
        require(!WorkbookExport.zipEnvelope(image));
        for(String path:args){
            byte[] book=Files.readAllBytes(Paths.get(path));
            require(WorkbookExport.zipEnvelope(book));
            String base=Base64.getEncoder().encodeToString(book);
            require(WorkbookExport.request("qayd-report-test.xlsx",base,"local"));
            require(WorkbookExport.request("qayd-report-test.xlsx",base,"share"));
            require(WorkbookExport.request("qayd-report-receipts-YER-2026-11-18.xlsx",base,"local"));
            Set<String> names=new HashSet<>();
            try(ZipInputStream zip=new ZipInputStream(Files.newInputStream(Paths.get(path)))){
                for(ZipEntry e;(e=zip.getNextEntry())!=null;zip.closeEntry())names.add(e.getName());
            }
            require(names.contains("[Content_Types].xml")&&names.contains("xl/worksheets/sheet1.xml"));
            require(!WorkbookExport.zipEnvelope(Arrays.copyOf(book,book.length-4)));
        }
        System.out.println("XLSX save/share envelope and source-limited ESC/POS byte framing passed.");
    }
}
