package app.qayd.ledger;

import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Collections;

/** JVM entry for checking the same team transport used by Android. Test data only. */
public final class TeamBridgeHarness {
    private static void check(boolean good){if(!good)throw new AssertionError("team transport contract");}
    private static void contract() throws Exception {
        check("https://team.example.test".equals(SharedOrigin.canonical("https://TEAM.example.test:443/")));
        check("https://[2001:db8::1]:8443".equals(SharedOrigin.canonical("https://[2001:DB8::1]:8443/")));
        check(SharedOrigin.canonical("http://team.example.test")==null);
        check(SharedOrigin.canonical("https://user@team.example.test")==null);
        check(SharedOrigin.canonical("https://team.example.test/subpath")==null);
        String host="https://team.example.test",id="6a1b2c3d-5200-4444-abcd-0d7c0009fe18";
        for(TeamHttp.Route route:TeamHttp.Route.values()){
            String url=TeamHttp.target(host,route,route==TeamHttp.Route.MEMBER?id:null);
            check(url.startsWith(host+"/api/"));
        }
        check(TeamHttp.target(host,TeamHttp.Route.MEMBER,id).endsWith("?user="+id));
        check(!TeamHttp.memberId("not-a-member"));
        String cookie="test-only-session-value-test-only-123456789";
        check(TeamHttp.sessionValue(cookie));
        String h=TeamHttp.COOKIE+"="+cookie+"; Secure; HttpOnly; Path=/; SameSite=Strict; Max-Age=2400";
        check(cookie.equals(TeamHttp.loginCookie(Collections.singletonMap("set-cookie",Collections.singletonList(h)))));
        check(TeamHttp.loginCookie(Collections.singletonMap("Set-Cookie",Arrays.asList(h,h)))==null);
        check(TeamHttp.loginCookie(Collections.singletonMap("Set-Cookie",Collections.singletonList(h+"; Domain=team.example.test")))==null);
        check(TeamHttp.loginCookie(Collections.singletonMap("Set-Cookie",Collections.singletonList(h.replace("; Secure",""))))==null);
        check(TeamHttp.loginCookie(Collections.singletonMap("Set-Cookie",Collections.singletonList(h.replace("; HttpOnly",""))))==null);
        check(TeamHttp.loginCookie(Collections.singletonMap("Set-Cookie",Collections.singletonList(h.replace("Path=/","Path=/team"))))==null);
        check(TeamHttp.loginCookie(Collections.singletonMap("Set-Cookie",Collections.singletonList(h.replace("SameSite=Strict","SameSite=Lax"))))==null);
        check(SharedTeam.ticket("team-12")&&!SharedTeam.ticket("manual-ticket"));
        System.out.println("Team contract: canonical HTTPS, fixed routes/UUID, and strict host-only session header verified.");
    }
    public static void main(String[] args)throws Exception{
        System.setOut(new PrintStream(System.out,true,"UTF-8"));
        if(args.length==0){contract();return;}
        if(args.length!=1||!args[0].equals("relay"))throw new IllegalArgumentException("relay");
        SharedTeam team=new SharedTeam();
        try(BufferedReader in=new BufferedReader(new InputStreamReader(System.in,StandardCharsets.UTF_8))){
            String line;
            while((line=in.readLine())!=null){
                final JSONObject command=new JSONObject(line);final String id=command.getString("ticket");
                if(command.optBoolean("clear")){team.clear();System.out.println(new JSONObject().put("ticket",id).put("status",204).put("value",new JSONObject()));continue;}
                team.request(id,command.getString("origin"),command.getString("op"),command.getString("json"),(ticket,status,value)->{
                    try{System.out.println(new JSONObject().put("ticket",ticket).put("status",status).put("value",new JSONObject(value)));}
                    catch(Exception malformed){throw new IllegalStateException("invalid reply",malformed);}
                });
            }
        }finally{team.close();}
    }
}
