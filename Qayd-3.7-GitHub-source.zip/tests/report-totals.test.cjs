const {test}=require('node:test');
const a=require('node:assert/strict');
const T=require('../app/report-totals.js');

const line=(account,code,minor)=>({account,code,minor});
const move=(...legs)=>({legs});

test('statement keeps opening, visible activity, carried balance and ending separate',()=>{
  const rows=[{minor:100125,closed:true},{minor:1001},{minor:-2050}];
  const s=T.statement({rows,opening:500001,ending:599077});
  a.equal(s.net,-1049);a.equal(s.credit,1001);a.equal(s.debit,2050);
  a.equal(s.ending,s.opening+s.carry+s.net);
  a.deepEqual(T.fields(s).map(([k,,v])=>[k,v]),[['credit',1001],['debit',2050],['net',-1049],['opening',500001],['carry',100125],['ending',599077]]);
  const filtered=T.statement({rows:rows.slice(-1),opening:500001,ending:599077,search:true});
  a.deepEqual([filtered.net,filtered.ending,filtered.carry],[-2050,599077,null]);
  a.match(filtered.note,/للبحث/);a.equal(T.fields(filtered).some(([k])=>k==='carry'),false);
});

test('details exclude whole internal transfers or show only the signed selected leg',()=>{
  const x=move(line('a','SAR',-150125),line('b','SAR',150125));
  const e=[x,move(line('a','SAR',3001)),move(line('a','SAR',-6003))];
  const pick=s=>[s.credit,s.debit,s.net];
  a.deepEqual(pick(T.details(e,'','SAR')),[3001,6003,-3002]);
  a.deepEqual(pick(T.details(e,'a','SAR')),[3001,156128,-153127]);
  a.deepEqual(pick(T.details([x],'b','SAR')),[150125,0,150125]);
  a.deepEqual(pick(T.details([x],'','SAR')),[0,0,0]);
  a.deepEqual(pick(T.details([],'','USD')),[0,0,0]);
  a.equal(T.detailAmount(x,'a','SAR'),-150125);
});
