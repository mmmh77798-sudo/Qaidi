const {test}=require('node:test');
const assert=require('node:assert/strict');
const L=require('../app/ledger.js');
const fixture=()=>{const d=L.empty();return {d,a:L.addAccount(d,{name:'أحمد'}).id,b:L.addAccount(d,{name:'مؤسسة النور'}).id};};
const add=(d,account,fields={})=>L.saveEntry(d,{account,kind:'credit',code:'YER',day:'2024-02-28',amount:'1200.25',memo:'دفعة A',...fields});
test('Arabic, Persian, grouping and exact financial amounts',()=>{
  assert.equal(L.parseAmount('١٬٢٣٤٫٥٦'),1234560);
  assert.equal(L.parseAmount('۱۲٬۳۴۵٫۶۷'),12345670);
  assert.equal(L.parseAmount('1 234.5'),1234500);
  assert.equal(L.decimal(-5),'-0.005');
  assert.equal(L.parseAmount('3.123'),3123);
  assert.equal(L.parseAmount('0.001'),1);
  assert.equal(L.inputDecimal(1200500),'1200.50');
  assert.equal(L.inputDecimal(1200501),'1200.501');
  for (const x of ['0','-1','3.1234','1,25','2e5','0.00','.5','9007199254740992','abc']) assert.throws(()=>L.parseAmount(x));
});
test('valid Gregorian dates and normalized name search',()=>{
  assert.equal(L.validDay('2024-02-29'),true);
  assert.equal(L.validDay('2025-02-29'),false);
  assert.equal(L.validDay('2024-02-30'),false);
  assert.equal(L.offset(1,'2024-02-29'),'2024-03-01');
  assert.equal(L.searchKey('أَحْمَــد ١٬٠٠٠'),'احمد 1000');
  const {d}=fixture();assert.throws(()=>L.addAccount(d,{name:'احمد'}));
});
test('amount addition and subtraction do not mix currencies',()=>{
  const {d,a,b}=fixture();
  add(d,a);add(d,a,{kind:'debit',amount:'200.25'});add(d,b,{kind:'debit',amount:'550'});add(d,a,{code:'USD',amount:'20'});
  const valid=L.validate(d);
  assert.equal(L.balances(valid,'YER').get(a).minor,1000000);
  assert.deepEqual(L.totals(L.balances(valid,'YER')),{credit:1000000,debit:550000,net:450000,credits:1,debits:1});
  assert.equal(L.balances(valid,'USD').get(a).minor,20000);
});
test('transfers post both legs, preserve the net, edit and delete as one unit',()=>{
  const {d,a,b}=fixture();add(d,a);
  const before=L.totals(L.balances(d,'YER')).net;
  const fields={kind:'transfer',from:a,to:b,amount:'50',day:'2024-02-28',code:'YER'};
  assert.throws(()=>L.saveEntry(d,{...fields,to:a}));
  const e=L.saveEntry(d,fields);const v=L.validate(d);
  assert.equal(L.balances(v,'YER').get(a).minor,1150250);
  assert.equal(L.balances(v,'YER').get(b).minor,50000);
  assert.equal(L.totals(L.balances(v,'YER')).net,before);
  L.saveEntry(d,{...fields,id:e.id,amount:'100'});
  assert.equal(L.balances(d,'YER').get(b).minor,100000);
  L.removeEntry(d,e.id);assert.equal(L.balances(d,'YER').get(b).minor,0);
  assert.equal(L.totals(L.balances(d,'YER')).net,before);
});
test('statement ranges, opening balance and date/amount filters',()=>{
  const {d,a}=fixture();add(d,a,{day:'2024-02-01',amount:'500'});add(d,a,{day:'2024-02-11',kind:'debit',amount:'100'});add(d,a,{day:'2024-03-01',amount:'50'});
  const s=L.statement(d,a,'YER',{from:'2024-02-03',to:'2024-02-28'});
  assert.equal(s.opening,500000);assert.equal(s.ending,400000);
  assert.equal(s.rows.length,1);assert.equal(s.rows[0].running,400000);
  assert.equal(L.matching(d,{query:'٢٠٢٤-٠٢'}).length,2);
  assert.equal(L.matching(d,{query:'٥٠٠'}).length,1);
});
test('closing balance archives records without losing totals or historical reports',()=>{
  const {d,a,b}=fixture();const e=add(d,a,{amount:'500'});const t=L.saveEntry(d,{kind:'transfer',from:a,to:b,code:'YER',day:'2024-02-28',amount:'400'});
  L.closeBalance(d,a,'YER','2024-02-29');
  const validated=L.validate(d);assert.equal(validated.entries.length,2);
  assert.throws(()=>L.removeEntry(d,t.id));assert.throws(()=>L.removeEntry(d,e.id));
  assert.throws(()=>add(d,a));assert.throws(()=>L.removeAccount(d,b));
  const {rows,ending}=L.statement(d,a,'YER');assert.equal(rows.length,1);assert.equal(rows[0].closed,true);assert.equal(rows[0].minor,100000);assert.equal(ending,100000);
  assert.equal(L.statement(d,a,'YER',{archive:true}).rows.length,2);
  L.openBalance(d,a,'YER');assert.equal(L.statement(d,a,'YER').rows.length,2);
  assert.equal(L.flows(d.entries,x=>x.day).get('2024-02-28').credit,500000);
});
test('validate refuses corrupt, unbalanced or ambiguous backup data',()=>{
  const {d,a,b}=fixture();const x=L.saveEntry(d,{kind:'transfer',from:a,to:b,code:'YER',day:'2024-02-28',amount:'12'});
  assert.deepEqual(L.validate(JSON.parse(JSON.stringify(d))),d);
  x.legs[1].minor=10;assert.throws(()=>L.validate(d));x.legs[1].minor=12000;
  d.entries.push({...x});assert.throws(()=>L.validate(d));d.entries.pop();
  d.accounts[1].name=d.accounts[0].name;assert.throws(()=>L.validate(d));
  assert.throws(()=>L.validate({schema:3}));
});
test('CSV is UTF-8 with quoted strings, protected formulas and real negative numbers',()=>{
  assert.equal(L.csv([['اسم','"مذكرة"','=1+1',-12.25]]),'\ufeff"اسم","""مذكرة""","\'=1+1",-12.25\r\n');
});
test('v1 ledgers migrate in place without dropping dates, balances or branding',()=>{
  const {d,a}=fixture();add(d,a);d.settings.business='تجربة فقط';
  const old=L.stateClone(d);old.schema=1;for(const e of old.entries)for(const leg of e.legs)leg.minor/=10;old.settings={defaultCode:'YER',business:'تجربة فقط',digits:'arabic',words:true,transferDetails:false};
  delete old.years;delete old.accounts[0].reminder;delete old.entries[0].time;delete old.entries[0].photo;
  const migrated=L.validate(old);
  assert.equal(migrated.settings.business,old.settings.business);assert.equal(migrated.settings.words,true);
  assert.equal(migrated.settings.notify.channel,'none');assert.ok(L.validTime(migrated.entries[0].time));
  assert.equal(L.statement(migrated,a,'YER').ending,1200250);
});
test('annual close keeps historical activity, separates currencies and supports undo',()=>{
  const {d,a,b}=fixture();const old=add(d,a,{day:'2024-11-03',amount:'500'});
  add(d,a,{day:'2024-11-04',amount:'180',code:'SAR'});
  add(d,b,{day:'2025-01-02',amount:'200'});
  add(d,a,{day:'2025-01-02',amount:'20'});
  L.closeYear(d,2024);const s=L.validate(d);
  assert.equal(L.yearCut(s),'2024-12-31');assert.equal(L.statement(s,a,'YER').rows[0].closed,true);assert.equal(L.statement(s,a,'YER').ending,520000);
  assert.equal(L.statement(s,a,'SAR').ending,180000);assert.equal(L.statement(s,a,'YER',{archive:true}).rows[0].id,old.id);
  assert.throws(()=>L.saveEntry(s,{id:old.id,account:a,day:'2025-01-25',code:'YER',kind:'credit',amount:'1'}));
  assert.throws(()=>add(s,a));assert.throws(()=>L.removeAccount(s,a));
  assert.equal(L.matching(s,{to:'2024-12-31'}).length,2);
  L.openYear(s);assert.equal(L.statement(s,a,'YER').rows[0].id,old.id);
});
test('time order, calendar periods and calculator rounding',()=>{
  const {d,a}=fixture();add(d,a,{time:'10:05',amount:'100'});add(d,a,{time:'09:50',amount:'20'});
  assert.deepEqual(L.statement(d,a,'YER').rows.map(r=>r.running),[20000,120000]);
  assert.equal(L.periodKey('2025-03-03','week'),'2025-03-01');
  assert.equal(L.periodKey('2024-05-31','month'),'2024-05');
  assert.equal(L.calculate('(١٢٥٠ + ٧٥٠) ÷ ٢'),1000000);
  assert.equal(L.calculate('10/3'),3333);
  assert.equal(L.calculate('2+3*4-1.5'),12500);
  assert.throws(()=>L.calculate('5 ÷ 0'));assert.throws(()=>L.calculate('Math.min(2, 3)'));
  assert.equal(L.phoneNumber('٧٧٠ ٠٠٠ ٠٠٠'),'+967770000000');
  assert.equal(L.phoneNumber('00966500000000'),'+966500000000');assert.throws(()=>L.phoneNumber('bad'));
});
test('password envelope does not expose plaintext and rejects incorrect password/tampering',async()=>{
  const V=require('../app/vault.js');const d=L.empty();L.addAccount(d,{name:'اختبار الخصوصية'});
  const c=await V.newKey('test-password-4321');const enc=await V.lock(d,c),again=await V.lock(d,c);
  assert.notEqual(enc.iv,again.iv);assert.equal(JSON.stringify(enc).includes('اختبار الخصوصية'),false);
  assert.deepEqual((await V.unlock(enc,'test-password-4321')).value,d);
  await assert.rejects(V.unlock(enc,'wrong-password'));
  const changed={...enc,payload:(enc.payload[0]==='A'?'B':'A')+enc.payload.slice(1)};
  await assert.rejects(V.unlock(changed,'test-password-4321'));
});
