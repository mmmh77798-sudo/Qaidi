const {localSetting}=require('./navigation.cjs');
const {chromium}=require('playwright');
const assert=require('node:assert/strict');
const fs=require('node:fs/promises');
const path=require('node:path');
const os=require('node:os');
const {legacyDb,readContainer}=require('./db-fixtures.cjs');
const L=require('../app/ledger.js');
const endpoint=process.argv[2]||'http://localhost:3000/';
(async()=>{
  const dir=await fs.mkdtemp(path.join(os.tmpdir(),'qayd-flags-'));
  let b;
  try{
    const unknown=path.join(dir,'no-cache.db'), verified=path.join(dir,'verified.db');
    legacyDb(unknown,'flags-unconfirmed');legacyDb(verified,'flags');
    const bytes=await fs.readFile(verified);
    b=await chromium.launch({headless:true,args:['--no-sandbox']});
    const p=await b.newPage({viewport:{width:393,height:852},isMobile:true,hasTouch:true,acceptDownloads:true});
    const errors=[];p.on('pageerror',e=>errors.push(e.message));p.setDefaultTimeout(8000);
    await p.goto(endpoint);
    const d=p.locator('#dialog');
    const title=name=>d.getByRole('heading',{name,exact:true}).waitFor();
    const next=()=>d.locator('[type=submit]').click();
    const sel=name=>d.locator(`select[name=${name}]`);
    const snapshot=()=>p.evaluate(()=>localStorage.getItem('qayd.ledger.v1'));
    const preview=()=>d.locator('#legacy-proposed bdi').innerText();
    const pick=async file=>{
      if(!await p.locator('#page [data-action=restore]').count())await localSetting(p,'storage');
      const [chooser]=await Promise.all([p.waitForEvent('filechooser'),p.getByRole('button',{name:'استرجاع نسخة',exact:true}).click()]);
      await chooser.setFiles(file);
    };
    await pick(unknown);await title('طريقة قراءة المبالغ');
    assert.equal(await sel('layout').inputValue(),'');
    await sel('layout').selectOption('flags');await next();await title('استيراد نسخة دفتر الحسابات');
    assert.equal(await sel('transferMode').count(),0);
    await next();await title('مطابقة رصيد قبل الاسترجاع');assert.equal(await preview(),'1,230.615');
    await d.locator('.dialog-foot [data-action=close-dialog]').click();assert.equal(await snapshot(),null);

    await pick(verified);await title('استيراد نسخة دفتر الحسابات');
    assert.equal(await sel('movement').count(),0);assert.equal(await sel('dayOrder').inputValue(),'dm');
    assert.equal(await sel('transferMode').inputValue(),'complete');
    assert.ok(await d.getByRole('heading',{name:'حركات بلا حساب'}).isVisible());
    await sel('transferMode').selectOption('posted');await next();await title('مطابقة رصيد قبل الاسترجاع');
    assert.match(await d.locator('.legacy-counts').innerText(),/2 من 3/);assert.equal(await preview(),'12.111');
    await p.locator('#legacy-back').click();await title('استيراد نسخة دفتر الحسابات');
    await sel('transferMode').selectOption('complete');await next();await title('مطابقة رصيد قبل الاسترجاع');
    assert.deepEqual(await sel('account').locator('option').evaluateAll(os=>os.map(o=>o.value)),['old-a-20|YER']);
    assert.match(await d.locator('.legacy-counts').innerText(),/3 من 3/);assert.equal(await preview(),'5.006');
    await sel('flow').selectOption('credit');await d.locator('[name=expected]').fill('5.01');await next();
    assert.match(await d.locator('.form-error').innerText(),/الرصيد غير مطابق/);assert.equal(await snapshot(),null);
    await d.locator('[name=expected]').fill('٥٫٠٠٦');await next();await title('استرجاع واستبدال البيانات');
    assert.match(await d.locator('.legacy-summary').innerText(),/6 من المبالغ بثلاث منازل عشرية/);
    assert.equal(await snapshot(),null);await next();await d.waitFor({state:'hidden'});
    const ledger=JSON.parse(await snapshot());
    assert.equal(ledger.schema,L.schema);assert.equal(ledger.accounts.length,4);assert.equal(ledger.entries.length,6);
    assert.deepEqual(ledger.entries.find(e=>e.id==='old-t-302').legs,[{account:'old-a-20',code:'YER',minor:-7105},{account:'old-a-10',code:'YER',minor:7105}]);
    assert.deepEqual(ledger.entries.find(e=>e.id==='old-t-305').legs,[{account:'old-unassigned',code:'YER',minor:-12321}]);
    assert.equal(L.balances(ledger,'YER').get('old-a-10').minor,1230615);
    assert.equal(L.balances(ledger,'YER').get('old-a-20').minor,5006);
    assert.equal(L.balances(ledger,'SAR').get('old-a-30').minor,-3005);
    assert.equal(ledger.entries.find(e=>e.id==='old-t-301').day,'2026-03-02');

    await p.locator('#mobilebar [data-view=accounts]').click();
    await p.locator('[data-action=open-account][data-id=old-a-10]:visible').click();
    const row=p.locator('#view-results tbody tr').filter({hasText:'خصم دقيق'});
    assert.match(await row.locator('td').nth(3).innerText(),/-11\.002/);
    await p.locator('[data-action=export-options][data-target=statement]').click();
    let waiting=p.waitForEvent('download');await d.locator('[data-action=csv]').click();
    const csv=await fs.readFile(await (await waiting).path(),'utf8');assert.match(csv,/خصم دقيق.*-11\.002/);
    await p.locator('#mobilebar [data-view=settings]').click();await p.locator('button[data-key=storage]').click();
    waiting=p.waitForEvent('download');await p.locator('[data-action=backup]').click();
    const backup=await waiting, file=path.join(dir,backup.suggestedFilename());await backup.saveAs(file);
    assert.deepEqual(readContainer(file).entries,ledger.entries);
    await pick(file);await title('استرجاع واستبدال البيانات');await next();await d.waitFor({state:'hidden'});
    assert.deepEqual(JSON.parse(await snapshot()).entries,ledger.entries);
    // The SQLite container did not change: a genuine old-format Qayd payload
    // still restores to the same values after scaling from cents.
    const beforeOld=await snapshot(), demo=L.demoData(), prior=L.stateClone(demo);
    prior.schema=1;for(const e of prior.entries)for(const leg of e.legs)leg.minor/=10;
    const oldBytes=await p.evaluate(async value=>Array.from(await QaydDb.write(value)),JSON.stringify(prior));
    await pick({name:'old-qayd.db',mimeType:'application/x-sqlite3',buffer:Buffer.from(oldBytes)});
    await title('استرجاع واستبدال البيانات');assert.equal(await snapshot(),beforeOld);
    await next();await d.waitFor({state:'hidden'});
    assert.deepEqual(JSON.parse(await snapshot()).entries,demo.entries);
    assert.deepEqual(await fs.readFile(verified),bytes);assert.deepEqual(errors,[]);
    console.log('Signed-marker DB: cache confirmation, unassigned preservation, exact thousandths, supported counterpart, local review, CSV and DB restore passed.');
  }finally{if(b)await b.close();await fs.rm(dir,{recursive:true,force:true});}
})().catch(e=>{console.error(e);process.exitCode=1;});
