'use strict';
const {localSetting}=require('./navigation.cjs');
const assert=require('node:assert/strict');
const {chromium}=require('playwright');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {pathToFileURL}=require('node:url');
const {execFileSync}=require('node:child_process');
const {fixture,currentFrom}=require('./category-fixtures.cjs');
const {legacyDb}=require('./db-fixtures.cjs');
const V=require('../app/vault.js'),CB=require('../app/category-backup.js');
const url=pathToFileURL(path.resolve(__dirname,'../app/index.html')).href;
const encPass='Synthetic-Protected-File-2026';
const prepare=(file,value)=>execFileSync('python3',['-c',`import sys, sqlite3
c=sqlite3.connect(sys.argv[1]);c.executescript('PRAGMA application_id=1363237188; PRAGMA user_version=1; CREATE TABLE qayd_backup(part INTEGER PRIMARY KEY, payload BLOB NOT NULL);')
b=sys.stdin.buffer.read();c.executemany('INSERT INTO qayd_backup VALUES(?,?)',((i//65536,b[i:i+65536]) for i in range(0,len(b),65536)));c.commit();assert c.execute('PRAGMA integrity_check').fetchone()==('ok',);c.close()
`,file],{input:JSON.stringify(value)});
(async()=>{
  const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'qayd-review-'));let browser;
  try{
    const source=currentFrom(fixture()),scope=CB.create(source,'clients');
    const db=path.join(tmp,'safe-sample.db'),legacy=path.join(tmp,'old-sample.db'),bad=path.join(tmp,'incomplete.db');
    prepare(db,await V.lock(scope,await V.newKey(encPass)));legacyDb(legacy);
    const initialBytes=fs.readFileSync(db),legacyBytes=fs.readFileSync(legacy);
    fs.writeFileSync(bad,initialBytes.subarray(0,511));
    browser=await chromium.launch();const p=await browser.newPage({viewport:{width:393,height:852},isMobile:true,hasTouch:true});
    p.setDefaultTimeout(9000);const errs=[],online=[];p.on('pageerror',e=>errs.push(e.message));p.on('request',r=>{if(/^https?:/.test(r.url()))online.push(r.url());});
    await p.context().setOffline(true);
    await p.addInitScript(raw=>{window.qa={written:[],clipboard:[],dials:0};window.QaydAndroid={readLedger:()=>raw,writeLedger:(...args)=>{qa.written.push(args);return true;},copyText:x=>qa.clipboard.push(x),dialSupport:()=>qa.dials++};},JSON.stringify(fixture()));
    await p.goto(url);
    const dialog=p.locator('#dialog'),title=name=>dialog.getByRole('heading',{name,exact:true}).waitFor(),close=()=>dialog.locator('.dialog-foot [data-action=close-dialog]').click();
    const setting=key=>p.locator(`[data-action=settings-open][data-key=${key}]`).click();
    const open=()=>p.locator('[data-action=go][data-view=settings]:visible').first().click();
    const picker=p.locator('#verify-backup-file');
    const clickVerify=async file=>{const [selection]=await Promise.all([p.waitForEvent('filechooser'),p.locator('[data-action=verify-backup]:visible').first().click()]);await selection.setFiles(file);};
    await open();await setting('about');
    const about=p.locator('.app-credit-card');assert.ok((await about.innerText()).includes('قيد '+require('../app/release.js').version));assert.match(await about.innerText(),/© 2026 هيثم عادل/);
    assert.match(await p.locator('.settings-card').first().innerText(),/777456253/);
    await p.locator('[data-action=support-copy]').click();await p.locator('[data-action=support-dial]').click();
    assert.deepEqual(await p.evaluate(()=>qa),{written:[],clipboard:['777456253'],dials:1});
    assert.equal(await p.locator('[data-action=verify-backup]').count(),0);
    await localSetting(p,'storage');
    await clickVerify({name:'ledger-test.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(source))});
    await title('النسخة قابلة للقراءة');assert.match(await dialog.innerText(),/نسخة دفتر قيد كاملة/);
    assert.match(await dialog.innerText(),/2025-02-06/);assert.match(await dialog.innerText(),/YER/);
    const counts=await dialog.locator('.backup-review-counts strong').allTextContents();assert.deepEqual(counts.slice(0,3).map(Number),[source.accounts.length,source.entries.length,source.entries.filter(x=>x.receipt).length]);
    assert.equal(await dialog.locator('[type=submit]').count(),0);await close();
    await open();await setting('storage');
    await clickVerify(db);await title('فحص نسخة مشفّرة');
    const password=dialog.locator('[name=password]'),next=()=>dialog.locator('[type=submit]').click();
    await password.fill('wrong-synthetic-pass');await next();await dialog.locator('.form-error').waitFor();
    assert.match(await dialog.locator('.form-error').innerText(),/غير صحيحة/);
    assert.equal(await p.evaluate(()=>qa.written.length),0);await password.fill(encPass);await next();await title('النسخة قابلة للقراءة');
    assert.match(await dialog.innerText(),/نسخة تصنيف: عملاء هذا الجهاز/);assert.match(await dialog.innerText(),/SQLite.*فك التشفير/);
    assert.doesNotMatch(await dialog.innerText(),/DESTINATION|مورد الساحة|777001223/);
    for(const width of [280,320,393,720,1250]){await p.setViewportSize({width,height:850});assert.ok(await dialog.evaluate(e=>e.scrollWidth<=e.clientWidth+1),`dialog fits ${width}`);}
    const shot=process.env.QAYD_REVIEW_SHOT;if(shot)await p.screenshot({path:shot});
    await close();await picker.setInputFiles(legacy);await title('تم التعرف على ملف الدفتر القديم');
    assert.doesNotMatch(await dialog.innerText(),/مخزن اختباري|PRIVATE_TEST/);await close();
    await picker.setInputFiles(bad);await title('تعذّر التحقق من النسخة');assert.match(await dialog.innerText(),/الدفتر/);await close();
    for(const bytes of [Buffer.from('{"schema":666}'),Buffer.from([0xff,0xfe])]){
      await picker.setInputFiles({name:'invalid.json',mimeType:'application/json',buffer:bytes});
      await title('تعذّر التحقق من النسخة');assert.equal(await dialog.locator('[type=submit]').count(),0);await close();
    }
    await picker.setInputFiles(db);await title('فحص نسخة مشفّرة');await close();
    assert.deepEqual(await p.evaluate(()=>qa.written),[]);assert.deepEqual(online,[]);assert.deepEqual(errs,[]);
    assert.deepEqual(fs.readFileSync(db),initialBytes);assert.deepEqual(fs.readFileSync(legacy),legacyBytes);
    console.log('Offline backup review: about/contact, complete JSON, encrypted category SQLite, wrong password, invalid and legacy files, cancellation and original-file/no-network/no-ledger-write checks.');
  }finally{await browser?.close();fs.rmSync(tmp,{recursive:true,force:true});}
})().catch(e=>{console.error(e);process.exitCode=1;});
