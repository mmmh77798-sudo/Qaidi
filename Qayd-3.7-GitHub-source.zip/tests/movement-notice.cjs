const {localSetting}=require('./navigation.cjs');
const {chromium}=require('playwright');
const assert=require('node:assert/strict');
const {pathToFileURL}=require('node:url');
const path=require('node:path');
const L=require('../app/ledger.js');
const url=pathToFileURL(path.resolve(__dirname,'../app/index.html')).href;
const clean=t=>t.replace(/[\u2066-\u2069]/g,'');
function fixture(){
  const d=L.empty();d.currencies[0].name='محلي';
  d.accounts=[['client','عميل اختبار', '+967771554000'],['missing','حساب بلا رقم',''],['other','حساب آخر','+967771554099']]
    .map(([id,name,phone])=>({id,name,phone,color:'mint'}));
  for(const [code,amount] of [['YER','33350'],['SAR','200']])L.saveEntry(d,{kind:'credit',account:'client',amount,code,day:'2026-10-10',memo:'ملاحظة خاصة لا ترسل'});
  L.closeBalance(d,'client','YER','2026-10-31');
  // Match preferences in existing pre-1.8 ledgers, including the former "none" channel.
  delete d.settings.notify.quickAdded;d.settings.notify.localAdd=true;
  return d;
}
(async()=>{
  const browser=await chromium.launch();
  try{
    const p=await browser.newPage({viewport:{width:360,height:780},hasTouch:true,isMobile:true});
    p.setDefaultTimeout(6500);const errors=[];p.on('pageerror',e=>errors.push(e.message));
    await p.context().setOffline(true);
    await p.addInitScript(raw=>{
      Object.assign(window,{raw,osNotices:0,sent:[],picks:[],creates:[],failSave:false});
      window.QaydAndroid={readLedger:()=>window.raw,writeLedger:next=>{if(window.failSave)return false;window.raw=next;return true;},
        amountAdded:()=>window.osNotices++,compose:(...args)=>window.sent.push(args),copyText:txt=>{window.copied=txt;},
        pickPhoneContact:ticket=>window.picks.push(ticket),createPhoneContact:(ticket,name)=>window.creates.push([ticket,name])};
    },JSON.stringify(fixture()));
    await p.clock.install({time:new Date('2026-11-18T09:00:00Z')});
    await p.clock.pauseAt(new Date('2026-11-18T09:01:00Z'));
    await p.goto(url);
    const dialog=p.locator('#dialog'),notice=p.locator('#movement-notice'),msg=dialog.locator('#draft-message');
    const click=(action,root=p,extra='')=>root.locator('[data-action="'+action+'"]'+extra+':visible').first().click();
    const nav=view=>click('go',p.locator('#mobilebar'),`[data-view=${view}]`);
    const field=name=>dialog.locator(`[name=${name}]`);
    const close=()=>click('close-dialog',dialog);
    const submit=()=>dialog.locator('button[type=submit]').click();
    const state=()=>p.evaluate(()=>JSON.parse(window.raw));
    const reveal=()=>click('movement-notice-send',notice);
    const calls=()=>p.evaluate(()=>({picks:picks.length,creates:creates.length,sent:sent.length,osNotices}));
    const result=(state,value='',ticket)=>p.evaluate(({state,value,ticket})=>qaydPhoneContactResult(ticket||picks.at(-1),state,value),{state,value,ticket});
    const settings=key=>localSetting(p,key);
    const saveSettings=key=>p.locator(`[data-config=${key}] button[type=submit]`).click();
    const insert=async(name,amount,{kind='credit',code='YER',memo=''}={})=>{
      await click('new-entry');await field('accountName').fill(name);await field('amount').fill(amount);await field('code').selectOption(code);
      if(kind==='debit')await dialog.locator('label:has([name=kind][value=debit])').click();
      if(memo)await field('memo').fill(memo);
      await submit();
    };
    await settings('profile');await p.locator('[name=business]').fill('مؤسسة الاختبار');await saveSettings('profile');
    await nav('home');await insert('عميل اختبار','5,000',{kind:'debit',memo:'إيصال خاص لا ترسل'});
    assert.equal(await dialog.isVisible(),false);assert.match(await notice.innerText(),/حُفظت الحركة/);
    assert.deepEqual(await notice.getByRole('button').allTextContents(),['إغلاق','إرسال']);
    assert.deepEqual(await calls(),{picks:0,creates:0,sent:0,osNotices:1});
    assert.equal(L.balances(await state(),'YER').get('client').minor,28350000);
    if(process.env.QAYD_NOTICE_SCREENSHOTS)await p.screenshot({path:process.env.QAYD_NOTICE_SCREENSHOTS+'/notice.png'});
    await p.clock.runFor(2999);assert.equal(await notice.isVisible(),true);
    await p.clock.runFor(1);assert.equal(await notice.isVisible(),false);assert.equal(await dialog.isVisible(),false);
    assert.equal((await calls()).sent,0);
    // The same draft is available without any timer, from the actual movement details.
    const entry=(await state()).entries.at(-1);
    await nav('moves');await click('entry-info',p,`[data-id="${entry.id}"]`);await click('draft-recipients',dialog);
    const example='إشعار من مؤسسة الاختبار:\nلك 5,000 محلي واصل\nالإجمالي - عليك 28,350 محلي';
    assert.equal(clean(await msg.inputValue()),example);
    assert.match(await dialog.locator('.short-phone').innerText(),/^\+967771554000$/);
    assert.equal((await calls()).sent,0);
    await click('copy-draft',dialog);assert.equal(clean(await p.evaluate(()=>window.copied)),example);
    await click('compose-message',dialog,'[data-channel=sms]');
    assert.equal(await p.evaluate(()=>sent[0][1]),'+967771554000');assert.equal(clean(await p.evaluate(()=>sent[0][2])),example);
    await close();
    // A failed write must produce no offer or OS alert. An edit produces no offer either.
    await click('entry-info',p,`[data-id="${entry.id}"]`);await click('edit-entry',dialog);
    await field('memo').fill('تعديل فقط');await submit();assert.equal(await notice.isVisible(),false);
    assert.equal((await calls()).osNotices,1);
    await p.evaluate(()=>window.failSave=true);await insert('عميل اختبار','1');
    assert.match(await dialog.locator('.form-error').innerText(),/لم تُحفظ التغييرات/);
    assert.equal(await notice.isVisible(),false);assert.equal((await calls()).osNotices,1);await close();
    await p.evaluate(()=>window.failSave=false);
    // Explicit dismiss is as silent as expiry and does not undo a saved movement.
    await insert('عميل اختبار','3.125',{code:'SAR'});await click('movement-notice-close',notice);
    assert.equal((await state()).entries.at(-1).legs[0].minor,3125);
    assert.equal(await notice.isVisible(),false);assert.equal(await dialog.isVisible(),false);assert.equal((await calls()).sent,1);
    // No phone: both system routes and a visible manual field, with an explicit save.
    await insert('حساب بلا رقم','2.501');await reveal();
    assert.match(await dialog.locator('h2').innerText(),/رقم هاتف الحساب/);
    assert.equal(await field('phone').inputValue(),'');assert.equal((await calls()).picks,0);
    if(process.env.QAYD_NOTICE_SCREENSHOTS)await p.screenshot({path:process.env.QAYD_NOTICE_SCREENSHOTS+'/phone.png'});
    await click('contact-create',dialog);
    const created=await p.evaluate(()=>creates.at(-1));assert.equal(created[1],'حساب بلا رقم');
    await result('returned','',created[0]);assert.match(await dialog.locator('#contact-status').innerText(),/إذا حفظت/);
    await click('contact-pick',dialog);await result('cancelled');assert.match(await dialog.locator('#contact-status').innerText(),/لم يُختر/);
    await click('contact-pick',dialog);await result('invalid');assert.match(await dialog.locator('#contact-status').innerText(),/تعذّر قراءة/);
    await click('contact-pick',dialog);await result('picked','+967771554111','old9');assert.equal(await field('phone').inputValue(),'');
    await result('picked','\u200e٠٠٩٦٧ ٧٧١\u2011554 111');
    assert.equal(await field('phone').inputValue(),'+967771554111');
    assert.equal((await state()).accounts.find(a=>a.id==='missing').phone,'');assert.equal((await calls()).sent,1);
    await submit();assert.equal((await state()).accounts.find(a=>a.id==='missing').phone,'+967771554111');
    assert.match(clean(await msg.inputValue()),/عليك 2\.501 محلي\nالإجمالي - عليك 2\.501 محلي$/);
    assert.equal(await dialog.locator('[data-action=compose-message]').count(),2);assert.equal((await calls()).sent,1);
    // Editing the number does not lose the draft. A picker failure still allows typing.
    await msg.fill('إشعار راجعته يدويًا');await click('edit-draft-phone',dialog);
    await click('contact-pick',dialog);await result('unavailable');assert.match(await dialog.locator('#contact-status').innerText(),/يمكنك كتابة/);
    await field('phone').fill('123');await submit();assert.match(await dialog.locator('.form-error').innerText(),/رقمًا صحيحًا/);
    await field('phone').fill('٠٧٧١٥٥٤١١٢');await submit();assert.equal((await state()).accounts.find(a=>a.id==='missing').phone,'+967771554112');
    assert.equal(await msg.inputValue(),'إشعار راجعته يدويًا');
    await click('compose-message',dialog,'[data-channel=wa]');assert.deepEqual(await p.evaluate(()=>sent.at(-1)),['wa','+967771554112','إشعار راجعته يدويًا',false]);
    await close();
    // Transfers offer one chosen recipient. They don't include the other name by default.
    await click('new-transfer');await field('from').selectOption('other');await field('to').selectOption('missing');await field('amount').fill('1.125');await submit();await reveal();
    assert.match(await dialog.locator('h2').innerText(),/مسودة إشعار تحويل/);
    await click('draft-entry',dialog,'[data-account=other]');assert.match(clean(await msg.inputValue()),/تحويل: لك 1\.125 محلي\nالإجمالي - لك 1\.125 محلي/);
    assert.doesNotMatch(await msg.inputValue(),/حساب بلا رقم|واصل/);assert.equal((await calls()).sent,2);await close();
    await settings('notifications');await p.locator('[name=quickAdded]').uncheck();await saveSettings('notifications');
    await nav('home');await insert('عميل جديد بلا هاتف','7');assert.equal((await state()).settings.notify.quickAdded,false);assert.equal(await notice.isVisible(),false);
    // A stale result after closing a number editor has no effect on ledger or UI.
    await nav('moves');await click('entry-info',p,`[data-id="${(await state()).entries.at(-1).id}"]`);await click('draft-recipients',dialog);
    await click('contact-pick',dialog);await close();await result('picked','+967771554113');
    assert.equal(await dialog.isVisible(),false);assert.equal((await state()).accounts.at(-1).phone,'');
    assert.deepEqual(errors,[]);
    // Without an Android bridge the same flow keeps manual entry, not a broken Contacts button.
    const preview=await browser.newPage({viewport:{width:390,height:820},hasTouch:true,isMobile:true});
    await preview.context().setOffline(true);
    await preview.addInitScript(raw=>localStorage.setItem('qayd.ledger.v1',raw),JSON.stringify(fixture()));
    await preview.goto(url);
    await preview.locator('[data-action=new-entry]:visible').first().click();
    const webDialog=preview.locator('#dialog');
    await webDialog.locator('[name=accountName]').fill('حساب بلا رقم');
    await webDialog.locator('[name=amount]').fill('5');
    await webDialog.locator('button[type=submit]').click();
    await preview.locator('#movement-notice [data-action=movement-notice-send]').click();
    assert.equal(await webDialog.locator('[data-action=contact-pick],[data-action=contact-create]').count(),0);
    await webDialog.locator('[name=phone]').fill('+967771554114');await webDialog.locator('button[type=submit]').click();
    assert.equal(await webDialog.locator('#draft-phone').inputValue(),'+967771554114');
    await preview.close();
    console.log('Movement notice: exact 3 s, recovery, signed recipient wording, saved currency balance, no implicit send, Android-shaped picker/create/cancel/failure and manual fallback passed.');
  }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
