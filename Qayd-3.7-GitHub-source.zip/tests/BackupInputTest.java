package app.qayd.ledger;

import java.io.ByteArrayInputStream;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.StandardCharsets;

public final class BackupInputTest {
    public static void main(String[] args)throws Exception {
        String json="{\"label\":\"دفتر تجريبي 📁\"}";
        byte[] b=json.getBytes(StandardCharsets.UTF_8);
        if(!BackupInput.read(new ByteArrayInputStream(b),b.length).equals(json))throw new AssertionError("UTF-8 changed");
        try{BackupInput.read(new ByteArrayInputStream(b),b.length-1);throw new AssertionError("Limit failed");}catch(BackupInput.LimitExceeded expected){}
        try{BackupInput.read(new ByteArrayInputStream(new byte[]{(byte)0xc3,0x20}),8);throw new AssertionError("Invalid UTF-8 accepted");}catch(CharacterCodingException expected){}
        if(!"name.json".equals(BackupInput.label(" \u202ename.json\n")))throw new AssertionError("Unsafe label accepted");
        byte[] sqlite=new byte[1024];byte[] magic="SQLite format 3\0".getBytes(StandardCharsets.US_ASCII);
        System.arraycopy(magic,0,sqlite,0,magic.length);sqlite[512]=(byte)0xff;
        BackupInput.Content packet=BackupInput.document(new ByteArrayInputStream(sqlite),32,1024);
        if(packet.json!=null||packet.length()!=1024||packet.db[512]!=(byte)0xff)throw new AssertionError("SQLite misclassified");
        try{BackupInput.document(new ByteArrayInputStream(sqlite),1024,100);throw new AssertionError("DB cap failed");}catch(BackupInput.LimitExceeded expected){}
        if(!json.equals(BackupInput.document(new ByteArrayInputStream(b),b.length,1024).json))throw new AssertionError("JSON prefix lost");
        System.out.println("Backup intake: binary SQLite, strict UTF-8, size caps and safe labels verified.");
    }
}
