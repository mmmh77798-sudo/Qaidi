const {deskNav}=require('./navigation.cjs');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const https=require('node:https');
const {execFileSync}=require('node:child_process');
const {chromium}=require('playwright');
const P=require('../shared/policy.cjs');const A=require('../shared/auth.cjs');
const {createDesk}=require('../shared/server.cjs');const {SQLiteStore}=require('../shared/store.cjs');
const L=require('../app/ledger.js');const V=require('../app/vault.js');
const {fixture}=require('./category-fixtures.cjs');
const key='Synthetic-Owner-Test-Pass-123',staffKey='Synthetic-Subuser-Pass-123';
const attach=(p,errors)=>{p.setDefaultTimeout(11000);p.on('pageerror',e=>errors.push(e.message));p.on('console',m=>{if(m.type()==='error'&&!/status of (401|403|404|409)/.test(m.text()))errors.push(m.text());});return p;};
const nav=async(p,page)=>{
  await deskNav(p,page);
  const labels={home:'نظرة عامة',accounts:'الحسابات',movements:'الحركات',reports:'التقارير',users:'المستخدمون الفرعيون',book:'إعدادات الدفتر'};
  await p.locator('#page').getByRole('heading',{name:labels[page],level:1,exact:true}).waitFor();
};
const click=(p,action)=>p.locator(`[data-action=${action}]:visible`).first().click();
const d=p=>p.locator('#dialog');
const title=(p,t)=>d(p).getByRole('heading',{name:t,exact:true}).waitFor();
const fill=(p,n,v)=>d(p).locator(`[name="${n}"]`).fill(v);
const save=p=>d(p).locator('button[type=submit]').click();
const close=p=>d(p).locator('.modal-head [data-action=close]').click();
const cat=(p,id)=>d(p).locator(`.perm[data-category="${id}"]`);
const check=(p,id,k)=>cat(p,id).locator(`[data-permission=${k}]`).check();
const view=p=>p.locator('#page');
async function logIn(p,name,pass){await p.locator('#login-form [name=login]').fill(name);await p.locator('#login-form [name=password]').fill(pass);await p.locator('#login-form [type=submit]').click();}
async function choosePassword(p,old,pass){for(const [n,v] of [['current',old],['password',pass],['again',pass]])await p.locator(`#password-first [name=${n}]`).fill(v);await p.locator('#password-first [type=submit]').click();}
function makeDb(dst,raw){
  const source=path.join(path.dirname(dst),'backup.json');fs.writeFileSync(source,JSON.stringify(raw));
  execFileSync('python3',['-c',`import sqlite3, sys
cx=sqlite3.connect(sys.argv[1]);cx.executescript('PRAGMA application_id=1363237188; PRAGMA user_version=1; CREATE TABLE qayd_backup(part INTEGER PRIMARY KEY,payload BLOB NOT NULL);')
content=open(sys.argv[2],'rb').read();cx.executemany('INSERT INTO qayd_backup VALUES(?, ?)',((i//65536,content[i:i+65536]) for i in range(0,len(content),65536)));cx.commit();cx.close()`,dst,source]);
}
(async()=>{
  const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'qayd-shared-browser-')),errors=[];
  const store=new SQLiteStore(path.join(tmp,'ledger.sqlite'));let serve,demo,browser;
  try{
    execFileSync('openssl',['req','-x509','-newkey','rsa:2048','-nodes','-days','1','-subj','/CN=127.0.0.1','-addext','subjectAltName=IP:127.0.0.1','-keyout',path.join(tmp,'key.pem'),'-out',path.join(tmp,'cert.pem')],{stdio:'ignore'});
    const empty=P.fresh();empty.users.push(A.makeUser('owner','مالك الدفتر',await A.hash(key),{owner:true}));store.init(empty);
    serve=https.createServer({key:fs.readFileSync(path.join(tmp,'key.pem')),cert:fs.readFileSync(path.join(tmp,'cert.pem'))});
    await new Promise(r=>serve.listen(0,'127.0.0.1',r));const url=`https://127.0.0.1:${serve.address().port}`;
    serve.on('request',createDesk({store,origin:url,onError:e=>errors.push(e.message)}).listeners('request')[0]);
    browser=await chromium.launch();
    const ownerContext=await browser.newContext({ignoreHTTPSErrors:true,viewport:{width:1250,height:860},acceptDownloads:true});
    const owner=attach(await ownerContext.newPage(),errors);await owner.goto(url);await logIn(owner,'owner',key);
    await view(owner).getByRole('heading',{name:'نظرة عامة',exact:true}).waitFor();
    const cookies=await ownerContext.cookies();assert.equal(cookies.length,1);assert.equal(cookies[0].httpOnly,true);assert.equal(cookies[0].secure,true);assert.equal(cookies[0].sameSite,'Strict');
    assert.equal(await owner.evaluate(()=>document.cookie),'');
    // DB reading and Vault opening happen locally until the owner explicitly approves the upload.
    const source=fixture(),db=path.join(tmp,'source.db');makeDb(db,await V.lock(source,await V.newKey('only-the-import-file-123')));
    await nav(owner,'book');await click(owner,'import');await d(owner).locator('[name=source]').setInputFiles(db);
    await fill(owner,'password','incorrect-123456');await save(owner);await d(owner).locator('#dialog-error').waitFor();
    assert.match(await d(owner).locator('#dialog-error').innerText(),/غير صحيحة/);assert.equal(store.load().s.ledger.accounts.length,0);
    await fill(owner,'password','only-the-import-file-123');await save(owner);await title(owner,'تأكيد نسخ الدفتر');
    assert.equal(store.load().s.ledger.entries.length,0);await save(owner);assert.equal(store.load().s.ledger.entries.length,0);
    await d(owner).locator('[name=confirmed]').check();await save(owner);await d(owner).waitFor({state:'hidden'});
    assert.deepEqual(store.load().s.ledger,source);await owner.locator('[data-action=import]:disabled').waitFor();
    // Owner makes a user with one category and independent capabilities.
    await nav(owner,'users');await click(owner,'new-user');await title(owner,'فتح مستخدم فرعي');
    await fill(owner,'name','موظف المبيعات');await fill(owner,'login','sales.team');
    await check(owner,'clients','view');await check(owner,'clients','addMovement');await check(owner,'clients','reports');
    assert.equal(await cat(owner,'suppliers').locator('[data-permission=view]').isChecked(),false);
    for(const width of [280,320,393,560,880,1250]){
      await owner.setViewportSize({width,height:860});
      assert.ok(await d(owner).evaluate(e=>e.scrollWidth<=e.clientWidth+1),`permissions fit ${width}px`);
    }
    await save(owner);await title(owner,'بيانات دخول المستخدم');
    const pass=await d(owner).locator('[name=invite-pass]').inputValue(),link=await d(owner).locator('[name=invite-link]').inputValue();
    assert.equal(link,url+'/');assert.equal(pass.length,24);assert.ok(!link.includes(pass));await close(owner);
    const userRow=owner.locator('[data-user="sales.team"]');assert.match(await userRow.innerText(),/بانتظار تغيير كلمة السر/);assert.doesNotMatch(await userRow.innerText(),new RegExp(pass));
    const staffCtx=await browser.newContext({ignoreHTTPSErrors:true,viewport:{width:393,height:852},isMobile:true,hasTouch:true,acceptDownloads:true});
    const staff=attach(await staffCtx.newPage(),errors);
    await staff.goto(link);await logIn(staff,'sales.team',pass);await staff.locator('#password-first').waitFor();
    assert.equal(await staff.locator('#page').count(),0);await choosePassword(staff,pass,staffKey);await view(staff).getByRole('heading',{name:'نظرة عامة',exact:true}).waitFor();
    await deskNav(staff,'more');assert.equal(await staff.locator('[data-page=users],[data-page=book]').count(),0);
    await nav(staff,'accounts');assert.equal(await staff.locator('[data-account]').count(),2);
    assert.doesNotMatch(await view(staff).innerText(),/مورد الساحة|مورد النخيل|حساب بلا فئة/);
    assert.equal(await staff.locator('[data-action=new-account],[data-action=edit-account],[data-action=delete-account]').count(),0);
    await staff.locator('[data-account=a] [data-action=new-movement]').click();
    await fill(staff,'amount','14.325');await fill(staff,'memo','SHARED-BROWSER-MOVE');await save(staff);await d(staff).waitFor({state:'hidden'});
    const added=store.load().s.ledger.entries.find(e=>e.memo==='SHARED-BROWSER-MOVE');assert.equal(added.legs[0].minor,14325);
    await nav(owner,'movements');await view(owner).getByText('SHARED-BROWSER-MOVE',{exact:true}).waitFor();
    await nav(staff,'movements');assert.equal(await staff.locator('[data-action=edit-movement],[data-action=delete-movement]').count(),0);
    const bridge=staff.locator('[data-movement="out-move"]');await bridge.waitFor();assert.match(await bridge.innerText(),/طرف تحويل/);assert.doesNotMatch(await bridge.innerText(),/SHARED-MEMO|مورد الساحة/);
    await nav(staff,'reports');assert.equal(await staff.locator('[data-action=report-csv]').count(),0);
    // One context changes the other context's current rights without changing its password or logging it in anew.
    await nav(owner,'users');await userRow.locator('[data-action=edit-user]').click();
    await cat(owner,'clients').locator('[data-permission=addMovement]').uncheck();await check(owner,'clients','exportCsv');
    await save(owner);await d(owner).waitFor({state:'hidden'});await click(staff,'refresh');
    const [dl]=await Promise.all([staff.waitForEvent('download'),click(staff,'report-csv')]);
    const csv=path.join(tmp,'scoped.csv');await dl.saveAs(csv);const csvText=fs.readFileSync(csv,'utf8');
    assert.match(csvText,/مؤسسة الفجر/);assert.doesNotMatch(csvText,/مورد النخيل|مورد الساحة|OUTSIDE/);
    await nav(staff,'movements');assert.equal(await staff.locator('[data-action=new-movement]').count(),0);
    await userRow.locator('[data-action=toggle-user]').click();await title(owner,'إيقاف المستخدم');await save(owner);await d(owner).waitFor({state:'hidden'});
    await click(staff,'refresh');await staff.locator('#login-form').waitFor();assert.equal(await staff.locator('#page').count(),0);
    await nav(owner,'book');assert.match(await view(owner).innerText(),/موظف المبيعات|إضافة حركة/);
    await click(owner,'backup');await fill(owner,'password','Test-Backup-Not-Login123');await fill(owner,'again','Test-Backup-Not-Login123');
    const [download]=await Promise.all([owner.waitForEvent('download'),save(owner)]);
    const backup=path.join(tmp,'download.json');await download.saveAs(backup);
    const copy=JSON.parse(fs.readFileSync(backup,'utf8'));const unpack=(await V.unlock(copy,'Test-Backup-Not-Login123')).value;
    assert.deepEqual(L.validate(unpack),store.load().s.ledger);assert.equal(unpack.users,undefined);
    await ownerContext.close();await staffCtx.close();
    // Public preview is independent, synthetic, embeddable and has separate demo workspaces.
    demo=createDesk({demo:true,onError:e=>errors.push(e.message)});await new Promise(r=>demo.listen(0,'127.0.0.1',r));
    const sample=`http://127.0.0.1:${demo.address().port}`;
    const preview=attach(await browser.newPage({viewport:{width:1150,height:820}}),errors);await preview.goto(sample);await click(preview,'demo');
    await view(preview).getByRole('heading',{name:'المستخدمون الفرعيون',exact:true}).waitFor();
    await nav(preview,'book');assert.equal(await preview.locator('[data-action=import],[data-action=backup]').count(),0);
    const data=await preview.evaluate(()=>({secureCookies:document.cookie,store:localStorage.length}));assert.deepEqual(data,{secureCookies:'',store:0});
    await nav(preview,'users');await click(preview,'new-user');await fill(preview,'name','مشاهد التجربة');await fill(preview,'login','demo.staff');
    await check(preview,'clients','view');await save(preview);await title(preview,'بيانات دخول المستخدم');
    const demoPass=await d(preview).locator('[name=invite-pass]').inputValue(),demoLink=await d(preview).locator('[name=invite-link]').inputValue();
    assert.match(demoLink,/\?demo=[A-Za-z0-9_-]{24}$/);assert.ok(!demoLink.includes(demoPass));
    const another=attach(await browser.newPage({viewport:{width:393,height:852}}),errors);await another.goto(demoLink);
    await logIn(another,'demo.staff',demoPass);await another.locator('#password-first').waitFor();await choosePassword(another,demoPass,staffKey);
    await nav(another,'accounts');assert.ok(await another.locator('[data-account=badr]').count());assert.equal(await another.locator('[data-account=yahya]').count(),0);
    const independent=attach(await browser.newPage(),errors);await independent.goto(sample);await click(independent,'demo');
    await view(independent).getByRole('heading',{name:'المستخدمون الفرعيون',exact:true}).waitFor();assert.equal(await independent.locator('[data-user]').count(),0);
    assert.deepEqual(errors,[]);
    console.log('Shared browser: separate HTTPS sessions, one-time passwords, encrypted DB import with consent, scoped writes and reports, permission changes, suspension, encrypted backup and isolated demo verified.');
  }finally{
    if(browser)await browser.close();
    if(serve)await new Promise(r=>serve.close(r));if(demo)await new Promise(r=>demo.close(r));
    store.close();fs.rmSync(tmp,{recursive:true,force:true});
  }
})().catch(e=>{console.error(e);process.exitCode=1;});
