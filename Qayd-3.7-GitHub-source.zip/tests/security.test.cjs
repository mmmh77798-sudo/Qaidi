'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const T=require('../shared/totp.cjs'),Transport=require('../shared/transport.cjs'),A=require('../shared/auth.cjs');

test('RFC 6238 SHA-1 test vectors and localized six-digit entry match the correct counter',()=>{
  const key=T.encode(Buffer.from('12345678901234567890'));
  assert.equal(key,'GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ');
  assert.equal(T.decode(key).toString(),'12345678901234567890');
  for(const [seconds,expected] of [[59,'94287082'],[1111111109,'07081804'],[1111111111,'14050471'],[1234567890,'89005924'],[2000000000,'69279037'],[20000000000,'65353130']]){
    const now=seconds*1000,step=T.step(now),six=expected.slice(-6);
    assert.equal(T.code(key,step,8),expected);
    assert.equal(T.timeMatch(key,six.replace(/\d/g,x=>String.fromCharCode(1632+Number(x))),now),step);
    assert.equal(T.timeMatch(key,six,now,step),null);
  }
});

test('authenticator state accepts only increasing counters and eight hashed one-use recovery codes',()=>{
  const key=T.seed(),base=1743333330000,counter=T.step(base);
  assert.match(key,/^[A-Z2-7]{32}$/);
  const pack=T.begin(key,counter);
  assert.equal(pack.codes.length,8);assert.equal(new Set(pack.codes).size,8);
  pack.codes.forEach(x=>assert.match(x,/^[A-Z2-7]{4}(?:-[A-Z2-7]{4}){3}$/));
  assert.equal(T.accept(pack.mfa,T.code(key,counter),base),null);
  assert.equal(T.accept(pack.mfa,T.code(key,counter+2),base),null);
  const live=T.accept(pack.mfa,T.code(key,counter+1),base);
  assert.equal(live.value.last,counter+1);assert.equal(live.recovered,false);
  for(const code of pack.codes)assert.ok(!JSON.stringify(pack.mfa).includes(code.replace(/-/g,'')));
  const used=T.accept(live.value,pack.codes[0].toLowerCase(),base);
  assert.equal(used.recovered,true);assert.equal(used.value.recovery.length,7);assert.equal(used.value.last,counter+1);
  assert.equal(T.accept(used.value,pack.codes[0],base),null);
  assert.equal(T.accept(used.value,'ليس رمزًا',base),null);
  assert.equal(pack.mfa.recovery.length,8);
});

test('production transport accepts direct TLS or an explicitly trusted private TLS proxy',()=>{
  const req=(remoteAddress,headers={},encrypted=false)=>({socket:{remoteAddress,encrypted},headers});
  const good={'x-forwarded-proto':'https','x-forwarded-for':'203.0.113.24'};
  assert.equal(Transport.secure(req('203.0.113.24',{},true),false),true);
  assert.equal(Transport.secure(req('127.0.0.1',good),false),false);
  assert.equal(Transport.secure(req('203.0.113.24',good),true),false);
  assert.equal(Transport.secure(req('127.0.0.1'),true),false);
  for(const peer of ['127.0.0.1','::ffff:127.0.0.1','::1','10.3.1.2','172.20.0.3','192.168.4.7','fd65::9']){
    assert.equal(Transport.secure(req(peer,good),true),true,peer);
    assert.equal(Transport.clientAddress(req(peer,good),true),'203.0.113.24');
  }
  for(const proto of ['http','https, http','HTTPS',''])assert.equal(Transport.secure(req('127.0.0.1',{'x-forwarded-proto':proto}),true),false);
  assert.equal(Transport.clientAddress(req('127.0.0.1',{...good,'x-forwarded-for':'192.0.2.3, 203.0.113.24'}),true),'127.0.0.1');
});

test('failed authentication-state commit leaves the previous cookie valid',()=>{
  const owner=A.makeUser('owner','مالك الاختبار',{salt:'unused',digest:'unused'},{owner:true});
  let user=owner;
  const sessions=new A.Sessions(),repo=()=>({load:()=>({s:{users:[user]}})});
  const req=token=>({headers:{cookie:A.sessionCookie(token).split(';')[0]}});
  const t=sessions.issue(owner,'');const previous=sessions.get(req(t),repo).key;
  user=A.bump(owner,true);
  assert.throws(()=>sessions.issue(user,'',{previous,commit:()=>{throw new Error('Synthetic storage error');}}),/storage/);
  user=owner;assert.equal(sessions.get(req(t),repo).user,owner);
  const updated=A.bump(owner,true),next=sessions.issue(updated,'',{previous,commit:()=>{user=updated;}});
  assert.equal(sessions.get(req(next),repo).user,updated);
  assert.throws(()=>sessions.get(req(t),repo),e=>e.code==='login');
});
