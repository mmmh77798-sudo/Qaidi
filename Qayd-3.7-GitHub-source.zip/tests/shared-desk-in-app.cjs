'use strict';
// Uses the packaged files in Chromium and the same Java API client as the APK.
// The Android Activity/file picker are simulated; no real account or remote host is contacted.
const {localNav,localSetting,deskNav}=require('./navigation.cjs');
const assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),https=require('node:https'),readline=require('node:readline');
const {execFileSync,spawn}=require('node:child_process');
const {once}=require('node:events');
const {pathToFileURL}=require('node:url');
const {setTimeout:wait}=require('node:timers/promises');
const {chromium}=require('playwright');
const {fixture}=require('./category-fixtures.cjs');
const source=path.resolve(process.env.QAYD_STAGING_SERVER_DIR||path.join(__dirname,'..'));
const L=require(path.join(source,'app/ledger.js'));
const P=require(path.join(source,'shared/policy.cjs')),A=require(path.join(source,'shared/auth.cjs')),T=require(path.join(source,'shared/totp.cjs'));
const {createDesk}=require(path.join(source,'shared/server.cjs')),{SQLiteStore}=require(path.join(source,'shared/store.cjs'));
const java=process.env.JAVA_HOME?path.join(process.env.JAVA_HOME,'bin','java'):'java';
const keytool=process.env.JAVA_HOME?path.join(process.env.JAVA_HOME,'bin','keytool'):'keytool';
const pOwner='Synthetic-APK-Owner-343242',pStaff='Synthetic-APK-Staff-465021';
const knownLocal='دفتر الهاتف للاختبار فقط',staffMemo='دفعة اختبار الموظف',ownerMemo='حركة اختبار المدير';
const login=p=>p.locator('#login-form'),view=p=>p.locator('#page'),d=p=>p.locator('#dialog');
const click=(p,a)=>p.locator(`[data-action=${a}]:visible`).first().click();
const nav=deskNav;
const field=(s,n)=>s.locator(`[name=${n}]`);
const submit=s=>s.locator('button[type=submit]').click();
const heading=(p,t)=>view(p).getByRole('heading',{name:t,exact:true}).waitFor();
const modal=(p,t)=>d(p).getByRole('heading',{name:t,exact:true}).waitFor();
const permit=(p,k)=>d(p).locator(`[data-category=clients] [data-permission=${k}]`);
async function creds(p,n,pw){await field(login(p),'login').fill(n);await field(login(p),'password').fill(pw);await submit(login(p));}
async function post(p,id,amount,memo){
  await p.locator(`[data-account="${id}"] [data-action=new-movement]`).click();await modal(p,'إضافة حركة');
  await field(d(p),'amount').fill(amount);await field(d(p),'memo').fill(memo);await submit(d(p));await d(p).waitFor({state:'hidden'});
}
(async()=>{
  const classes=process.env.QAYD_DESK_CLASSES,jar=process.env.QAYD_TEAM_JSON_JAR;
  assert.ok(classes&&jar,'Set QAYD_DESK_CLASSES and QAYD_TEAM_JSON_JAR.');
  const root=path.resolve(__dirname,'..'),tmp=fs.mkdtempSync(path.join(os.tmpdir(),'qayd-desk-inapp-'));
  const errors=[],outside=[],requests=[],canceled=[],waiters=new Map(),servers=[];
  let browser,jvm,store,relayExit,sequence=4000,failInfo=false,hold=null,writeFault='',viewFaultCookie='';
  try{
    const apk=process.env.QAYD_TEST_APK;
    if(apk){
      const aapt=path.join(process.env.ANDROID_SDK_ROOT||process.env.ANDROID_HOME||'.','build-tools/35.0.0/aapt2');
      if(fs.existsSync(aapt)){
        const apkManifest=execFileSync(aapt,['dump','xmltree','--file','AndroidManifest.xml',path.resolve(apk)],{encoding:'utf8'});
        for(const target of ['.ProfileActivity','.SharedDeskActivity']){
          const block=apkManifest.split(/\n\s*E: /).find(line=>line.includes('="'+target+'"'));
          assert.match(block||'',/android:exported\(0x[0-9a-f]+\)=false/,target+' must be a registered, non-exported activity');
        }
        assert.match(apkManifest,/\.MainActivity/);assert.match(apkManifest,/android.intent.category.LAUNCHER/);
      }
      execFileSync('unzip',['-qq',path.resolve(apk),'assets/app/*','assets/shared-desk/*','assets/device-profile/*','-d',tmp]);
    }else{
      fs.mkdirSync(path.join(tmp,'assets'));
      fs.cpSync(path.join(root,'app'),path.join(tmp,'assets/app'),{recursive:true});
      execFileSync('python3',[path.join(root,'tools/stage-shared-desk.py'),path.join(tmp,'assets/shared-desk')]);
      execFileSync('python3',[path.join(root,'tools/stage-device-profile.py'),path.join(tmp,'assets/device-profile')]);
    }
    const offlineUrl=pathToFileURL(path.join(tmp,'assets/app/index.html')).href;
    const deskUrl=pathToFileURL(path.join(tmp,'assets/shared-desk/index.html')).href;
    const profileUrl=pathToFileURL(path.join(tmp,'assets/device-profile/index.html')).href;
    const key=path.join(tmp,'key.pem'),cert=path.join(tmp,'cert.pem'),trust=path.join(tmp,'qa-only.p12');
    execFileSync('openssl',['req','-x509','-newkey','rsa:2048','-nodes','-days','1','-subj','/CN=127.0.0.1','-addext','subjectAltName=IP:127.0.0.1','-keyout',key,'-out',cert],{stdio:'ignore'});
    execFileSync(keytool,['-importcert','-noprompt','-storetype','PKCS12','-storepass','synthetic123','-alias','qa','-file',cert,'-keystore',trust],{stdio:'ignore'});
    jvm=spawn(java,['-Dsun.net.http.allowRestrictedHeaders=true','-Dfile.encoding=UTF-8',`-Djavax.net.ssl.trustStore=${trust}`,'-Djavax.net.ssl.trustStorePassword=synthetic123','-cp',`${classes}${path.delimiter}${jar}`,'app.qayd.ledger.SharedDeskBridgeHarness','relay'],{stdio:['pipe','pipe','pipe']});
    relayExit=once(jvm,'exit');
    jvm.stderr.on('data',b=>errors.push(String(b)));
    jvm.on('exit',()=>{for(const p of waiters.values()){clearTimeout(p.timer);p.reject(new Error('JVM relay stopped'));}waiters.clear();});
    readline.createInterface({input:jvm.stdout}).on('line',line=>{
      try{const r=JSON.parse(line),k=`${r.lane}:${r.ticket}`,p=waiters.get(k);if(p){waiters.delete(k);clearTimeout(p.timer);p.resolve(r);}else canceled.push(k);}
      catch{errors.push('Malformed JVM response');}
    });
    const wire=q=>jvm.stdin.write(JSON.stringify(q)+'\n');
    const relay=q=>new Promise((resolve,reject)=>{
      const k=`${q.lane}:${q.ticket}`,timer=setTimeout(()=>{waiters.delete(k);reject(new Error('JVM relay timed out'));},66000);
      assert.ok(!waiters.has(k));waiters.set(k,{resolve,reject,timer});wire(q);
    });
    const command=(lane,op)=>relay({lane,ticket:'control-'+(++sequence),[op]:true});
    const clear=lane=>command(lane,'clear'),stash=async lane=>(await command(lane,'vaultState')).value;
    const isStaff=lane=>lane==='staff'||lane==='staff-wrong-role';
    const tls={key:fs.readFileSync(key),cert:fs.readFileSync(cert)};
    const start=async make=>{
      const s=https.createServer(tls);s.listen(0,'127.0.0.1');servers.push(s);await once(s,'listening');
      const url=`https://127.0.0.1:${s.address().port}`;s.on('request',make(url));return url;
    };
    store=new SQLiteStore(path.join(tmp,'synthetic.sqlite'));
    const example=fixture();example.accounts.find(a=>a.id==='a').phone='+967 770 111 345';
    const initial=P.fresh(example),ownerUser=A.makeUser('owner','مدير قيد للاختبار',await A.hash(pOwner),{owner:true}),seed=T.seed();
    const ownerMfa=T.begin(seed,T.step(Date.now())-2);ownerUser.mfa=ownerMfa.mfa;initial.users.push(ownerUser);store.init(initial);
    const origin=await start(url=>{
      const app=createDesk({store,origin:url,onError:e=>errors.push(e.message)}).listeners('request')[0];
      return (req,res)=>{
        requests.push({url:req.url,method:req.method,passive:req.headers['x-qayd-passive'],cookie:!!req.headers.cookie});
        if(hold&&req.url===hold.path){const h=hold;hold=null;h.ready(()=>app(req,res));return;}
        if(failInfo&&req.url==='/api/info'){failInfo=false;res.writeHead(503,{'Content-Type':'application/json'});res.end(JSON.stringify({error:'الخادم نائم للاختبار.'}));return;}
        if(viewFaultCookie&&req.url.startsWith('/api/desk')&&req.headers.cookie===viewFaultCookie){
          viewFaultCookie='';res.writeHead(503,{'Content-Type':'application/json'}).end('{"error":"تعذّر تحديث العرض للاختبار.","code":""}');return;
        }
        if(writeFault&&req.url==='/api/book/change'){
          const fault=writeFault,end=res.end;writeFault='';
          res.end=function(...args){
            if(res.statusCode===200){
              if(fault==='lose-reply'){res.destroy();return res;} // The synthetic ledger commit happened already.
              if(fault==='fail-refresh')viewFaultCookie=req.headers.cookie;
            }
            return end.apply(res,args);
          };
        }
        app(req,res);
      };
    });
    const call=(lane,route,body,passive=false,at=origin,remember=false)=>relay({lane,origin:at,ticket:'desk-'+(++sequence),route,body:body===undefined?'':JSON.stringify(body),passive,remember,employee:isStaff(lane)});
    const testLogin={login:'owner',password:pOwner};
    let edgeHits=[];
    const redirect=await start(()=> (req,res)=>{edgeHits.push(req.method);res.writeHead(302,{Location:origin+'/api/info'}).end();});
    assert.equal((await call('redirect','login',testLogin,false,redirect)).value.code,'redirect');
    assert.deepEqual(edgeHits,['GET']);assert.equal(requests.length,0);
    edgeHits=[];
    const demo=await start(()=> (req,res)=>{edgeHits.push(req.method);res.writeHead(200,{'Content-Type':'application/json'}).end('{"demo":true,"version":"3.1"}');});
    assert.equal((await call('demo','login',testLogin,false,demo)).value.code,'demo');assert.deepEqual(edgeHits,['GET']);
    edgeHits=[];
    const old=await start(()=> (req,res)=>{edgeHits.push(req.method);res.writeHead(200,{'Content-Type':'application/json'}).end('{"demo":false,"version":"3.0"}');});
    assert.equal((await call('older','login',testLogin,false,old)).value.code,'version');assert.deepEqual(edgeHits,['GET']);
    const badTls=origin.replace('127.0.0.1','localhost');
    assert.equal((await call('wrong-certificate','info',undefined,false,badTls)).value.code,'tls');assert.equal(requests.length,0);
    assert.equal((await call('anonymous','book/backup')).value.code,'request');
    assert.equal((await call('anonymous','desk')).value.code,'login');assert.equal(requests.length,0);
    const publicInfo=await call('anonymous','info');assert.equal(publicInfo.status,200);assert.equal(publicInfo.value.version,process.env.QAYD_EXPECT_API||'3.4');
    const roleReject=await call('staff-wrong-role','login',{...testLogin,otp:ownerMfa.codes[0]},false,origin,true);
    assert.equal(roleReject.status,403);assert.equal(roleReject.value.code,'staff-role');
    assert.deepEqual(await stash('staff-wrong-role'),{stored:false,writes:0});
    assert.equal((await call('staff-wrong-role','desk')).status,401);
    assert.equal((await call('anonymous','device-login')).status,400);
    browser=await chromium.launch();
    const local=L.empty(),only=L.addAccount(local,{name:knownLocal,category:'clients',note:'NO-UPLOAD-OFFLINE'});
    L.saveEntry(local,{kind:'credit',account:only.id,code:'YER',amount:'205.125',memo:'LOCAL-ONLY-MOVEMENT',day:L.localDay()});
    const localRaw=JSON.stringify(local);
    async function device(lane,saved,width){
      const employee=isStaff(lane),c=await browser.newContext({viewport:{width,height:852},isMobile:true,hasTouch:true});
      const records={clear:0,exit:0,change:0,maintenance:[],downloads:[],writeNotice:''};let launchQuick=false;const watch=p=>{
        p.on('pageerror',e=>errors.push(e.message));
        p.on('console',e=>{if(e.type()==='error')errors.push(e.text());});
        p.on('request',r=>{if(!r.url().startsWith('file:'))outside.push(r.url());});
      };
      await c.setOffline(true);
      await c.exposeFunction('qaRelay',(id,route,body,passive,remember)=>relay({lane,origin,ticket:id,route,body,passive,remember,employee}));
      await c.exposeFunction('qaClear',async()=>{records.clear++;await clear(lane);});
      await c.exposeFunction('qaExit',async()=>{records.exit++;await clear(lane);});
      await c.exposeFunction('qaManager',async()=>{records.change++;await clear(lane);});
      await c.exposeFunction('qaMaintenance',(...args)=>records.maintenance.push(args));
      await c.exposeFunction('qaWriteNotice',state=>{records.writeNotice=state;});
      await c.exposeFunction('qaForget',()=>command(lane,'forget'));
      await c.exposeFunction('qaSave',(name,csv)=>records.downloads.push({name,csv}));
      const before=requests.length,setup=await c.newPage();watch(setup);
      await setup.addInitScript(()=>{
        window.choices=[];
        window.QaydProfile={setup:()=>JSON.stringify({role:'',origin:'',editing:false}),choose:(...v)=>choices.push(v),leave:()=>{}};
      });
      await setup.goto(profileUrl);await setup.getByRole('heading',{name:'كيف ستستخدم قيد؟'}).waitFor();
      assert.deepEqual(await setup.evaluate(()=>[typeof QaydAndroid,typeof QaydDesk,localStorage.length]),['undefined','undefined',0]);
      assert.ok(await setup.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1));
      let phone=null;
      if(employee){
        await setup.locator('[data-role=staff]').click();const field=setup.locator('#origin');
        await field.fill('http://test-manager.example.test');await submit(setup.locator('#profile-link'));
        assert.match(await setup.locator('#profile-error').innerText(),/HTTPS/);assert.deepEqual(await setup.evaluate(()=>choices),[]);
        await setup.locator('[data-action=current]').click();assert.equal(await field.inputValue(),'https://qayd-production.up.railway.app');
        await field.fill(origin+'/');await submit(setup.locator('#profile-link'));
        assert.deepEqual(await setup.evaluate(()=>choices),[['staff',origin]]);
      }else{
        await setup.locator('[data-role=manager]').click();assert.deepEqual(await setup.evaluate(()=>choices),[['manager','']]);
        phone=await c.newPage();watch(phone);
        await phone.addInitScript(localRaw=>{
          window.offlineOps={open:[],quick:[],write:[],legacy:[],outside:[],mode:[]};window.open=(...args)=>offlineOps.outside.push(args);
          window.QaydAndroid={readLedger:()=>localRaw,writeLedger:(...args)=>{offlineOps.write.push(args);return true;},
            openSharedDesk:(...args)=>offlineOps.open.push(args),openSharedPosting:(...args)=>offlineOps.quick.push(args),
            configureDeviceMode:at=>offlineOps.mode.push(at),teamRequest:(...args)=>offlineOps.legacy.push(args),teamClear:()=>{}};
        },localRaw);
        await phone.goto(offlineUrl);
        const setKey='qayd.shared.origin.v1';
        await heading(phone,'دفتر الهاتف');
        assert.match(await phone.locator('.record-shared').innerText(),/يحتاج إلى ربط/);
        assert.equal(await phone.locator('[data-action=shared-post-open]').count(),0);
        await click(phone,'shared-desk-open');
        const config=phone.locator('#team-origin-form');await config.waitFor();
        assert.deepEqual(await phone.evaluate(()=>offlineOps.quick),[]);
        if(saved){await field(config,'origin').fill(origin+'/');await submit(config);await phone.locator('.team-server').waitFor();}
        assert.deepEqual(await phone.evaluate(()=>[offlineOps.open,offlineOps.quick,offlineOps.legacy]),[[],[],[]]);
        await localSetting(phone,'device-mode');await click(phone,'device-mode-choose');
        assert.deepEqual(await phone.evaluate(()=>offlineOps.mode),[origin]);
        await localNav(phone,'home');
        assert.match(await phone.locator('.record-shared').innerText(),/للفريق.*الإنترنت/);
        await click(phone,'shared-desk-open');
        // A phone-only draft is never supplied to the quick-post bridge.
        await click(phone,'new-entry');await d(phone).locator('[data-destination=phone]').waitFor();
        assert.match(await d(phone).locator('[type=submit]').innerText(),/دفتر الهاتف/);
        await field(d(phone),'accountName').fill(knownLocal);await field(d(phone),'amount').fill('12.325');
        await field(d(phone),'memo').fill('UNSENT-LOCAL-DRAFT');await d(phone).locator('[data-action=close-dialog]').first().click();
        await click(phone,'shared-post-open');
        assert.equal(await phone.evaluate(k=>localStorage.getItem(k),setKey),origin);
        assert.deepEqual(await phone.evaluate(()=>offlineOps),{open:[[origin]],quick:[[origin]],write:[],legacy:[],outside:[],mode:[origin]});
        launchQuick=true;
      }
      assert.deepEqual(requests.slice(before).filter(r=>!(r.method==='GET'&&r.passive==='1')),[],
        'setup and routing issue no requests; passive polling on other logged-in pages can continue');
      await setup.close();
      async function open(startingKept=false){
        const p=await c.newPage();watch(p);
        await p.addInitScript(({employee,origin,startingKept,launchQuick,startingNotice})=>{
          let kept=startingKept,notice=startingNotice;
          window.QaydDesk={origin:()=>origin,employeeMode:()=>employee,takeQuickPost:()=>launchQuick||employee,canRemember:()=>employee,hasRemembered:()=>kept,
            readWriteNotice:()=>notice,writeWriteNotice:value=>{notice=value;void qaWriteNotice(value);return true;},
            forgetRemembered:()=>{kept=false;void qaForget();return true;},changeManager:()=>qaManager(),openMaintenance:(...args)=>qaMaintenance(...args),
            request:async(id,route,body,passive,remember)=>{
              const {value,status}=await qaRelay(id,route,body,passive,remember),bytes=new TextEncoder().encode(JSON.stringify(value));
              if(typeof value.deviceSaved==='boolean')kept=value.deviceSaved;
              if(value.code==='saved-login'||route==='logout')kept=false;
              let utf='';for(let i=0;i<bytes.length;i++)utf+=String.fromCharCode(bytes[i]);const enc=btoa(utf);
              for(let i=0;i<enc.length;i+=49152)window.qaydDeskReply(id,status,enc.slice(i,i+49152),i+49152>=enc.length);
            },clear:()=>qaClear(),exit:()=>qaExit(),saveCsv:(name,csv)=>qaSave(name,csv)};
        },{employee,origin,startingKept,launchQuick,startingNotice:records.writeNotice});
        launchQuick=false;await p.goto(deskUrl);
        assert.deepEqual(await p.evaluate(()=>[typeof QaydAndroid,typeof Vault,document.cookie]),['undefined','undefined','']);
        return p;
      }
      return {c,phone,p:await open(),open,records};
    }
    failInfo=true;
    const manager=await device('owner',true,393),owner=manager.p;
    await owner.locator('.app-boot .error').waitFor();await click(owner,'desk-connect');
    await login(owner).waitFor();
    await click(owner,'desk-show-otp');assert.equal(await field(login(owner),'otp').isVisible(),true);await click(owner,'desk-show-otp');
    await creds(owner,'owner',pOwner);await field(login(owner),'otp').waitFor();assert.equal(await view(owner).count(),0);
    assert.match(await owner.locator('.gate-main').innerText(),/لفتح نموذج حركة في الدفتر المشترك/);
    await field(login(owner),'otp').fill(T.code(seed,T.step(Date.now())));await submit(login(owner));await modal(owner,'إضافة حركة');
    assert.equal(await field(d(owner),'account').inputValue(),'');
    assert.match(await d(owner).locator('[data-destination=shared]').innerText(),/بحسب صلاحياته/);
    assert.match(await d(owner).locator('[type=submit]').innerText(),/حفظ في الدفتر المشترك/);
    assert.ok(!requests.some(x=>x.url==='/api/book/change'));
    const shots=process.env.QAYD_POSTING_SHOTS;
    if(shots){await manager.phone.screenshot({path:path.join(shots,'home.png')});await owner.screenshot({path:path.join(shots,'shared-entry.png')});}
    await d(owner).locator('[data-action=close]').first().click();await heading(owner,'نظرة عامة');
    assert.match(await owner.locator('.top').innerText(),/المالك/);
    await nav(owner,'users');await heading(owner,'المستخدمون الفرعيون');await click(owner,'new-user');await modal(owner,'فتح مستخدم فرعي');
    await field(d(owner),'name').fill('الموظف للاختبار');await field(d(owner),'login').fill('qa.staff');
    for(const k of ['view','addMovement','reports','exportCsv'])await permit(owner,k).check();
    await submit(d(owner));await modal(owner,'بيانات دخول المستخدم');
    const temporary=await field(d(owner),'invite-pass').inputValue();assert.equal(temporary.length,24);
    assert.equal(await field(d(owner),'invite-link').inputValue(),origin+'/');
    await owner.locator('[data-user="qa.staff"]').waitFor({state:'attached'});await d(owner).locator('[data-action=close]').first().click();
    await nav(owner,'home');await heading(owner,'نظرة عامة');
    const employee=await device('staff',false,360);let staff=employee.p;
    assert.equal(employee.phone,null);await login(staff).waitFor();
    assert.equal(await staff.locator('[data-action=leave-desk]').count(),0);
    assert.equal(await field(login(staff),'remember').isChecked(),false);
    await field(login(staff),'remember').check();await creds(staff,'qa.staff',temporary);const first=staff.locator('#password-first');await first.waitFor();
    assert.equal(await view(staff).count(),0);assert.equal((await call('staff','desk')).value.code,'password-required');
    assert.deepEqual(await stash('staff'),{stored:false,writes:0},'temporary password is never stored');
    assert.equal(await field(first,'remember').isChecked(),true);
    await field(first,'current').fill(temporary);await field(first,'password').fill(pStaff);await field(first,'again').fill(pStaff);await submit(first);await heading(staff,'نظرة عامة');
    assert.match(await staff.locator('.top').innerText(),/مستخدم فرعي/);
    assert.equal(await d(staff).isVisible(),false,'employee shell ignores any quick-post flag');
    assert.deepEqual(await stash('staff'),{stored:true,writes:1});
    assert.ok(await staff.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1));
    await nav(staff,'more');assert.equal(await staff.locator('[data-page=book],[data-page=users]').count(),0);
    await nav(staff,'accounts');await heading(staff,'الحسابات');
    assert.equal(await staff.locator('[data-account]').count(),2);
    assert.doesNotMatch(await view(staff).innerText(),/مورد الساحة|مورد النخيل|NO-UPLOAD|دفتر الهاتف للاختبار/);
    assert.equal(await staff.locator('[data-action=new-account],[data-action=edit-account],[data-action=delete-account]').count(),0);
    const writes=()=>requests.filter(x=>x.url==='/api/book/change'&&x.method==='POST').length;
    await nav(staff,'movements');await heading(staff,'الحركات');await click(staff,'new-movement');await modal(staff,'إضافة حركة');
    const search=d(staff).getByRole('combobox',{name:'الحساب المشترك'}), matches=d(staff).locator('#post-account-options [role=option]');
    await search.focus();assert.equal(await matches.count(),2);assert.doesNotMatch(await d(staff).innerText(),/مورد الساحة|مورد النخيل/);
    await search.fill('الساحة');assert.equal(await matches.count(),0);assert.match(await d(staff).locator('#post-account-hint').innerText(),/لا يوجد حساب مطابق/);
    await search.fill('١٢٢٣');assert.equal(await matches.count(),0,'even phone search excludes hidden accounts');
    await search.fill('٣٤٥');assert.equal(await matches.count(),1);assert.match(await matches.first().innerText(),/مؤسسة الفجر/);
    await search.fill('مُؤَسَّسَة ٱلفَجْر');assert.equal(await matches.count(),1);
    await field(d(staff),'amount').fill('1.125');const beforeSelection=writes();await submit(d(staff));
    assert.match(await d(staff).locator('#dialog-error').innerText(),/اختر الحساب من نتائج البحث/);assert.equal(writes(),beforeSelection);
    await search.press('ArrowDown');await search.press('Enter');assert.equal(await field(d(staff),'account').inputValue(),'a');
    assert.equal(await field(d(staff),'amount').evaluate(el=>el===document.activeElement),true);
    await field(d(staff),'kind').selectOption('transfer');
    await d(staff).locator('#post-to').fill('الندى');await d(staff).locator('#post-to-options [role=option]').first().tap();
    assert.equal(await field(d(staff),'to').inputValue(),'b');assert.equal(await field(d(staff),'account').isDisabled(),true);
    for(const width of [280,320,393,720,1200]){
      await staff.setViewportSize({width,height:852});assert.ok(await d(staff).evaluate(el=>el.scrollWidth<=el.clientWidth+1),`posting fits ${width}px`);
    }
    await staff.setViewportSize({width:360,height:852});await d(staff).locator('[data-action=close]').first().click();
    await nav(staff,'accounts');await heading(staff,'الحسابات');
    const scoped=(await call('staff','desk')).value;
    assert.deepEqual(scoped.categories.map(c=>c.id),['clients']);
    assert.equal((await call('staff','users')).status,403);
    const missing=await call('staff','book/change',{action:'movement-add',fields:{version:scoped.version,kind:'credit',code:'YER',amount:'1.000',day:scoped.today,account:'x'}});
    assert.equal(missing.status,404);
    const forbidden=await call('staff','book/change',{action:'account-add',fields:{version:scoped.version,category:'clients',name:'NOT-AUTHORIZED'}});
    assert.equal(forbidden.status,403);
    assert.equal(store.load().s.bookVersion,scoped.version);
    // A real visible-session poll (20 seconds maximum between checks, plus request time).
    assert.equal(await owner.evaluate(()=>document.visibilityState),'visible');
    const beforePoll=requests.length;
    const oldMinor=L.balances(store.load().s.ledger,'YER').get('a').minor;
    await post(staff,'a','14.325',staffMemo);
    await view(owner).getByText(staffMemo,{exact:true}).waitFor({timeout:26500});
    assert.ok(requests.slice(beforePoll).some(x=>x.url==='/api/status'&&x.passive==='1'&&x.cookie));
    assert.equal(L.balances(store.load().s.ledger,'YER').get('a').minor,oldMinor+14325);
    // Native owner creates and edits records (including a pre-existing non-UUID category).
    await nav(owner,'book');await heading(owner,'إعدادات الدفتر');assert.equal(await owner.locator('[data-action=backup],[data-action=import],[data-action=recovery-export],[data-action=transfer-pick]').count(),0);
    const handoff=owner.locator('#maintenance-panel');assert.equal(await handoff.count(),1);
    if(publicInfo.value.capabilities?.categoryTransfer===1){
      const n=requests.filter(x=>x.method==='POST').length;
      await click(owner,'maintenance-web');
      for(let i=0;i<20&&!manager.records.maintenance.length;i++)await wait(50);
      assert.deepEqual(manager.records.maintenance,[[]]);assert.equal(requests.filter(x=>x.method==='POST').length,n);
    }else{assert.match(await handoff.innerText(),/يتطلب ترقية الخادم/);assert.equal(await owner.locator('[data-action=maintenance-web]').count(),0);}
    assert.equal(await staff.locator('#maintenance-panel,[data-action=maintenance-web]').count(),0);
    await owner.locator('[data-action=edit-category][data-id=clients]').click();await modal(owner,'تعديل التصنيف');
    await field(d(owner),'name').fill('عملاء تجربة أندرويد');await submit(d(owner));await d(owner).waitFor({state:'hidden'});
    await nav(owner,'accounts');await heading(owner,'الحسابات');await click(owner,'new-account');await modal(owner,'إضافة حساب');
    const newName='حساب جديد للاختبار المشترك';
    await field(d(owner),'name').fill(newName);await field(d(owner),'category').selectOption('clients');await submit(d(owner));await d(owner).waitFor({state:'hidden'});
    const rec=store.load().s.ledger.accounts.find(a=>a.name===newName);assert.ok(rec);
    await post(owner,rec.id,'72.005',ownerMemo);
    // Manual refresh is available from any workspace; owner changes appear on staff.
    await click(staff,'refresh');const balance=staff.locator(`[data-account="${rec.id}"]`);
    await balance.waitFor();assert.match(await balance.innerText(),/72\.005/);
    await balance.locator('[data-action=view-account]').click();await heading(staff,'الحركات');
    await view(staff).getByText(ownerMemo,{exact:true}).waitFor();
    assert.equal(await staff.locator('[data-action=edit-movement],[data-action=delete-movement]').count(),0);
    await field(staff.locator('#filters'),'q').fill(ownerMemo);await submit(staff.locator('#filters'));
    await view(staff).getByText(ownerMemo,{exact:true}).waitFor();await staff.locator('[data-action=refresh]').focus();
    // Concurrent dialogs carry their original version. The stale write is rejected, not replayed.
    await nav(staff,'accounts');await heading(staff,'الحسابات');
    await staff.locator(`[data-account="${rec.id}"] [data-action=new-movement]`).click();await modal(staff,'إضافة حركة');
    await field(d(staff),'amount').fill('3.250');await field(d(staff),'memo').fill('STALE-DIALOG-MUST-NOT-SAVE');
    await post(owner,rec.id,'1.125','قيد أحدث على الخادم');await submit(d(staff));
    await d(staff).locator('#dialog-error').waitFor();assert.match(await d(staff).locator('#dialog-error').innerText(),/لم يُحفظ التغيير.*تغيّرت البيانات/);
    assert.equal(await d(staff).locator('[type=submit]').isDisabled(),true);
    assert.ok(!store.load().s.ledger.entries.some(e=>e.memo==='STALE-DIALOG-MUST-NOT-SAVE'));
    await click(staff,'refresh-rejected');await d(staff).waitFor({state:'hidden'});
    await balance.getByText('73.13',{exact:true}).waitFor();
    await nav(staff,'reports');await heading(staff,'التقارير');await click(staff,'report-csv');
    for(let i=0;i<30&&!employee.records.downloads.length;i++)await wait(100);
    assert.equal(employee.records.downloads.length,1);const {name,csv}=employee.records.downloads[0];
    assert.match(name,/^qayd-report-YER-/);assert.equal(csv.charCodeAt(0),0xfeff);
    assert.match(csv,/مؤسسة الفجر/);assert.doesNotMatch(csv,/مورد الساحة|NO-UPLOAD/);
    await nav(staff,'accounts');await heading(staff,'الحسابات');
    const saves=word=>store.load().s.ledger.entries.filter(e=>e.memo===word).length;
    const failSaved='حُفظ القيد قبل فشل تحديث العرض',lost='حُفظ القيد قبل فقد الرد';
    let beforeFault=writes();writeFault='fail-refresh';await post(staff,rec.id,'2.375',failSaved);
    await staff.locator('#write-notice[data-state=saved]').waitFor();
    assert.match(await staff.locator('#write-notice').innerText(),/حُفظ التغيير.*الدفتر المشترك/s);
    assert.equal(saves(failSaved),1);assert.equal(writes(),beforeFault+1);
    await balance.locator('[data-action=new-movement]').click();assert.equal(await d(staff).isVisible(),false);
    await staff.locator('#write-notice [data-action=refresh]').click();await staff.locator('#write-notice').waitFor({state:'hidden'});
    await balance.getByText('75.505',{exact:true}).waitFor();assert.equal(writes(),beforeFault+1);
    beforeFault=writes();writeFault='lose-reply';await post(staff,rec.id,'1.125',lost);
    await staff.locator('#write-notice[data-state=uncertain]').waitFor();
    assert.match(await staff.locator('#write-notice').innerText(),/لم يتأكد الحفظ/);
    assert.equal(saves(lost),1);assert.equal(writes(),beforeFault+1);
    assert.equal(await staff.locator('[data-action=ack-write]').count(),0);
    if(shots)await staff.screenshot({path:path.join(shots,'unknown-save.png')});
    await staff.close();await clear('staff');await command('staff','recreate');
    assert.equal(employee.records.writeNotice,'uncertain');staff=await employee.open(true);
    await heading(staff,'نظرة عامة');await staff.locator('#write-notice[data-state=uncertain]').waitFor();
    assert.equal(await staff.locator('[data-action=ack-write]').count(),0);
    await click(staff,'new-movement');assert.equal(await d(staff).isVisible(),false);
    await click(staff,'review-write');await heading(staff,'الحركات');await view(staff).getByText(lost,{exact:true}).waitFor();
    await click(staff,'ack-write');await staff.locator('#write-notice').waitFor({state:'hidden'});
    assert.equal(writes(),beforeFault+1);assert.equal(saves(lost),1);
    assert.equal(employee.records.writeNotice,'');
    await nav(owner,'users');await heading(owner,'المستخدمون الفرعيون');
    const member=owner.locator('[data-user="qa.staff"]');await member.locator('[data-action=edit-user]').click();
    await modal(owner,'إعدادات المستخدم الفرعي');await permit(owner,'addMovement').uncheck();await submit(d(owner));await d(owner).waitFor({state:'hidden'});
    await nav(staff,'accounts');await heading(staff,'الحسابات');await click(staff,'refresh');
    await staff.locator('[data-action=new-movement]').first().waitFor({state:'detached'});
    const latest=(await call('staff','desk')).value;
    assert.equal((await call('staff','book/change',{action:'movement-add',fields:{version:latest.version,kind:'credit',code:'YER',amount:'2.000',day:latest.today,account:'a'}})).status,403);
    // Model exit/background: a cookie is dropped and no pending reply is delivered.
    let release;const held=new Promise(resolve=>{hold={path:'/api/status',ready:resolve};});
    const dropId='desk-'+(++sequence);wire({lane:'staff',origin,ticket:dropId,route:'status',passive:true,employee:true});release=await held;
    assert.equal((await call('staff','me')).value.code,'busy');assert.equal((await clear('staff')).status,204);
    release();await wait(180);assert.deepEqual(canceled,[]);assert.equal((await call('staff','desk')).status,401);
    assert.equal((await stash('staff')).stored,true);
    await staff.close();await command('staff','recreate');staff=await employee.open(true);
    await heading(staff,'نظرة عامة');assert.equal(await login(staff).count(),0);
    assert.deepEqual(await staff.evaluate(()=>[localStorage.length,sessionStorage.length,document.cookie]),[0,0,'']);
    await nav(staff,'more');await click(staff,'logout');await login(staff).waitFor();assert.equal((await stash('staff')).stored,false);
    await creds(staff,'qa.staff',temporary);await staff.locator('#gate-error').waitFor();assert.equal(await view(staff).count(),0);
    await field(login(staff),'remember').check();await creds(staff,'qa.staff',pStaff);await heading(staff,'نظرة عامة');
    assert.deepEqual(await stash('staff'),{stored:true,writes:2});
    await member.locator('[data-action=toggle-user]').click();await modal(owner,'إيقاف المستخدم');
    await submit(d(owner));await d(owner).waitFor({state:'hidden'});await click(staff,'refresh');await login(staff).waitFor();
    assert.equal(await view(staff).count(),0);assert.equal((await call('staff','status')).status,401);
    await click(staff,'desk-saved');await staff.locator('#gate-error').waitFor();assert.equal((await stash('staff')).stored,false);
    assert.equal(await staff.locator('[data-action=desk-saved]').count(),0);
    await click(staff,'desk-link');for(let i=0;i<20&&!employee.records.change;i++)await wait(40);assert.equal(employee.records.change,1);
    await nav(owner,'more');await click(owner,'logout');await login(owner).waitFor();assert.equal((await call('owner','desk')).status,401);
    await click(owner,'leave-desk');for(let i=0;i<20&&!manager.records.exit;i++)await wait(40);assert.equal(manager.records.exit,1);
    assert.deepEqual(await manager.phone.evaluate(()=>offlineOps),{open:[[origin]],quick:[[origin]],write:[],legacy:[],outside:[],mode:[origin]});
    assert.equal(await manager.phone.evaluate(()=>data.accounts[0].name),knownLocal);
    assert.equal(await manager.phone.evaluate(()=>data.entries[0].memo),'LOCAL-ONLY-MOVEMENT');
    assert.ok(!store.load().s.ledger.entries.some(e=>e.memo==='LOCAL-ONLY-MOVEMENT'));
    assert.ok(!store.load().s.ledger.accounts.some(a=>a.name===knownLocal||a.name==='NOT-AUTHORIZED'));
    assert.ok(requests.every(r=>r.url.startsWith('/api/')&&!r.url.startsWith('/api/book/import')&&!r.url.startsWith('/api/book/backup')&&!r.url.startsWith('/api/book/transfer-')&&!r.url.startsWith('/api/recovery/')));
    assert.ok(requests.filter(x=>x.url==='/api/info'||x.url==='/api/login').every(x=>!x.cookie));
    assert.deepEqual(outside,[]);assert.deepEqual(errors,[]);
    console.log(`APK shared API ${publicInfo.value.version}: first-run roles, HTTPS binding, temporary password, sealed staff login, logout/suspension, bidirectional changes, scoped permissions, owner-only browser handoff, plus explicit destinations, quick entry, scoped picker, post-commit response/refresh failure and restart without replay verified.`);
  }finally{
    if(browser)await browser.close();
    if(jvm){jvm.stdin.end();jvm.kill();await Promise.race([relayExit,wait(1200)]);}
    for(const s of servers)await new Promise(r=>s.close(r));
    store?.close();fs.rmSync(tmp,{recursive:true,force:true});
  }
})().catch(e=>{console.error(e);process.exitCode=1;});
