'use strict';
/* Entirely fictional records and credentials used only by tests. */
const L=require('../app/ledger.js'),C=require('../app/collections-model.js'),CB=require('../app/category-backup.js');
const P=require('../shared/policy.cjs'),A=require('../shared/auth.cjs'),T=require('../shared/totp.cjs');
const {fixture,make,target}=require('./category-fixtures.cjs');
const ownerPass='synthetic-qayd-owner-only-402897',staffPass='synthetic-qayd-clerk-only-298401';
const recoveryPhrase='Entirely synthetic Sesame Wallet 372041',transferPhrase='Synthetic for one category only 687413';
const oldGrants=[{category:'clients',allow:['view','addMovement','reports','exportCsv']}];
function phoneBook(){
  const phone=fixture();
  phone.entries.find(e=>e.id==='receipt-a').receipt.number=41;phone.receiptSerial=41;
  L.closeYear(phone,2025);
  make(phone,'phone-debit-after-cut',{kind:'debit',account:'b',amount:'4.005',day:'2026-02-06',code:'USD',memo:'PHONE-DEBIT-SYNTHETIC'});
  return L.validate(phone);
}
function phoneCopy(){return CB.create(phoneBook(),target,{includePhotos:false});}
async function sharedState({mfa=false}={}){
  const shared=L.empty();
  shared.settings.business='Synthetic business, shared book only';
  shared.accounts.push({id:'shared-only',name:'عميل التجربة المشترك',category:'clients',color:'mint'});
  const sale=make(shared,'shared-opening',{kind:'credit',account:'shared-only',amount:'61.125',day:'2026-03-03',memo:'ALREADY-SHARED-ONLY'});
  L.closeBalance(shared,'shared-only','YER','2026-03-08');
  C.saveReceipt(shared,{account:'shared-only',code:'YER',amount:'2.250',day:'2026-04-04',receipt:{method:'cash',reference:'SHARED-RECEIPT-1',target:sale.id}}).id='shared-receipt';
  const s=P.fresh(shared),owner=A.makeUser('owner','مالك الاختبار',await A.hash(ownerPass),{owner:true});
  const password=await A.hash(staffPass),staff={...A.makeUser('staff.auth','موظف الاختبار',password,{mustChange:false}),grants:oldGrants};
  const paused={...A.makeUser('staff.paused','موظف موقوف',password,{mustChange:true}),enabled:false};
  const factor=mfa?T.begin(T.seed(),T.step(Date.now())-2):null;if(factor)owner.mfa=factor.mfa;
  s.users=[owner,staff,paused];P.log(s,owner,'owner-init');P.log(s,owner,'user-create',staff.name);P.log(s,owner,'user-update',paused.name);
  return {s,owner,staff,paused,factor,phone:phoneBook()};
}
module.exports={ownerPass,staffPass,recoveryPhrase,transferPhrase,oldGrants,sharedState,phoneBook,phoneCopy};
