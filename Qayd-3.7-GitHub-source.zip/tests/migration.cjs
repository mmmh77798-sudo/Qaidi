const {reveal}=require('./navigation.cjs');
const {chromium}=require('playwright');
const assert=require('node:assert/strict');
const fs=require('node:fs/promises');
const path=require('node:path');
const os=require('node:os');
const {pathToFileURL}=require('node:url');
const {legacyDb,readContainer}=require('./db-fixtures.cjs');
const L=require('../app/ledger.js');
const endpoint=process.argv[2]||'http://localhost:3000/';
const openStorage=p=>p.locator('#sidebar [data-view=settings]:visible,#mobilebar [data-view=settings]:visible').click().then(()=>p.locator('button[data-key=storage]').click());
const dialog=p=>p.locator('#dialog');
const next=p=>dialog(p).locator('[type=submit]').click();
const title=(p,name)=>dialog(p).getByRole('heading',{name,exact:true}).waitFor();
const cancel=p=>dialog(p).locator('.dialog-foot [data-action=close-dialog]').click();
const notes=p=>dialog(p).locator('.form-error');
const snapshot=p=>p.evaluate(()=>localStorage.getItem('qayd.ledger.v1'));
(async()=>{
  const temp=await fs.mkdtemp(path.join(os.tmpdir(),'qayd-migration-'));
  let b;
  try{
    const testDb=path.join(temp,'trial.sqlite.db');legacyDb(testDb);
    const signedDb=path.join(temp,'signed.db');legacyDb(signedDb,'signed');const signedOriginal=await fs.readFile(signedDb);
    const signedOnly=path.join(temp,'signed-only.db');legacyDb(signedOnly,'signed-only');
    const dualDb=path.join(temp,'dual.db');legacyDb(dualDb,'dual');const dualOriginal=await fs.readFile(dualDb);
    const bad=path.join(temp,'decimal.db');legacyDb(bad,'bad-amount');
    const wrong=path.join(temp,'wrong.db');legacyDb(wrong,'wrong-version');
    const link=path.join(temp,'orphan.db');legacyDb(link,'bad-link');
    const damaged=path.join(temp,'short-file.db');const original=await fs.readFile(testDb);await fs.writeFile(damaged,original.subarray(0,200));
    b=await chromium.launch({headless:true,args:['--no-sandbox']});
    const p=await b.newPage({viewport:{width:393,height:852},isMobile:true,hasTouch:true,acceptDownloads:true});
    const errors=[];p.on('pageerror',e=>errors.push(e.message));p.setDefaultTimeout(7000);
    await p.goto(endpoint);await openStorage(p);
    assert.equal(await p.locator('#page [data-action=restore]').count(),1);
    const pick=async (name,view=p)=>{
      if(!await view.locator('#page [data-action=restore]').count())await openStorage(view);
      const [chooser]=await Promise.all([view.waitForEvent('filechooser'),view.getByRole('button',{name:'استرجاع نسخة',exact:true}).click()]);
      await chooser.setFiles(name);
    };
    for(const [file,message] of [[bad,/أكثر من ثلاث منازل/],[wrong,/بنية نسخة دفتر الحسابات/],[link,/مرتبطة بعملة/],[damaged,/غير مكتمل/]]){
      await pick(file);await notes(p).waitFor();assert.match(await notes(p).innerText(),message);
      assert.match(await dialog(p).locator('#db-read-status').innerText(),/توقف الاستيراد/);
      assert.equal(await snapshot(p),null);await cancel(p);
    }
    await pick(testDb);await title(p,'استيراد نسخة دفتر الحسابات');
    assert.match(await dialog(p).locator('.legacy-sample').first().innerText(),/عينة عادية/);
    assert.equal(await p.evaluate(()=>document.documentElement.scrollWidth),393);
    const sel=(name,value,view=p)=>dialog(view).locator(`select[name=${name}]`).selectOption(value);
    const rules=async(view=p)=>{await sel('movement','credit',view);await sel('dayOrder','dm',view);await sel('transferMode','complete',view);await next(view);await title(view,'مطابقة رصيد قبل الاسترجاع');};
    await rules();
    assert.match(await dialog(p).locator('#legacy-proposed').innerText(),/115\.75/);
    await sel('flow','credit');await dialog(p).locator('[name=expected]').fill('1');await next(p);
    await notes(p).waitFor();assert.match(await notes(p).innerText(),/الرصيد غير مطابق/);
    assert.equal(await snapshot(p),null);
    await p.locator('#legacy-back').click();await title(p,'استيراد نسخة دفتر الحسابات');
    await sel('transferMode','posted');await next(p);await title(p,'مطابقة رصيد قبل الاسترجاع');
    assert.match(await dialog(p).locator('#legacy-proposed').innerText(),/100/);
    await p.locator('#legacy-back').click();await rules();
    await sel('flow','credit');await dialog(p).locator('[name=expected]').fill('١١٥٫٧٥');await next(p);
    await title(p,'استرجاع واستبدال البيانات');assert.match(await dialog(p).locator('.legacy-verified').innerText(),/حساب مقابل/);
    const waiting=p.waitForEvent('download');await dialog(p).locator('[data-action=backup-before-restore]').click();
    const copy=await waiting;assert.match(copy.suggestedFilename(),/^qayd-before-restore.*\.db$/);
    assert.equal(readContainer(await copy.path()).demo,true);
    assert.equal(await snapshot(p),null);
    const shot=process.env.QAYD_MIGRATION_SHOT;if(shot)await p.screenshot({path:shot,fullPage:true});
    await next(p);await p.locator('#dialog').waitFor({state:'hidden'});
    const stored=JSON.parse(await snapshot(p));assert.equal(stored.accounts.length,2);assert.equal(stored.entries.length,5);
    assert.equal(L.balances(stored,'YER').get('old-a-10').minor,1034500);
    assert.equal(L.balances(stored,'YER').get('old-a-20').minor,115750);
    assert.equal(L.balances(stored,'SAR').get('old-a-20').minor,50000);
    assert.equal(stored.entries.find(e=>e.id==='old-t-2').day,'2026-03-02');
    assert.equal(stored.entries.find(e=>e.id==='old-t-6').time,'12:24');
    assert.doesNotMatch(JSON.stringify(stored),/PRIVATE_TEST|محذوف/);
    assert.deepEqual(await fs.readFile(testDb),original,'Original SQLite file changed');
    assert.deepEqual(errors,[]);

    // With no positive magnitudes there is no direction choice. The existing
    // unsigned magnitude + «عليّ» form of balance verification still works.
    await openStorage(p);
    const beforeSigned=await snapshot(p);
    await pick(signedOnly);await title(p,'استيراد نسخة دفتر الحسابات');
    assert.equal(await dialog(p).locator('[name=movement]').count(),0);
    assert.match(await dialog(p).locator('.legacy-sample').first().innerText(),/-3\.21/);
    await next(p);await title(p,'مطابقة رصيد قبل الاسترجاع');
    assert.match(await dialog(p).locator('#legacy-proposed bdi').innerText(),/-3\.21/);
    await sel('flow','debit');await dialog(p).locator('[name=expected]').fill('3.21');await next(p);
    await title(p,'استرجاع واستبدال البيانات');await cancel(p);
    assert.equal(await snapshot(p),beforeSigned);

    // Change directions on the same input; only the positive source values flip.
    await pick(signedDb);await title(p,'استيراد نسخة دفتر الحسابات');
    await sel('movement','debit');await sel('dayOrder','dm');await sel('transferMode','complete');
    await next(p);await title(p,'مطابقة رصيد قبل الاسترجاع');
    assert.match(await dialog(p).locator('#legacy-proposed bdi').innerText(),/-316\.07/);
    await p.locator('#legacy-back').click();await title(p,'استيراد نسخة دفتر الحسابات');
    await rules();
    assert.match(await dialog(p).locator('#legacy-proposed bdi').innerText(),/-84\.57/);
    await dialog(p).locator('[name=expected]').fill('−٨٤٫٥٧');await sel('flow','credit');await next(p);
    await notes(p).waitFor();assert.match(await notes(p).innerText(),/الرصيد غير مطابق/);
    assert.equal(await snapshot(p),beforeSigned);
    await sel('flow','');await next(p);await title(p,'استرجاع واستبدال البيانات');
    assert.match(await dialog(p).locator('.legacy-summary').innerText(),/2 من المبالغ السالبة/);
    assert.equal(await snapshot(p),beforeSigned);
    await next(p);await dialog(p).waitFor({state:'hidden'});
    const signed=JSON.parse(await snapshot(p));
    assert.equal(signed.entries.length,7);
    assert.equal(signed.entries.find(e=>e.id==='old-t-7').legs[0].minor,-12340);
    assert.equal(signed.entries.find(e=>e.id==='old-t-8').legs[0].minor,-200320);
    assert.equal(L.balances(signed,'YER').get('old-a-10').minor,1022160);
    assert.equal(L.balances(signed,'YER').get('old-a-20').minor,-84570);
    assert.equal(L.balances(signed,'SAR').get('old-a-20').minor,50000);
    assert.deepEqual(await fs.readFile(signedDb),signedOriginal,'Signed SQLite source changed');

    await p.locator('#mobilebar [data-view=accounts]').click();
    await p.locator('[data-action=open-account][data-id=old-a-20]:visible').click();
    const line=p.locator('#view-results tbody tr').filter({hasText:'سالب في الخانة الأولى'});
    assert.match(await line.locator('td').nth(3).innerText(),/-200\.32/);
    assert.match(await line.locator('td').nth(4).innerText(),/-84\.57/);
    await p.locator('[data-action=export-options][data-target=statement]').click();
    const waitingCsv=p.waitForEvent('download');await dialog(p).locator('[data-action=csv]').click();
    const csv=await fs.readFile(await (await waitingCsv).path(),'utf8');
    assert.match(csv,/سالب في الخانة الأولى.*-200\.32.*-84\.57/);

    const checkBackupRoundTrip=async(ledger)=>{
      await openStorage(p);
      const waitingDb=p.waitForEvent('download');await p.locator('[data-action=backup]').click();
      const exported=await waitingDb, portable=path.join(temp,exported.suggestedFilename());await exported.saveAs(portable);
      assert.match(portable,/\.db$/);assert.deepEqual(readContainer(portable).entries,ledger.entries);
      const roundTrip=await b.newPage();roundTrip.on('pageerror',e=>errors.push(e.message));roundTrip.setDefaultTimeout(7000);
      await roundTrip.goto(endpoint);await openStorage(roundTrip);await pick(portable,roundTrip);
      try{await title(roundTrip,'استرجاع واستبدال البيانات');}
      catch(e){throw new Error(`Review after choosing ${path.basename(portable)}: ${await dialog(roundTrip).textContent()} · ${await roundTrip.locator('#toast').textContent()} · ${errors.join('; ')}`,{cause:e});}
      assert.equal(await snapshot(roundTrip),null);
      await next(roundTrip);await dialog(roundTrip).waitFor({state:'hidden'});
      const restored=JSON.parse(await snapshot(roundTrip));assert.deepEqual(restored.entries,ledger.entries);
      assert.deepEqual(L.balances(restored,'YER'),L.balances(ledger,'YER'));
      assert.deepEqual(L.balances(restored,'SAR'),L.balances(ledger,'SAR'));
      await roundTrip.close();
    };
    await checkBackupRoundTrip(signed);

    // Both nonzero fields must survive as separate postings. Review the original
    // fields and their effects before confirming a balance in an impacted currency.
    const beforeDual=await snapshot(p);
    await pick(dualDb);await title(p,'استيراد نسخة دفتر الحسابات');
    assert.ok(await dialog(p).getByRole('heading',{name:'صفوف فيها مبلغان'}).isVisible());
    await rules();
    const dualPreview=dialog(p).locator('#legacy-dual-example');
    const proposed=dialog(p).locator('#legacy-proposed bdi');
    assert.equal(await dialog(p).locator('[name=account] option').count(),2);
    assert.equal(await proposed.innerText(),'-65.01');
    assert.match(await dualPreview.locator('summary').innerText(),/9010/);
    assert.deepEqual(await dualPreview.locator('tbody tr:first-child > *').allInnerTexts(),['in','-150.25','-150.25']);
    assert.deepEqual(await dualPreview.locator('tbody tr:last-child > *').allInnerTexts(),['out','30.51','-30.51']);
    assert.match(await dualPreview.locator('p').innerText(),/-180\.76/);
    const dualShot=process.env.QAYD_DUAL_SHOT;if(dualShot)await p.screenshot({path:dualShot,fullPage:true});
    await sel('account','old-a-10|SAR');assert.equal(await proposed.innerText(),'0');
    assert.match(await dualPreview.locator('summary').innerText(),/9011/);
    await sel('flow','zero');await next(p);await title(p,'استرجاع واستبدال البيانات');
    assert.match(await dialog(p).locator('.legacy-verified').innerText(),/ريال سعودي/);
    await cancel(p);assert.equal(await snapshot(p),beforeDual);

    await pick(dualDb);await title(p,'استيراد نسخة دفتر الحسابات');
    await sel('movement','debit');await sel('dayOrder','dm');await sel('transferMode','complete');
    await next(p);await title(p,'مطابقة رصيد قبل الاسترجاع');
    assert.equal(await proposed.innerText(),'-235.49');
    assert.deepEqual(await dualPreview.locator('tbody tr:last-child > *').allInnerTexts(),['out','30.51','+30.51']);
    await p.locator('#legacy-back').click();await title(p,'استيراد نسخة دفتر الحسابات');await rules();
    // One cent off must block restore. A negative with no separate side is valid.
    await dialog(p).locator('[name=expected]').fill('-65.00');await next(p);
    await notes(p).waitFor();assert.match(await notes(p).innerText(),/الرصيد غير مطابق/);
    assert.equal(await snapshot(p),beforeDual);
    await dialog(p).locator('[name=expected]').fill('-65.01');await next(p);
    await title(p,'استرجاع واستبدال البيانات');
    assert.match(await dialog(p).locator('.legacy-summary').innerText(),/2 من الصفوف بمبلغين.*4 قيد/);
    assert.equal(await snapshot(p),beforeDual);
    const dualCopy=p.waitForEvent('download');await dialog(p).locator('[data-action=backup-before-restore]').click();
    assert.deepEqual(readContainer(await (await dualCopy).path()).entries,signed.entries);
    await next(p);await dialog(p).waitFor({state:'hidden'});
    const dual=JSON.parse(await snapshot(p));assert.equal(dual.entries.length,10);
    const legs=dual.entries.filter(e=>e.id.startsWith('old-t-9010-')).map(e=>e.legs);
    assert.deepEqual(legs,[[{account:'old-a-20',code:'YER',minor:-150250}],[{account:'old-a-20',code:'YER',minor:-30510}]]);
    assert.deepEqual(dual.entries.filter(e=>e.id.startsWith('old-t-9011-')).map(e=>e.legs[0].minor),[5000,-5000]);
    assert.equal(dual.entries.find(e=>e.id==='old-t-9012').legs.length,1);
    assert.equal(L.balances(dual,'YER').get('old-a-10').minor,1065010);
    assert.equal(L.balances(dual,'YER').get('old-a-20').minor,-65010);
    assert.equal(L.balances(dual,'SAR').get('old-a-10').minor,0);
    assert.deepEqual(await fs.readFile(dualDb),dualOriginal,'Dual source SQLite file changed');
    await checkBackupRoundTrip(dual);

    // WebView file-origin + document callback: real bytes through a mocked native bridge.
    const native=await b.newPage();native.on('pageerror',e=>errors.push(e.message));native.setDefaultTimeout(7000);
    await native.addInitScript(chunks=>{
      const payload=atob(chunks);
      window.QaydAndroid={readLedger:()=>null,writeLedger:s=>{window.nativeSaved=s;return true;},pickBackup:drive=>{window.selection=drive;},
        readPendingBackup:id=>window.qaydBackupReady(id,'old-backup.db',payload.length,'db'), backupPart:(_id,off)=>btoa(payload.slice(off,off+4096)),discardBackup:()=>{}};
    },dualOriginal.toString('base64'));
    await native.goto(pathToFileURL(path.join(__dirname,'../app/index.html')).href);
    await openStorage(native);await (await reveal(native.locator('[data-action=drive-import]'))).click();
    assert.equal(await native.evaluate(()=>window.selection),true);
    await native.evaluate(()=>window.qaydBackupOffered('db-file-offer',true));await title(native,'استيراد نسخة دفتر الحسابات');
    await rules(native);await sel('flow','debit',native);await dialog(native).locator('[name=expected]').fill('-65.01');
    await next(native);await title(native,'استرجاع واستبدال البيانات');
    assert.equal(await native.evaluate(()=>!!window.nativeSaved),false);await next(native);await dialog(native).waitFor({state:'hidden'});
    const nativeLedger=await native.evaluate(()=>JSON.parse(window.nativeSaved));
    assert.deepEqual(nativeLedger.entries,dual.entries);
    assert.equal(L.balances(nativeLedger,'YER').get('old-a-20').minor,-65010);
    // >64 KiB and Unicode must round trip across SQLite chunks; check file-origin worker.
    assert.equal(await native.evaluate(async()=>{
      const value=JSON.stringify({value:'📁اختبار محفوظ'.repeat(18001)}), d=await QaydDb.write(value);
      return (await QaydDb.read(d).promise).text===value;
    }),true);
    assert.deepEqual(errors,[]);
    console.log('Legacy DB: dual-column and signed postings, guided review, transfers, exact balances, unchanged sources, CSV, DB round trips and chunked native intake passed.');
  }finally{if(b)await b.close();await fs.rm(temp,{recursive:true,force:true});}
})().catch(e=>{console.error(e);process.exitCode=1;});
