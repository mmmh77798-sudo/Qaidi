package app.qayd.ledger;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.URI;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;

public class LanPreviewTest {
    private static String call(URI uri,String method,String path)throws Exception {
        try(Socket s=new Socket(uri.getHost(),uri.getPort())){
            s.setSoTimeout(3500);
            s.getOutputStream().write((method+" "+path+" HTTP/1.1\r\nHost: test\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.US_ASCII));
            InputStream in=s.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[1024];int n;
            try{while((n=in.read(b))!=-1)out.write(b,0,n);}
            catch(java.net.SocketException e){if(out.size()>0)throw new AssertionError("Partial response before reset",e);throw e;}
            return new String(out.toByteArray(),StandardCharsets.UTF_8);
        }
    }
    private static void check(boolean ok){if(!ok)throw new AssertionError();}
    public static void main(String[] args)throws Exception{
        LanPreview preview=new LanPreview((Inet4Address)InetAddress.getByName("127.0.0.1"),"<!doctype html>اختبار بيانات وهمية");
        URI uri=new URI(preview.url());
        try {
            check(uri.getPath().matches("/view/[a-f0-9]{48}/"));
            String fine=call(uri,"GET",uri.getPath());
            check(fine.startsWith("HTTP/1.1 200")&&fine.contains("اختبار بيانات")&&fine.contains("no-store")&&fine.contains("frame-ancestors 'none'"));
            String wrong=call(uri,"GET","/view/invalid/");check(wrong.startsWith("HTTP/1.1 404")&&!wrong.contains("اختبار بيانات"));
            check(call(uri,"POST",uri.getPath()).startsWith("HTTP/1.1 405"));
            check(!call(uri,"HEAD",uri.getPath()).contains("اختبار بيانات"));
        }finally{preview.close();}
        check(!preview.alive());
        // Kernels can refuse or reset the connection as the listener shuts down.
        // Neither path may return any part of the shared snapshot.
        try{check(call(uri,"GET",uri.getPath()).isEmpty());}catch(java.net.SocketException expected){}
        System.out.println("LAN preview: token, read-only methods, no-store, and listener shutdown verified.");
    }
}
